# Mon Carnet Numérique — inventaire des textes à faire examiner par le juriste

**Version examinée :** archive `e-carnetv1.zip` reçue le 8 octobre 2026  
**Objet :** recenser les formulations juridiques, les engagements et les affirmations sensibles présents dans l’interface, l’API et la documentation, afin de les soumettre au juriste du projet.  
**Statut :** document de repérage, **pas un avis juridique**, pas une validation de conformité et pas une réécriture des clauses.

> Le juriste doit décider seul du contenu, des obligations, des termes à employer et de la version à publier. Les citations ci-dessous sont des extraits fidèles du dépôt, donnés pour faciliter la revue. Les constats techniques factuels doivent également être confirmés par l’équipe produit/sécurité.

## 1. Alerte de statut avant toute revue

Le dépôt **ne décrit pas une V1 prête à recevoir des données de santé réelles**. Le README et les documents d’état indiquent : « V1 en construction, non acceptée et non autorisée pour des données de santé réelles » ; le rapport Go/No-Go conclut **NO-GO pour staging/production**. La preuve la plus récente consignée est 77 tests réussis sur PostgreSQL 16 local et un test de restauration locale ; ce n’est ni une recette staging ni une validation juridique/médicale.

Une page de l’application diverge de cet état interne : `/v1` se présente comme « V1 — Cœur sûr et utilisable », sa méta-description parle de « V1 stable », et son pied de page affirme « V1 stable et utilisable ». **Faire arbitrer cette divergence avant tout partage public ou lancement**, sans prendre le texte de la page comme preuve de disponibilité.

Références : `README.md:5-6, 32-42`; `docs/ETAT-REEL-V1.md:3-5, 80-103`; `docs/GO-NO-GO-2026-10-05.md:5-7, 20-22`; `apps/web/src/app/v1/page.tsx:4-7, 58-63, 119-121`.

## 2. Textes publics et promesses produit

### 2.1 Page d’accueil — `apps/web/src/app/page.tsx`

La page d’accueil expose, entre autres, les affirmations suivantes :

- Méta-description : « Préparez vos consultations, autorisez un médecin en un scan, gardez la trace de chaque accès. Un carnet de santé numérique où le patient décide. » (`:7-10`)
- « Aucun professionnel ne voit votre carnet sans votre accord, donné pour une durée limitée et révocable à tout moment. » (`:16-20`)
- « Chaque lecture et chaque décision sont enregistrées. Vous savez qui a accédé à quoi, et quand. » (`:16-20`)
- « Ce que vous déclarez n’est jamais présenté comme confirmé tant qu’un médecin ne l’a pas validé lui-même. » (`:16-20`)
- QR : « Il scanne votre QR à usage unique. Cela envoie une demande : rien n’est ouvert tant que vous n’avez pas répondu. » (`:22-28`)
- « L’autorisation dure deux heures, prolongeable deux fois une heure, et vous pouvez la retirer à tout moment. » (`:22-28`)
- « Le médecin complète à partir de votre préparation et signe. Son nom et son établissement sont conservés avec la consultation. » (`:22-28`)
- « Historique, provenance de chaque information et journal des accès restent dans votre carnet. » (`:22-28`)
- Espace professionnel : « Spécialité déclarée, sans pièce ni numéro professionnel » ; espace établissement : « Aucun accès aux dossiers médicaux. » (`:30-43`)
- Pilote : « l’application est un pilote. Elle ne sera ouverte à de vraies données de santé qu’après validation complète de la sécurité, de l’hébergement et du cadre juridique. » (`:116-120`)
- Questions fréquentes intégrées : l’établissement vérifierait le professionnel en interne, et sans accord du patient « rien n’est lisible » ; seules des données fictives seraient accueillies à ce stade (`:45-49`).

**À soumettre :** la portée exacte de « vous seul décidez », « aucun professionnel », « chaque lecture », « tout est tracé », « jamais », « à tout moment », « chaque accès », « garde la main », « signé », « données fictives uniquement » et la promesse d’accès « en un scan ». Le code et l’état produit doivent confirmer chaque assertion. Le dossier technique précise qu’un parcours QR demande encore l’UUID du patient séparément (`docs/ETAT-REEL-V1.md:16-19`; `docs/RECETTE-V1.md:19`).

### 2.2 Pages « À propos », « Sécurité », FAQ et pied de page

- `/a-propos` — `apps/web/src/app/a-propos/page.tsx:5-8` : « Un carnet durable, sous le contrôle du patient » ; le patient « conserve ses déclarations, leur provenance et la décision d’autoriser ou non un accès » ; un professionnel ne lirait rien sans vérification, rattachement, établissement actif et consentement explicite ; « les corrections sont historisées ».
- `/securite` — `apps/web/src/app/securite/page.tsx:5-8` : « Chaque demande sensible est contrôlée côté serveur » par session, contexte, établissement, AccessGrant, périmètre et expiration ; « cookies protégés », isolation entre établissements, « audit append-only », aucun cache hors ligne de données médicales ; le texte précise que l’hébergement ivoirien, la revue juridique, la restauration testée et les contrôles indépendants sont à faire avant toute donnée réelle.
- FAQ publique — `apps/web/src/app/faq/page.tsx:5-10` : pas d’accès automatique ; durée de deux heures et deux prolongations d’une heure ; « Vous pouvez révoquer à tout moment » ; aucun compte/role/espace infirmier autonome ; données médicales non mises en cache hors ligne.
- Pied de page — `apps/web/src/components/public/PublicShell.tsx:26-40` : « Pilote en cours : l’application ne contient aucune donnée de santé réelle. Ce site ne remplace pas un avis médical. »

**Point de cohérence à demander au produit/sécurité :** la page sécurité présente un audit « append-only » comme prévu, tandis que les documents techniques disent que la protection contre `TRUNCATE` et les privilèges runtime restent à compléter/vérifier sur la cible (`docs/SECURITY.md:13, 17-27`; `docs/ETAT-REEL-V1.md:92`). Ne publier une promesse technique qu’après confirmation du périmètre et de l’état réel.

### 2.3 Page V1 et autres affirmations d’état du produit

`apps/web/src/app/v1/page.tsx:10-40, 57-63, 101-121` décrit les fonctionnalités incluses et exclues, affirme que le professionnel ne voit aucune donnée sans autorisation explicite et termine par « V1 stable et utilisable — socle sécurisé ». À confronter au verdict NO-GO et aux validations manquantes des documents de référence. Cette page est accessible (même si son indexation est désactivée) et contient des liens de démonstration.

### 2.4 Formulations d’établissement / staff

- `apps/web/src/components/EstablishmentWorkspace.tsx:58-64, 67-88, 104-107` : accès réservé à l’administrateur nominatif invité ; établissement transmet ses justificatifs par e-mail ; l’équipe vérifie puis crée l’entité et invite l’administrateur ; l’espace ne donne aucun accès clinique.
- `apps/web/src/components/EstablishmentConsole.tsx:43, 49-54, 81-88, 122-136` : la demande est examinée par l’équipe ; un code est unique et valable 48 h ; le médecin doit attendre l’acceptation ; aucune lecture de dossier patient par l’établissement ; fin du rattachement sans effacer les traces/dossiers existants.
- `apps/web/src/components/StaffProfessionalVerification.tsx:6-17` : E‑Carnet « ne collecte pas et ne valide pas les justificatifs médicaux individuels » ; l’établissement procède à la vérification ; la spécialité visible « est déclarative » et « ne constitue pas une attestation ni une vérification médicale par E‑Carnet ».
- `apps/web/src/components/EstablishmentAdminWorkspace.tsx:63-65` : espace administratif, pas d’accès aux dossiers ; code 48 h à usage unique ; création d’une demande en attente, pas d’affiliation automatique.

### 2.5 Authentification et compte

`apps/web/src/components/AuthForms.tsx:29-42` affiche « Une identité unique. Des accès temporaires, visibles et révocables », puis Google/Facebook/Apple/e-mail. L’inscription par e-mail recueille nom, prénom, e-mail et mot de passe ; aucun lien vers des conditions générales ou une politique de confidentialité, ni case d’acceptation générale n’a été repéré dans cet écran.

`apps/web/src/components/AccountSettingsClient.tsx:25-29` expose l’identité, l’avatar par URL, les fournisseurs liés et leur déliaison ; il précise qu’aucune fusion de compte n’est faite automatiquement sur la seule adresse e-mail.

## 3. Consentement patient et accès clinique

### 3.1 Présentation et actions d’autorisation

Dans `apps/web/src/components/PatientAccessGrants.tsx:131-173` :

- « Chaque demande affiche le professionnel, l’établissement, le périmètre et la durée. Aucun accès n’est ouvert avant votre choix. »
- « Le QR contient uniquement un jeton opaque à usage unique. Il ne contient aucune donnée médicale. »
- QR temporaire, expiration au bout de cinq minutes et consommation par une seule demande.
- La demande présente le périmètre et une durée initiale de 2 h, prolongée au plus deux fois d’1 h, puis les commandes « Autoriser 2 h », « Refuser », « Prolonger 1 h » et « Révoquer maintenant ».
- L’historique présente notamment « Demande créée », « Accès autorisé », « Accès refusé », « Accès prolongé », « Accès révoqué », « Accès expiré ».

Dans `apps/web/src/components/ProfessionalAccessFlow.tsx:93-121` : « Avant consentement, aucune donnée médicale n’est renvoyée. Le patient valide ou refuse la demande, avec durée et périmètre visibles. » Le professionnel choisit un ID patient et un périmètre avant d’envoyer la demande.

Dans `apps/web/src/components/ProfessionalAccessGrants.tsx:74-77`, le texte indique que contexte professionnel, rattachement et établissement actif sont contrôlés par l’API, et qu’une demande ne donne aucun accès avant le consentement.

**À valider par le juriste avec l’équipe métier :** l’objet exact du consentement, les données/périmètres concernés, destinataires, durée, renouvellement, révocation, traces conservées, conséquences d’un refus, circonstances particulières (patient mineur ou représenté, personne aidante, urgence) et relation avec les autres autorisations/obligations de soins. Cette liste formule des questions, pas une conclusion juridique.

### 3.2 Pré-consultation et déclarations de santé

- `apps/web/src/components/PatientCarnet.tsx:37-58` : le patient ajoute une déclaration d’allergie, antécédent ou traitement ; le bandeau affirme que chaque information garde sa provenance et n’est pas confirmée avant validation par un médecin ; confirmation « Déclaration ajoutée. Elle reste marquée “déclarée par vous”. »
- `apps/web/src/components/PatientPreconsultations.tsx:64-95` : champ établissement destinataire, motif, observations (« Ce que vous ressentez ») et « Saisie aidée par (facultatif) » ; après enregistrement, le texte promet qu’un professionnel rattaché au même établissement ne peut lire qu’avec autorisation ; après clôture, le texte répète que la lecture est conditionnée à l’autorisation et au même établissement.
- `apps/web/src/components/ProfessionalConsultations.tsx:51-68` : conclusion, conduite à tenir, attestation SVG, historique et validation ; texte affiché : « Une attestation SVG est enregistrée avec la validation. Elle ne constitue pas une signature électronique qualifiée. » Après validation : « Consultation validée et conservée dans l’historique. »

**À faire examiner :** terminologie clinique, distinction entre déclaration et constat professionnel, qui peut corriger, rectifier, compléter ou signer, portée probante de l’attestation/SVG et horodatage, informations de santé traitées, et ce que signifie exactement la « validation » dans ce produit. Les décisions A8 et A10 (champs/unités/corrections) sont signalées comme restant à faire valider médicalement : `docs/QUESTIONNAIRE-DECISIONS-A1-A16.md:38-41`.

## 4. Conditions de rattachement médecin — projet à examiner clause par clause

Source de référence : `docs/CONDITIONS-RATTACHEMENT-MEDECIN.md:1-43`, version `2026-10-08-v1`; le texte de la page d’acceptation est `apps/web/src/app/conditions-rattachement/page.tsx:8-28`.

La page avertit : « Projet fonctionnel à faire valider par un conseil juridique avant tout usage contractuel réel. Ce texte ne remplace pas le contrat complet entre l’établissement et le médecin. » (`:12-14`).

### Engagements effectivement présentés

Le médecin, lors de la saisie du code, accepte les six engagements suivants (`conditions-rattachement/page.tsx:15-24`, mêmes clauses dans le Markdown de référence) :

1. « Protéger les informations non publiques de l’établissement et ne pas les divulguer à des personnes non autorisées, sauf obligation légale ou autorisation documentée. »
2. « Préserver la confidentialité des patients et n’accéder à leurs informations que dans le cadre de ma mission, avec les autorisations et consentements requis. »
3. « Saisir des informations médicales de bonne foi et exactes, distinguer les déclarations du patient des constatations professionnelles, et ne pas inventer, altérer ou falsifier un diagnostic, une consultation, une attestation ou un dossier. »
4. « Protéger mes moyens d’accès, ne pas partager mon compte, mon mot de passe ou mes codes personnels et signaler toute compromission présumée. »
5. « Comprendre que l’établissement peut mettre fin au rattachement et que je peux également y mettre fin depuis mon espace privé. La fin du rattachement bloque les nouveaux accès cliniques dépendant de cette affiliation. »
6. « Comprendre que cette fin n’efface pas les traces d’audit ni les consultations et documents déjà constitués ; leur conservation et leur accès demeurent soumis aux règles applicables et à la politique de conservation à approuver. »

La page explique également que le serveur enregistre le médecin, l’établissement, la version acceptée et l’horodatage UTC ; sans acceptation explicite, le code n’est pas consommé ; accepter ne donne pas à soi seul accès aux dossiers (`:25-27`). Le code source du formulaire lie l’acceptation explicite à la version `2026-10-08-v1` et à la soumission du code (`apps/web/src/components/ProfessionalAccess.tsx:46-53`).

### Questions à soumettre avec le projet de conditions

Le document lui-même demande de valider : identité et pouvoir du signataire établissement ; articulation avec le contrat de travail/prestation et responsabilité professionnelle ; définition des informations confidentielles, exceptions et durée ; sécurité, notification d’incident, conservation et preuve ; règles applicables en Côte d’Ivoire et pays d’exploitation, notamment aux données de santé ; conservation après la fin du rattachement ; sanctions, responsabilité, litiges et signature électronique (`docs/CONDITIONS-RATTACHEMENT-MEDECIN.md:26-34`).

Il ajoute que ce texte **n’est pas à lui seul un contrat complet** et que les parties, obligations, sanctions éventuelles, règles de données de santé et modalités de signature restent à confirmer (`:7`).

## 5. Fin du rattachement et conservation

Les mêmes textes sont présentés dans l’interface médecin et établissement :

- Confirmation médecin : « Les accès cliniques futurs seront bloqués ; les consultations et l’historique existants ne seront pas supprimés. »
- Confirmation administrateur : les accès futurs sont bloqués et « les traces/dossiers existants conservés. »
- Succès médecin : « L’historique et les dossiers existants restent conservés. »

Références : `apps/web/src/components/ProfessionalAccess.tsx:71-73`; `apps/web/src/components/EstablishmentAdminWorkspace.tsx:63-65`; `apps/web/src/components/EstablishmentConsole.tsx:125-136`; définition produit `docs/FLOW-ETABLISSEMENT.md:27-32, 38-48`.

Les documents internes indiquent que la durée de conservation et la purge des preuves structure reçues par e-mail, des éventuels identifiants historiques et des traces sont à décider. Le juriste doit donc examiner ces phrases **comme des assertions d’état/conservation**, et les confronter à une politique approuvée qui n’apparaît pas dans l’archive.

## 6. Données et traitements visibles dans le code — matière à cartographier

Cet inventaire est tiré des modèles et interfaces ; il ne décrit pas à lui seul les finalités, bases juridiques, durées ou responsabilités.

| Famille repérée | Exemples effectivement présents | Repères source |
|---|---|---|
| Compte et identité | Nom, prénom, e-mail, mot de passe (hashé côté serveur), URL d’avatar, contexte d’usage | `apps/api/apps/identity/models.py`; `apps/web/src/components/AuthForms.tsx`; `AccountSettingsClient.tsx` |
| Identité via tiers | Identifiant fournisseur, e-mail, nom d’affichage, URL d’avatar, date de dernière vue Google/Facebook/Apple | `apps/api/apps/identity/models.py:39-56`; `apps/web/src/components/AuthForms.tsx:8-12, 34-37` |
| Profil patient | Téléphone, date de naissance, adresse, organisme/numéro/échéance de couverture | `apps/api/apps/patients/models.py:7-18` |
| Informations de santé | Allergies, antécédents, traitements, détails libres ; motif et observations de pré-consultation ; aide déclarée ; conclusion, observations, conduite à tenir, attestation SVG et horodatages/signature | `apps/api/apps/patients/models.py:24-40`; `apps/api/apps/care/models.py:9-34, 94-125` |
| Accès patient-professionnel | Identifiants reliés, nom du professionnel, établissement, périmètre, statut, date de demande/début/expiration/révocation, nombre de prolongations | `apps/api/apps/care/models.py:36-77` |
| QR et jeton | Jeton opaque présenté au scan ; hash enregistré ; création, expiration et consommation | `apps/api/apps/care/models.py:80-92` |
| Audit | Type d’événement, acteur, rôle, patient, établissement, AccessGrant, consultation, métadonnées et date | `apps/api/apps/audit/models.py:18-44` |
| Professionnel et rattachement | Profession déclarée, spécialité, établissement actif, ancien champ `professional_identifier` dans le modèle, même si le parcours courant ne le demande pas | `apps/api/apps/professionals/models.py:7-18`; `docs/SECURITY.md:23`; `docs/FLOW-ETABLISSEMENT.md:48` |
| Établissement et son responsable | Nom, type, ville, adresse, téléphone, e-mail, nom du responsable ; administrateur nominatif, invitations, codes, adhésions et décisions horodatées | `apps/api/apps/establishments/models.py:9-27, 33-48, 51-118` |
| Justificatifs de structure | Envoyés par e-mail à l’équipe selon le flow, hors dépôt public ; boîte, accès, sauvegarde et purge à définir | `docs/FLOW-ETABLISSEMENT.md:9-16, 64`; `docs/QUESTIONNAIRE-DECISIONS-A1-A16.md:34, 41` |
| Préférences d’apparence | Thème (palette et police) rattaché au compte | `apps/api/apps/identity/models.py:6-15`; `apps/web/src/components/ThemeSettingsClient.tsx` |

**Ne pas conclure** à partir de cet inventaire que toutes ces données sont effectivement collectées en production : le dépôt précise que le pilote doit utiliser uniquement des données synthétiques. Il n’identifie pas les durées par catégorie, l’ensemble des journaux d’hébergeur, ni les flux/transferts entre fournisseurs.

## 7. Éléments juridiques ou notices absents / non repérés dans l’archive

Dans les routes et le pied de page publics parcourus, les pages `/mentions-legales`, `/confidentialite`, `/conditions-generales`/CGU et une page dédiée aux cookies n’ont pas été repérées. Le pied de page ne relie qu’À propos, Sécurité, FAQ et Connexion (`apps/web/src/components/public/PublicShell.tsx:26-40`). Les réglages d’inscription ne présentent pas d’acceptation générale des conditions ou d’information de confidentialité (`apps/web/src/components/AuthForms.tsx:29-45`).

C’est un **constat de contenu absent du dépôt**, pas une qualification de manquement. Demander au juriste quels documents/mentions sont nécessaires au projet et à ses différents utilisateurs, où les afficher, à quel moment, dans quelles langues et avec quels mécanismes d’acceptation/versionnage.

Autres décisions explicitement ouvertes dans le journal produit `docs/QUESTIONNAIRE-DECISIONS-A1-A16.md:34-46` :

- rétention des justificatifs d’établissement reçus par e-mail (A4/A11) ;
- région, lieux de traitement, copies et sauvegardes des fournisseurs Vercel/Render/Neon (A12) ;
- exigences d’hébergement ivoirien avant données réelles (A13) ;
- droit local et avis écrit du juriste (A14) ;
- durée de conservation, correction, export, suppression et maintien de l’audit (A15) ;
- responsables, seuils, délais, confinement et notification d’incident (A16).

Les documents demandent aussi une politique de rétention/purge pour le champ professionnel historique et les preuves reçues par e-mail (`docs/SECURITY.md:22-27`; `docs/FLOW-ETABLISSEMENT.md:48`).

## 8. Liste de questions à faire trancher par le juriste

1. **Identité de l’opérateur et des parties :** qui exploite le service, qui est responsable de quoi dans les relations patient–professionnel–établissement–E‑Carnet, et quelles informations d’identification/contact publier ?
2. **Textes d’usage :** quelles conditions s’appliquent aux patients, professionnels, établissements, administrateurs et personnels internes ? Quelles parties relèvent d’un contrat séparé ?
3. **Données de santé :** quelles catégories sont traitées, par qui, pour quelles finalités et sur quel fondement ; quelles données libres doivent être exclues ou limitées ?
4. **Information et consentement :** quelle information précède l’inscription, la saisie clinique, la demande d’accès, l’autorisation patient, les prolongations, l’usage du QR et la révocation ? Comment traiter mineurs, représentation, aide à la saisie et urgence ?
5. **Durées et fin de relation :** combien de temps garder profils, dossiers, consultations, révisions, événements d’audit, données de rattachement, invitations/codes, preuves e-mail et sauvegardes ; que supprimer, rectifier, exporter ou conserver après fermeture de compte ou fin d’affiliation ?
6. **Hébergement et transferts :** quels lieux/fournisseurs et sous-traitants interviennent (web, API, base, courriel, OAuth, observabilité/journaux, sauvegardes), et quelles informations/clauses doivent être publiées ou conclues ?
7. **Vérification professionnelle :** quelle portée attribuer à l’approbation de l’établissement ? Comment éviter que « vérifié », « validé » ou « signé » soit compris comme une vérification par E‑Carnet ou une certification différente de la réalité ?
8. **Attestation et signature :** portée du SVG, preuve/horodatage, auteur, intégrité, corrections et mentions associées ; le code dit seulement que l’attestation ne constitue pas une signature électronique qualifiée.
9. **Réclamations et incidents :** adresse de contact, gestion des demandes, délais/processus internes, événements de sécurité et communication aux personnes/autorités, selon les décisions du juriste.
10. **Cookies et tiers d’authentification :** information à donner sur les cookies de session/CSRF et les échanges avec Google, Facebook et Apple ; consentement général à l’inscription et liaison d’identité.
11. **Exactitude des promesses :** valider mot à mot les promesses de non-accès, révocabilité, exhaustivité de l’audit, conservation, stockage/absence de cache et statut du pilote avec les responsables techniques.
12. **Versions et preuve :** valider le texte de rattachement, sa version, le moment d’acceptation, la preuve serveur et la procédure en cas de changement de version.

## 9. Sources principales du dépôt

- `apps/web/src/app/page.tsx` — landing et promesses.
- `apps/web/src/app/a-propos/page.tsx`, `faq/page.tsx`, `securite/page.tsx`, `v1/page.tsx` — pages publiques.
- `apps/web/src/components/public/PublicShell.tsx` — navigation/pied de page/disclaimer.
- `apps/web/src/app/conditions-rattachement/page.tsx` et `apps/web/src/components/ProfessionalAccess.tsx` — texte versionné et acceptation.
- `apps/web/src/components/PatientAccessGrants.tsx`, `ProfessionalAccessFlow.tsx`, `ProfessionalAccessGrants.tsx` — autorisations, QR et accès.
- `apps/web/src/components/PatientCarnet.tsx`, `PatientPreconsultations.tsx`, `ProfessionalConsultations.tsx` — données et textes cliniques.
- `apps/web/src/components/EstablishmentWorkspace.tsx`, `EstablishmentConsole.tsx`, `EstablishmentAdminWorkspace.tsx`, `StaffProfessionalVerification.tsx` — obligations/affirmations établissement.
- `apps/api/apps/*/models.py` et `apps/api/apps/establishments/email_service.py` — données structurées et invitation e-mail.
- `docs/CONDITIONS-RATTACHEMENT-MEDECIN.md`, `docs/QUESTIONNAIRE-DECISIONS-A1-A16.md`, `docs/SECURITY.md`, `docs/FLOW-ETABLISSEMENT.md`, `docs/ETAT-REEL-V1.md`, `docs/RECETTE-V1.md`, `docs/GO-NO-GO-2026-10-05.md` — texte de référence et décisions ouvertes.

## 10. Précaution de remise

Remettre au juriste le dossier avec l’archive source et lui demander de marquer, pour chaque extrait : **à conserver / à modifier / à retirer / à déplacer / décision requise**, puis de fournir les textes finaux et les conditions d’affichage/acceptation. Les propositions finales doivent être validées par l’équipe produit et technique avant publication. Aucune phrase de ce document ne doit être interprétée comme approbation juridique de la V1.
