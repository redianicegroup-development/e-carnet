from django.urls import path

from .views import MfaSetupView, MfaVerifyView, ProfessionalMeView, ProfessionalOnboardingView, ProfessionalSpecialtyListView

urlpatterns = [
    path("specialties/", ProfessionalSpecialtyListView.as_view()),
    path("me/", ProfessionalMeView.as_view()),
    path("onboarding/", ProfessionalOnboardingView.as_view()),
    path("mfa/setup/", MfaSetupView.as_view()),
    path("mfa/verify/", MfaVerifyView.as_view()),
]
