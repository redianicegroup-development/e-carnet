import base64
import hashlib
import hmac
import struct
import time


def totp(secret, interval=30, digits=6, at=None):
    counter = int((at or time.time()) // interval)
    digest = hmac.new(base64.b32decode(secret, casefold=True), struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    code = (struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF) % (10 ** digits)
    return f"{code:0{digits}d}"


def valid_totp(secret, code):
    clean = str(code).strip()
    return any(hmac.compare_digest(totp(secret, at=time.time() + shift), clean) for shift in (-30, 0, 30))
