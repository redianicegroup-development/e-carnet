from django.contrib.auth import get_user_model
from django.test import TestCase
from rest_framework.test import APIClient
from .models import AccountContext

User = get_user_model()


class IdentityOnboardingTests(TestCase):
    def setUp(self):
        self.client = APIClient()

    def test_register_creates_one_account_and_patient_context(self):
        response = self.client.post("/api/v1/identity/register/", {"email": "awa@example.test", "password": "a-long-local-password", "first_name": "Awa", "last_name": "Koné"}, format="json")
        self.assertEqual(response.status_code, 201)
        user = User.objects.get(email="awa@example.test")
        self.assertEqual(AccountContext.objects.filter(user=user, role="patient").count(), 1)
        self.assertEqual(self.client.get("/api/v1/identity/me/").status_code, 200)

    def test_duplicate_email_and_invalid_login_are_rejected(self):
        self.client.post("/api/v1/identity/register/", {"email": "dup@example.test", "password": "a-long-local-password", "first_name": "A", "last_name": "B"}, format="json")
        duplicate = self.client.post("/api/v1/identity/register/", {"email": "DUP@example.test", "password": "a-long-local-password", "first_name": "A", "last_name": "B"}, format="json")
        self.assertEqual(duplicate.status_code, 400)
        self.client.post("/api/v1/identity/logout/")
        invalid = self.client.post("/api/v1/identity/login/", {"email": "dup@example.test", "password": "wrong-password"}, format="json")
        self.assertEqual(invalid.status_code, 400)

    def test_patient_onboarding_completes_profile(self):
        self.client.post("/api/v1/identity/register/", {"email": "patient@example.test", "password": "a-long-local-password", "first_name": "A", "last_name": "B"}, format="json")
        response = self.client.patch("/api/v1/identity/onboarding/patient/", {"phone": "+22500000000", "coverage_provider": "Couverture fictive"}, format="json")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data["data"]["patient_profile"]["completed"])
        self.assertTrue(response.data["data"]["contexts"][0]["onboarding_completed"])

class IdentityProfileAndOAuthTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="identity@example.test", email="identity@example.test", password="a-long-local-password", first_name="Awa", last_name="Kone")
        self.client = APIClient()
        self.client.force_authenticate(self.user)

    def test_identity_profile_can_update_avatar_and_names(self):
        response = self.client.patch("/api/v1/identity/me/profile/", {"first_name": "Awa", "last_name": "Koné", "avatar_url": "https://cdn.example.test/avatar.png"}, format="json")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["data"]["avatar_url"], "https://cdn.example.test/avatar.png")
        self.user.refresh_from_db()
        self.assertEqual(self.user.first_name, "Awa")

    def test_oauth_identity_can_be_unlinked_when_password_exists(self):
        from .models import AuthIdentity
        AuthIdentity.objects.create(user=self.user, provider="google", provider_user_id="google-1", email=self.user.email)
        response = self.client.delete("/api/v1/identity/oauth/identities/google/")
        self.assertEqual(response.status_code, 200)
        self.assertFalse(AuthIdentity.objects.filter(user=self.user).exists())
