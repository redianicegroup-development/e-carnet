# Mon Carnet Numérique — brief de direction artistique

**Destinataires :** infographiste, designer UI/UX et motion designer  
**Version examinée :** dépôt `e-carnetv1.zip`, 8 octobre 2026  
**But :** documenter l’existant et proposer un cap créatif à transformer en identité et en système d’interface. Ce brief n’est pas une maquette ni une validation produit.

## 1. Le projet en une phrase

Un carnet de santé numérique personnel qui aide la personne à préparer ses consultations, à choisir si et dans quelle mesure un professionnel peut consulter certaines informations, puis à retrouver leur provenance et l’historique des accès.

### Principes à faire ressentir

- **La personne reste au centre** : elle prépare, décide, autorise et retrouve.
- **La confiance se voit** : origine des informations, état d’accès, identité de l’établissement et durée doivent être compréhensibles.
- **Le soin est humain, l’interface rigoureuse** : ton calme, clair et accessible, sans froideur hospitalière ni style fintech.
- **Le mobile d’abord** : formulaires courts, grandes cibles, navigation atteignable au pouce ; adaptation desktop ensuite.
- **Pas de promesse visuelle de certification** : le profil professionnel peut être déclaratif ; l’établissement effectue sa propre vérification. Le design ne doit pas laisser entendre qu’E‑Carnet certifie un diplôme ou une qualité médicale.

L’application est une V1 **en construction et NO-GO pour les données de santé réelles** selon ses propres documents. Le projet de direction doit donc éviter des visuels qui pourraient faire croire à une disponibilité clinique déjà autorisée.

## 2. État de l’identité visuelle actuelle

- Noms utilisés : **Mon Carnet Numérique**, **E-carnet**, **E‑Carnet** et parfois « e-carnet ». La relation entre nom institutionnel, nom court, casse et tiret n’est pas harmonisée.
- Le signe de marque principal est un **plus** dans un carré arrondi ; certaines vues ont un plus typographique et le composant d’authentification emploie une petite icône de carnet/document. Il n’y a pas, dans les fichiers publics du dépôt, de logo vectoriel/bitmap maître identifiable : la marque est surtout dessinée par CSS/SVG inline.
- L’iconographie applicative comporte un jeu SVG à trait arrondi et grille commune 24 × 24 (`apps/web/src/components/ui/Icon.tsx`), mais quelques vues utilisent encore des caractères Unicode à la place d’icônes.
- L’interface utilise cartes blanches, fonds pastel, pastilles de statut, coins arrondis, ombres légères, barre de navigation mobile à cinq entrées et rail latéral desktop.
- Les prototypes HTML de `docs/prototypes/` sont une **référence visuelle uniquement** ; certains parcours sont périmés. S’en inspirer pour la densité, la navigation, les proportions, les icônes et la hiérarchie, mais ne pas recopier leurs anciens parcours (`docs/prototypes/README.md`, `docs/prototypes/ARCHITECTURE.md`).

## 3. Palette réellement déclarée dans le code

### 3.1 Palette par défaut du produit

La valeur réellement chargée comme défaut dans `apps/api/apps/identity/theme.py` et `packages/ui/src/themes.ts` est **Lagon** :

| Rang | Rôle conceptuel | Valeur par défaut |
|---|---|---|
| C1 | Fond de page | `#E6FFF7` |
| C2 | Teinte / sélection / surface douce | `#B9F2E3` |
| C3 | Accent doux | `#7AD8C8` |
| C4 | Couleur primaire | `#4AA1A3` |
| C5 | Encre / texte foncé | `#2A4B5D` |

Variables associées en CSS : surface `#FFFFFF`, bordure forte `#718B91`, texte secondaire `#4A6670`, focus `#2A4B5D`. Les algorithmes de thème dérivent certaines variables depuis les cinq couleurs de source et assombrissent au besoin des couleurs pour le contraste ; la couleur rendue du bouton primaire peut donc différer de C4.

### 3.2 Presets disponibles dans l’application

Le code propose neuf palettes à cinq couleurs dans cet ordre : **C1 fond · C2 teinte/surface douce · C3 accent doux · C4 primaire · C5 encre** (`packages/ui/src/themes.ts:22-32`).

| Preset | C1 | C2 | C3 | C4 | C5 |
|---|---|---|---|---|---|
| Sauge | `#F2F5EF` | `#D8E2D0` | `#A9C4A5` | `#5B7F68` | `#2C3A33` |
| Menthe | `#E9F7F2` | `#BFE8D6` | `#63C6A7` | `#2F7E6A` | `#1F2E2C` |
| Brume | `#FFFFFF` | `#F4F7F8` | `#D6E2E6` | `#58B7B0` | `#20343A` |
| Lagon *(défaut code)* | `#E6FFF7` | `#B9F2E3` | `#7AD8C8` | `#4AA1A3` | `#2A4B5D` |
| Miel | `#FFF7E6` | `#FFE3B3` | `#FFC857` | `#4BAA8B` | `#1E3A34` |
| Lavande | `#F6F2FF` | `#E3D7FF` | `#BCA6F6` | `#5D64B8` | `#1F2440` |
| Rose | `#FFF1F5` | `#FFD2DF` | `#F28AA8` | `#B94D6D` | `#3A1E2A` |
| Prairie | `#F5FAF4` | `#DCEFD7` | `#8CCF8A` | `#2F8A5A` | `#1F2D24` |
| Argile | `#FFF4EC` | `#F6D8C3` | `#DDA57A` | `#4D8F86` | `#1D2F33` |

### 3.3 Couleurs sémantiques fixes

Ces couleurs servent aux statuts de provenance et aux états. Le code indique qu’elles ne sont **pas personnalisées** par le thème ; ne pas les détourner comme couleurs de marque.

| Sens | Texte | Fond |
|---|---|---|
| Déclaré par le patient / en attente | `#8A6100` | `#FFF3D6` |
| Relevé / mesuré | `#1F4E8C` | `#E6EEF8` |
| Confirmé / validé / actif | `#17704A` | `#E4F5EC` |
| Contesté / refusé / erreur | `#A32D2D` | `#FBEAE8` |
| Expiré / révoqué / suspendu | `#4A5550` | `#E8ECE9` |
| Danger | `#A32D2D` | — |

Chaque état doit aussi disposer d’un libellé et, le cas échéant, d’une icône : la couleur seule ne doit pas porter l’information.

### 3.4 Divergence de référence à résoudre

Le code courant part de **Lagon + Unbounded** (`packages/ui/src/themes.ts:34`; `apps/api/apps/identity/theme.py:3-6`; `packages/ui/src/styles/tokens.css`). Les commentaires et prototypes archivés décrivent **Sauge + Plus Jakarta Sans** comme défaut (`docs/prototypes/themes.ts:34`; `docs/prototypes/tokens.css:1-26`). La direction artistique devra choisir et documenter **une seule référence officielle**, puis aligner interface, prototypes et documentation. Ne pas laisser l’équipe interpréter les anciens fichiers comme des valeurs actives.

### Recommandation de direction couleur

**Piste proposée : « Sauge & encre »**, en partant du preset existant Sauge : doux, posé et distinct du bleu médical générique. Garder un fond très clair, une encre profonde et un accent vert/bleu-vert pour les actions principales ; réserver les teintes chaudes aux demandes en attente et les statuts sémantiques aux états. Le preset existant est un point de départ, pas un choix final : valider les contrastes sur les couleurs effectivement calculées, les textes, les boutons, les bordures et les focus avant livraison.

**Choix à faire avec le produit :** une palette de marque fixe pour la cohérence de toutes les captures et communications, ou maintien d’un thème personnel par compte. Aujourd’hui, le réglage permet aux utilisateurs de choisir une palette et une police (`apps/web/src/components/ThemeSettingsClient.tsx`). Quelle que soit la décision, les statuts et la lisibilité des captures de formation doivent rester stables.

## 4. Polices et typographie déclarées

### 4.1 Polices disponibles

Douze familles sont déclarées dans l’interface de thème (`packages/ui/src/themes.ts:8-12`) et préconfigurées avec `next/font/google` dans `apps/web/src/app/layout.tsx:3-40` :

1. Plus Jakarta Sans
2. Nunito
3. Lexend
4. Manrope
5. Sora
6. Mooli
7. Unbounded
8. Quicksand
9. Bricolage Grotesque
10. Barlow
11. Ubuntu
12. Fredoka

La police sélectionnée par défaut dans le code courant est **Unbounded**. La police monospace est **JetBrains Mono**, dédiée aux codes/identifiants et éléments techniques (`packages/ui/src/styles/tokens.css`). Les familles de thème sont globalement déclarées au poids 400 seulement, à l’exception de Unbounded (400 à 800) et JetBrains Mono (400 et 600) dans le layout ; les styles emploient des graisses 600, 700 et 800 ailleurs. À vérifier au build/rendu pour éviter une synthèse de graisses incohérente.

### 4.2 Échelle typographique actuelle

Valeurs repérées dans `apps/web/src/app/globals.css` et `landing.css` (les tailles rem sont relatives à la base navigateur, 16 px) :

| Usage | Règle actuelle repérée |
|---|---|
| Texte courant | 16 px, interligne 1.55 |
| H1 applicatif | `clamp(1.3rem, 4.8vw, 2rem)`, interligne 1.15, poids 800, approche `-0.02em` |
| H2 applicatif | 1.05 rem, interligne 1.25, poids 800, approche `-0.01em` |
| H3 | 1 rem, interligne 1.3, poids 700 |
| Texte d’introduction `.lead` | 1.05 rem |
| H1 de la landing | `clamp(1.55rem, 6vw, 3rem)`, interligne 1.1, poids 800 |
| H2 de section landing | `clamp(1.25rem, 4.2vw, 2rem)`, interligne 1.15 |
| Petit corps et notices | variantes autour de 0.875–0.95 rem |
| Labels de formulaire | 0.8125 rem, poids 700 |
| Pastilles d’état | 0.75 rem, poids 700 |
| Codes / identifiants | JetBrains Mono ; code établissement en 1.6 rem, chasse augmentée |
| `eyebrow` / repères de section | JetBrains Mono, 11 px, capitales, approche `0.12em` |

**Point de vigilance typographique :** le défaut Unbounded est très caractérisé et s’étend au texte courant de l’application. Tester les paragraphes médicaux, formulaires, tableaux et libellés longs sur mobile avant de le conserver comme police de lecture. La landing simule également certains libellés à 7–10 px ; ne pas reprendre ces tailles minuscules pour l’interface réelle ou les visuels de communication accessibles.

### Proposition typographique

- **Famille principale proposée : Plus Jakarta Sans**, ou Manrope si les tests de lecture la préfèrent : une sans-sérif contemporaine mais sobre pour corps, formulaires, navigation et titres.
- Corps à viser : 16 px minimum dans les parcours de lecture, interligne confortable ; échelle de titres plus cohérente entre site public et espaces connectés.
- Utiliser des graisses réelles adaptées (corps 400, accent 600, titres 700/800) et réduire les capitales aux petits libellés secondaires.
- **JetBrains Mono uniquement** pour codes temporaires, horodatages/identifiants techniques et éléments qui bénéficient d’une chasse fixe.
- N’utiliser qu’une famille principale en production, même si les préférences personnelles sont maintenues. Documenter toutes les graisses, fallback et comportement hors ligne.

## 5. Formes, iconographie et composition observées

- Coins arrondis principaux : 10 px (petit), 16 px (moyen), 22 px (grand) et forme pilule ; certains boutons ont 14 px, champs 12 px, cartes 16 px et cartes marketing 22 px.
- Surfaces : fond pastel clair, cartes blanches bordées, teintes légères pour les sélections, ombre douce, boutons à hauteur tactile minimale 44 px.
- Iconographie produit : SVG 24 × 24, trait uniforme 1.8, terminaisons arrondies ; icônes maison, dossier, stéthoscope, partage, personne, verrou, carte, cœur, plus, établissement, lien, code QR, document, crayon, horloge, enveloppe, alerte, œil, etc.
- Quelques glyphes Unicode persistent dans la navigation et certains réglages ; les remplacer par le jeu d’icônes commun, en gardant les signes de marque et icônes métier bien distingués.
- Les codes à usage unique ont un rendu monospace ; les états d’accès et de provenance utilisent des badges colorés avec points.
- Mobile : navigation à cinq onglets (« Accueil », « Carnet », « Consult. », « Accès », « Moi » pour patient ; les onglets changent selon le rôle). Desktop : rail latéral et en-tête.

### Direction d’illustration

Privilégier des schémas sobres de circulation de l’information : une personne tient son carnet, choisit le destinataire, autorise un périmètre, puis retrouve une ligne d’historique. Utiliser des gestes, repères et objets abstraits (page, onglet, trace, lien), plutôt qu’une photographie de blouse blanche, un stéthoscope cliché ou une imagerie biomédicale alarmante. Si des personnes sont représentées, varier les âges, genres et situations sans transformer l’Afrique de l’Ouest en décor exotique.

## 6. Direction de logo proposée

### Concept de travail : « la page que l’on choisit d’ouvrir »

Créer un symbole propriétaire qui combine subtilement :

- une **page / carnet** ou deux pages ouvertes, pour l’historique personnel ;
- un **repère ou onglet** qui s’ouvre, pour la décision du patient ;
- éventuellement une petite ligne ou un point de provenance, pour la trace.

Le signe doit rester lisible à 16 px et en monochrome. Éviter de se limiter au « + » médical générique, qui ne différencie pas le produit et peut être confondu avec une croix institutionnelle ; éviter aussi un bouclier dominant qui pourrait suggérer une certification de sécurité inexistante. Le symbole ne doit pas suggérer diagnostic, urgence ou validation officielle.

### Nom de marque à harmoniser

Proposition d’architecture de nom à faire arbitrer : **Mon Carnet Numérique** (nom long), **E‑Carnet** (nom court). Choisir une casse et une graphie uniques — « E‑Carnet » ou « e‑carnet » — et les appliquer partout. Ne pas mélanger les libellés tant que le porteur n’a pas arbitré.

### Livrables logo attendus

- logo horizontal avec nom long ; logo compact avec nom court ; symbole seul ;
- versions couleur, monochrome sombre, blanche/inversée et niveaux de gris ;
- fichiers vectoriels SVG propres et source éditable (AI/Figma/SVG) ; PNG transparents aux tailles utiles ;
- favicon, icône PWA/app et avatars sociaux ;
- règles de taille minimale, zone de protection, fonds autorisés et usages interdits ;
- variantes adaptées à l’en-tête, au pied de page, au QR/écran mobile, à l’impression et aux vidéos.

## 7. Direction motion design

Le mouvement doit expliquer un état ou une transition, pas faire croire qu’une donnée médicale est analysée, vérifiée ou synchronisée si ce n’est pas le cas.

### Micro-interactions produit suggérées

1. **Préparation** : progression discrète entre brouillon et clôture ; la provenance apparaît avec le libellé « déclaré par le patient ».
2. **Demande d’accès** : arrivée d’une demande sous forme de carte ; mettre professionnel, établissement, périmètre et durée au premier plan.
3. **Choix du patient** : transition visuelle nette et neutre entre autoriser/refuser ; ne pas employer d’animation valorisant un choix plutôt que l’autre.
4. **QR** : affichage propre du code, compteur/heure d’expiration à 5 min et bouton masquer ; pas de pulsation ou effet de scan qui fasse croire à un accès déjà accordé.
5. **Accès actif / révoqué** : changement de badge, de durée et de disponibilité des actions, avec libellé et couleur sémantique cohérents.
6. **Historique** : ligne chronologique simple qui ajoute une action datée sans animation spectaculaire.
7. **Fin du rattachement** : état irréversible à présenter avec une hiérarchie claire et un récapitulatif de l’effet sur les accès futurs et l’historique existant.

### Garde-fous motion

- Micro-transitions courtes et utilitaires (environ 120–200 ms comme point de départ à tester), pas d’animation décorative en boucle.
- Respecter `prefers-reduced-motion`, déjà partiellement pris en charge par les styles CSS ; fournir une variante sans mouvement et éviter parallaxe/zoom automatique.
- Éviter flash, clignotement, urgence visuelle et rouge en décoration ; réserver danger/refus aux états concernés.
- Ne jamais utiliser un mouvement seul pour transmettre accord, statut, danger, validation ou expiration : libellé et structure accessibles indispensables.
- Éviter les animations de données cliniques, dossiers qui s’ouvrent automatiquement, battements cardiaques ou scan suggérant que l’app « comprend » un examen.

### Livrables motion attendus

- principes de mouvement (durées, courbes, distances, règles d’arrêt/réduction) ;
- prototypes de transitions du flux d’accès patient et du flux QR ;
- micro-animations facultatives de chargement, feedback et changement d’état ;
- animation de logo facultative, utilisable en boucle courte seulement si elle reste calme et lisible sans son ;
- exports Lottie/SVG/vidéo selon l’usage, ainsi que versions réduites et statiques.

## 8. Écrans à traiter en priorité par le designer

1. **Landing et identité publique** : hiérarchie du message, statut de pilote, nom/logo, liens d’information.
2. **Patient mobile** : accueil, déclaration, pré-consultation, historique, demande d’accès à examiner, QR, autoriser/refuser/prolonger/révoquer.
3. **Professionnel mobile** : profil déclaratif, rattachement à établissement, demande d’accès, consultation et historique.
4. **Administrateur établissement** : code unique, demande en attente, acceptation/refus, équipe et fin de rattachement ; séparation évidente entre données administratives et dossiers cliniques.
5. **États transversaux** : vide, chargement, erreur, hors réseau, session expirée, refus, expiration, révoqué, succès, confirmation d’action importante.
6. **Onboarding et connexion** : identité, choix du contexte, formulaires conditionnels, authentification e-mail et fournisseurs sociaux.

Pour les maquettes, suivre les parcours actifs décrits dans `docs/ROADMAP-V1-V5.md`, `docs/QUESTIONNAIRE-DECISIONS-A1-A16.md` et `docs/FLOW-ETABLISSEMENT.md`, pas les anciens flows des prototypes.

## 9. Exigences de livraison et accessibilité

- Tokens nommés par rôle (surface, encre, accent, bordure, focus, statut) plutôt que des hex dispersés.
- Contrastes à mesurer sur les couleurs **résolues et réellement affichées**, y compris états hover/disabled, focus, badges, champs et texte secondaire. Les notes de code ne remplacent pas un test d’accessibilité.
- Aucun statut transmis uniquement par couleur ; textes, icône/forme et ordre de lecture cohérents.
- Cibles tactiles d’au moins 44 px ; focus clavier visible ; erreurs annoncées et reliées aux champs ; navigation lecteur d’écran et zoom à tester.
- Tailles de texte adaptées à la lecture sur petit écran ; éviter les labels de 7–11 px repérés dans la maquette téléphone marketing pour l’interface réelle.
- Fournir une planche de marque, guide d’usage, mini design system (couleur, typo, iconographie, formes, états, espacements) et composants Figma ; identifier clairement les éléments décoratifs et les interactions.
- Tester au minimum sur écrans mobiles étroits et larges, tablette et desktop ; livrer des exports compressés et adaptés PWA/web.

## 10. Proposition de direction en résumé

> **Une identité chaleureuse, calme et nette : le carnet comme espace personnel, le vert sauge comme repère de soin, l’encre profonde pour la confiance, une typographie sans-sérif extrêmement lisible et des animations discrètes qui montrent le choix et la traçabilité sans simuler une certification.**

Le système doit d’abord clarifier l’usage avant d’ajouter une « couche graphique ». La bonne direction est celle qui rend immédiatement visibles : **qui demande**, **à quel établissement**, **quelles données**, **pour combien de temps**, **ce que le patient décide**, et **où retrouver la trace**.

### Fichiers sources visuels consultés

- `packages/ui/src/styles/tokens.css`
- `packages/ui/src/themes.ts`
- `apps/api/apps/identity/theme.py`
- `apps/web/src/app/globals.css`
- `apps/web/src/app/landing.css`
- `apps/web/src/app/layout.tsx`
- `apps/web/src/components/ui/Icon.tsx`
- `apps/web/src/components/ThemeSettingsClient.tsx`
- `docs/prototypes/README.md`, `docs/prototypes/ARCHITECTURE.md`, `docs/prototypes/themes.ts`, `docs/prototypes/tokens.css`
