# Mon Carnet Numérique — V1 en construction

Monorepo d’une application web/PWA mobile-first : Next.js 16, API Django/DRF et PostgreSQL cible.

> **Statut actuel : V1 en construction, non acceptée et non autorisée pour des données de santé réelles.**
> Le code fonctionnel est validé localement, mais le verdict staging/production reste **NO-GO** tant que PostgreSQL réel, la restauration, le staging et les validations produit/sécurité ne sont pas signés.

## État vérifié le 05/10/2026

- `npm run test:api` : **57 tests OK, 1 ignoré** ; l’ignoré concerne la concurrence non démontrable sous SQLite.
- `npm run check:api` : OK.
- `python manage.py makemigrations --check --dry-run` : OK, aucune migration manquante.
- `npm run lint` : aucune erreur ; deux avertissements non bloquants sur les avatars distants en `<img>`.
- `npm run build` : OK, **27 routes** générées.
- Smoke Chromium mobile/accessibilité local : **6 routes OK** pour landmark `<main>`, langue française et `alt`.
- `npm ci` : **5 vulnérabilités high** signalées dans l’arbre npm ; à traiter avant publication.
- Authlib signale que `authlib.jose` est déprécié au profit de `joserfc`.
- PostgreSQL réel, Docker runtime, sauvegarde/restauration et staging : **non vérifiables dans le sandbox courant**, Docker étant indisponible.

Le rapport consolidé est [l’état réel V1](docs/ETAT-REEL-V1.md) et le verdict de recette est [le rapport Go/No-Go](docs/GO-NO-GO-2026-10-05.md).

## Fonctionnalités présentes

- Compte unique, sessions serveur, CSRF/CORS et Argon2id.
- Authentification email/mot de passe et parcours OAuth Google/Facebook/Apple : callbacks, retour UI, liaison/déliaison explicite, conflit email sans fusion silencieuse et audit.
- Onboarding en trois étapes : identité/nom/avatar URL éditable, choix Patient/Professionnel, formulaire métier conditionnel.
- Profil patient, déclarations, pré-consultation, historique et consultation.
- AccessGrant : consentement, scopes V1, expiration serveur de 2 h, deux prolongations d’1 h et révocation.
- QR opaque, hashé, à usage unique, valable **5 minutes** ; scopes par défaut `preconsultation` + `declarations`, `consultations` sélectionnable, `documents` hors V1.
- Invitations établissement via transport SMTP Django configurable ; token brut limité au mode `DEBUG=true` local.
- Établissement privé : routes staff, administrateur nominatif historisé, invitation 48 h, code médecin 48 h à usage unique, demande `pending`, acceptation/refus et isolation.
- Audit applicatif, PWA et pages web des espaces principaux.
- Sanitation SVG par allowlist stricte : primitives de dessin uniquement, sans script/CSS/URL externe/DTD/média/namespace non autorisé.
- Scripts de recette PostgreSQL/restauration/staging et smoke mobile/accessibilité livrés.

## Ce qui bloque encore la V1

1. Exécuter les tests sur PostgreSQL réel, notamment concurrence, trigger append-only, permissions et isolation A/B.
2. Produire une sauvegarde/restauration isolée et mesurer le RPO/RTO approuvé.
3. Configurer et recetter un staging réel : domaines, HTTPS, SMTP, SPF/DKIM/DMARC, OAuth, cookies/CSRF et données synthétiques.
4. Rejouer les parcours Android/iOS/4G, QR mobile et accessibilité WCAG 2.2 AA complète ; le smoke Chromium local ne vaut pas certification.
5. Traiter les vulnérabilités npm high et migrer `authlib.jose` vers `joserfc` avec tests JWT Apple.
6. Obtenir les validations médicales, juridiques, hébergement ivoirien, conservation, incidents et stockage privé.
7. Faire signer la matrice de recette CA-01 à CA-24 et remplacer le verdict **NO-GO** par **GO** ou **GO CONDITIONNEL**.

Tant que ces points ne sont pas prouvés et validés, utiliser uniquement des données synthétiques `example.test`.

## Documentation de référence

- [État réel V1](docs/ETAT-REEL-V1.md)
- [Rapport Go/No-Go](docs/GO-NO-GO-2026-10-05.md)
- [Décisions produit et cahier de charge A1–A16](docs/QUESTIONNAIRE-DECISIONS-A1-A16.md)
- [Roadmap produit V1–V5](docs/ROADMAP-V1-V5.md)
- [Plan d’implémentation V1](docs/V1-PLAN.md)
- [Matrice de recette V1](docs/RECETTE-V1.md)
- [Flow établissement](docs/FLOW-ETABLISSEMENT.md) · [ADR-002](docs/adr/ADR-002-etablissement-invitation-et-rattachement.md)
- [Audit détaillé](RAPPORT-AUDIT-ECARNET.md)
- [Sécurité](docs/SECURITY.md) · [Déploiement](docs/DEPLOYMENT.md)
- [Récapitulatif d’implémentation](IMPLEMENTATION-DECISIONS-2026-10-05.md)

## Démarrer en local

Prérequis : Node.js 22+, npm 10+, Python 3.12+, Docker Engine et Docker Compose v2 pour la pile PostgreSQL complète.

```bash
cp .env.example .env
# Remplacer les secrets de développement par des valeurs aléatoires locales.
docker compose up --build
```

- Web : <http://localhost:3000>
- API liveness : <http://localhost:8000/api/v1/health/live/>
- API readiness : <http://localhost:8000/api/v1/health/ready/>
- PostgreSQL local : `localhost:5432`

Les services sont liés à `127.0.0.1`. `docker compose down -v` efface les données fictives du volume local.

## Contrôles

```bash
npm ci
npm run test:api
npm run check:api
(cd apps/api && python manage.py makemigrations --check --dry-run)
npm run lint
npm run build

# Après démarrage du web local
ops/accessibility-mobile-smoke.sh http://127.0.0.1:3000

# Sur un runner avec Docker/PostgreSQL
ops/staging-gates.sh reports/staging-gates-current.txt
```

Pour l’API hors Docker, utiliser un environnement virtuel Python et installer `apps/api/requirements.txt`.

## Sécurité des données

Développement, staging et pilote n’utilisent que des données fictives (`example.test`). Toute donnée réelle reste bloquée tant que l’hébergement ivoirien, les avis juridique/médical, le stockage privé, la sécurité SVG, le plan d’incident, la restauration testée et les gates Go/No-Go ne sont pas validés.
