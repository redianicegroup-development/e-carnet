# Vérification des constats — `e-carnet2.zip`

**Périmètre initial :** revue statique de l’archive fournie. **Mise à jour du 08/10/2026 :** code et tests modifiés pour les points explicitement traités ci-dessous; revalidation sur PostgreSQL 16 local.

## Conclusion

Sur l’archive initiale, les constats **1 à 6 étaient confirmés**, avec une nuance sur le point 5. Le tableau ci-dessous reflète maintenant l’état après patch : CA‑13 et CA‑19 sont corrigés localement; l’audit des lectures est partiellement corrigé. Les problèmes QR, OAuth et les autres constats explicitement listés comme ouverts restent à traiter.

La suite de tests Django passe (**75 tests, 1 ignoré**), mais elle ne couvre pas les scénarios d’entrelacement, de lecture inter-établissements des pré-consultations, de lecture clinique auditée, de `TRUNCATE` PostgreSQL ni les principaux cas OAuth relevés. Ce résultat vert n’invalide donc pas les constats.

**Avis :** ne pas exposer cette version à des données cliniques réelles avant correction et tests de régression sur PostgreSQL.

## Constats détaillés sur l’archive initiale — avant correctifs

| # | Constat | Verdict | Priorité |
|---|---|---|---|
| 1 | Lecture de pré-consultations d’un autre établissement (CA-19) | **Corrigé localement — provenance établissement et filtre A/B testés** | P1 — revalider staging |
| 2 | Révocation perdue face à une prolongation concurrente (CA-13) | **Corrigé localement — verrou de ligne et test concurrent PostgreSQL** | P1 — revalider staging |
| 3 | Contraintes SQL manquantes sur AccessGrant | **Confirmé** | P1 |
| 4 | Audit des lectures et protection contre TRUNCATE | **Partiellement corrigé — lectures cliniques journalisées; TRUNCATE reste à protéger** | P1 ouvert |
| 5 | Expiration des demandes, nouvelle demande après refus, choix du scope | **Confirmé** | P1 (consentement), P2 (cycle de vie) |
| 6 | ID interne entier et email de connexion sensible à la casse | **Confirmé** | P2 |
| — | Modèle de confiance « l’établissement atteste le médecin » | **Partiellement documenté, implémentation/UI incohérentes** | P1 avant pilote |
| — | QR : UUID obligatoire en plus du jeton | **Confirmé** | P1 pour le parcours QR annoncé |
| — | OAuth : rôle par défaut, email non vérifié, PKCE absent | **Confirmé** (rôle à valider contre le parcours voulu) | P1 |

### 1. CA-19 — fuite de pré-consultations entre établissements

`CareEncounter` ne porte aucune clé étrangère vers un établissement (`apps/api/apps/care/models.py:9-24`); le commentaire précise même que ce lien est reporté. Dans `ProfessionalAuthorizedEncounterListView`, le serveur vérifie correctement que l’autorisation appartient au professionnel et à son établissement actif (`views.py:210-215`), mais charge ensuite **toutes** les pré-consultations clôturées du patient (`views.py:216`). Le filtre ne lie donc pas les dossiers à l’établissement du grant.

Un professionnel autorisé par B peut ainsi récupérer une pré-consultation du même patient saisie dans le contexte de A. `facility_label` est un libellé libre, pas une relation autoritative. La recette CA-19 (`docs/RECETTE-V1.md:29`) dit « tests backend présents », mais le test `test_professional_context_cannot_read_other_establishment_data` (`apps/api/apps/care/tests.py:120-138`) vérifie qu’un grant de A n’est pas consultable lorsque B est actif; il ne vérifie pas une pré-consultation de A accessible au moyen d’un grant valide de B. Le test de lecture (`tests.py:220-235`) n’utilise qu’un seul établissement.

**Correction attendue :** ajouter une provenance établissement fiable aux éléments cliniques et filtrer en base sur le périmètre autorisé, ou formaliser explicitement que les éléments patients sont partageables entre établissements après consentement — mais alors corriger la recette et le consentement affiché. Ajouter un test A/B qui crée réellement une pré-consultation de A, un grant valide de B pour le même patient, et exige que cette pré-consultation ne soit jamais renvoyée.

### 2. CA-13 — révocation écrasable par `extend`

`PatientAccessGrantActionView.post` charge l’objet sans `select_for_update`, change des champs en mémoire, puis exécute `item.save()` (`apps/api/apps/care/views.py:111-134`). Cette vue ne déclare pas de transaction englobante. Deux requêtes ayant lu `active` peuvent donc toutes deux poursuivre : la prolongation sauvegarde un objet dont le statut en mémoire est `active`, et peut réécrire ce statut après le `revoke`. Cela correspond à l’entrelacement décrit.

Le test existant fait `accept`, `extend`, puis `revoke` de manière séquentielle (`apps/api/apps/care/tests.py:25-47`); il ne modélise pas la course. `refresh_expiration()` est atomique, mais cela ne verrouille pas la séquence complète de décision et sauvegarde de cette vue.

**Correction attendue :** transaction englobante et chargement `select_for_update()` de l’AccessGrant avant de vérifier l’état et appliquer la transition; mettre à jour seulement les champs pertinents, puis tester les ordres `revoke/extend` concurrents sur PostgreSQL. Le statut révoqué doit être terminal pour une prolongation déjà en vol.

### 3. Contraintes de base AccessGrant

Les deux clés étrangères sont nullable et `blank=True` dans le modèle (`apps/api/apps/care/models.py:35-45`); la migration les crée également avec `null=True` (`apps/api/apps/care/migrations/0003_accessgrant_establishment_accessgrant_professional.py:16-25`). Aucun `UniqueConstraint` n’est défini dans `Meta` (`models.py:52-54`).

La prévention des doublons est uniquement applicative (`apps/api/apps/care/services.py:53-55`): un `exists/first` suivi d’un insert ne protège pas contre deux demandes simultanées. Il n’existe donc pas de garantie SQL contre les demandes ouvertes en double, et la base accepte des grants sans professionnel ou établissement.

**Correction attendue :** rendre `professional` et `establishment` non nullables après migration/nettoyage des données; ajouter une contrainte d’unicité conditionnelle correspondant exactement à la définition d’une demande ouverte (probablement `pending` et `active`, par patient/professionnel/établissement). Ajouter un test concurrent et traiter explicitement la violation d’unicité en réponse API.

### 4. INV-09 — audit des lectures et immutabilité

Les endpoints de lecture clinique ne créent pas d’événement : la lecture des pré-consultations répond directement (`views.py:205-217`) et la liste des consultations aussi (`views.py:177-183`). L’audit patient ne renvoie que les événements dont le type commence par `access_grant.` (`views.py:85-108`). La lecture clinique produit donc zéro événement visible au patient.

La migration PostgreSQL installe un trigger `BEFORE UPDATE OR DELETE` **par ligne** (`apps/api/apps/audit/migrations/0002_auditevent_append_only.py:19-23`). Elle ne définit pas de trigger `TRUNCATE` (trigger distinct au niveau statement); les protections du modèle Django (`apps/api/apps/audit/models.py:7-16,37-44`) ne protègent pas contre du SQL direct. Un rôle DB ayant les droits adéquats peut donc tronquer la table en autocommit/hors transaction explicite. Le document de sécurité précise déjà que le trigger doit être vérifié sur PostgreSQL (`docs/SECURITY.md:13,35`), et la recette ne demande que UPDATE/DELETE (`docs/RECETTE-V1.md:28`).

**Correction attendue :** enregistrer chaque lecture clinique autorisée (acteur, patient, établissement, ressource, horodatage, décision), y compris les réponses vides si elles représentent une consultation du dossier; l’exposer au patient. Compléter la stratégie PostgreSQL avec un trigger `BEFORE TRUNCATE` et des privilèges séparant le rôle applicatif du propriétaire/migrateur; tester que le rôle runtime ne peut ni supprimer ni tronquer l’audit. Un trigger ne peut pas protéger contre un superuser/propriétaire malveillant : cette limite doit être documentée.

### 5. Demandes non expirantes et consentement insuffisamment ajustable

Aucun champ ne représente l’expiration d’une demande `pending` (`models.py:45-50`), et le chemin `accept` ne vérifie que `status == "pending"` avant activation (`views.py:118-120`). Une demande datant de 90 jours peut donc être acceptée.

La recherche des doublons exclut `refused` (`services.py:53-55`), donc un nouveau grant est immédiatement créable après refus. Enfin, le scope est fourni par le professionnel lors de la création (`services.py:50-62`); l’action patient d’acceptation ne lit aucun périmètre dans le corps de la requête (`views.py:113-134`). L’UI affiche le scope et la durée, mais ne permet que « Autoriser 2 h » ou « Refuser » (`apps/web/src/components/PatientAccessGrants.tsx:163-169`). Le patient ne peut donc pas réduire le périmètre avant d’accepter.

**Correction attendue :** définir une échéance courte pour les demandes en attente et refuser/expirer atomiquement toute acceptation tardive; décider d’un délai ou d’une règle de nouvelle demande après refus; permettre au patient de choisir/réduire les scopes, puis persister et auditer le scope effectivement consenti.

### 6. Compte et email

Aucun `AUTH_USER_MODEL` personnalisé n’est défini dans `apps/api/config/settings.py`; le projet utilise donc `auth.User`, dont la clé primaire est entière. `/me` expose explicitement `id` comme `IntegerField` (`apps/api/apps/identity/auth_serializers.py:33-35`), d’où l’ID tel que `1`. Les profils métier peuvent avoir des UUID, mais cela ne change pas l’identifiant du compte.

À l’inscription, l’adresse est convertie en minuscules (`auth_serializers.py:15-18`). À la connexion, `LoginSerializer` valide le format mais ne normalise pas l’adresse (`auth_serializers.py:28-30`), puis `LoginView` transmet exactement la valeur saisie comme nom d’utilisateur (`apps/api/apps/identity/auth_views.py:29-37`). Avec un compte enregistré sous `foo@example.com`, la saisie `Foo@Example.com` échoue sur le backend Django standard.

**Correction attendue :** normaliser la valeur de connexion avant l’authentification et ajouter un test de casse. Pour l’ID UUID, si cette exigence est maintenue, planifier un vrai modèle utilisateur UUID et une migration de toutes les références; ne pas remplacer seulement le champ de réponse `/me` par une valeur différente sans contrat stable.

### Modèle de confiance établissement/médecin

Le choix produit est déjà exprimé dans `docs/adr/ADR-002-etablissement-invitation-et-rattachement.md:14-21` : E‑Carnet vérifie les preuves de l’établissement; l’établissement vérifie le médecin en interne; l’approbation du rattachement constitue l’attestation institutionnelle pour cette structure, distincte du consentement patient. `docs/SECURITY.md:11,23` le mentionne également. Il serait donc inexact de dire que rien n’est documenté.

Mais l’UI n’est pas alignée : `apps/web/src/components/ProfessionalAccess.tsx:26,36-51` exige encore `verification_status === "verified"`, affirme que l’équipe E‑Carnet vérifie le médecin et bloque le code d’affiliation tant que ce statut n’est pas validé. Le modèle conserve également ce statut (`apps/api/apps/professionals/models.py:8-16`), tandis que le garde clinique réel ne le vérifie pas (`apps/api/apps/professionals/access.py:4-22`). Cela crée deux modèles d’assurance différents entre la documentation, l’interface et l’accès serveur.

**À faire :** documenter explicitement la chaîne de confiance et ses limites (qui vérifie quoi, preuves structure, procédure locale de contrôle professionnel, responsabilité et révocation); harmoniser le parcours UI/API en retirant le gate et les affirmations d’une vérification médicale par E‑Carnet si l’approbation de l’établissement est désormais la seule attestation; conserver un statut technique seulement s’il a une sémantique distincte et non bloquante clairement définie.

### QR — UUID obligatoire malgré le jeton

La route réellement montée pour `/professionnel/patients` utilise `ProfessionalAccessGrants` (`apps/web/src/app/professionnel/patients/page.tsx:1-8`). Elle comprend un scanner ZXing, mais conserve un champ UUID obligatoire et désactive l’envoi si `patientId` est vide (`apps/web/src/components/ProfessionalAccessGrants.tsx:31-36,53-60,76`). L’API sait pourtant résoudre le patient à partir du seul `qr_token` (`apps/api/apps/care/services.py:40-49,56-66`). Le patient est donc forcé de communiquer aussi son UUID, ce qui contredit la propriété de porte d’entrée QR seule. En outre, le jeton actuel est un jeton opaque long (`secrets.token_urlsafe(32)`), pas un code court mémorisable.

**Correction attendue :** rendre l’UUID optionnel puis supprimer le champ si le QR doit être l’unique entrée; envoyer seulement le jeton scanné/saisi et faire résoudre le patient côté serveur. Si le produit veut un code court au lieu du jeton long, concevoir un code à forte entropie, à durée très courte, usage unique, limité en débit et non énumérable; ne pas simplement raccourcir le jeton.

### OAuth

- **Choix du rôle :** sur un callback sans compte existant, le serveur crée automatiquement un `AccountContext(role="patient", is_active=True)` (`apps/api/apps/identity/oauth_views.py:93-101`) puis connecte le compte; l’étape de choix de contexte n’est pas appelée. L’inscription email fait elle aussi ce défaut patient (`auth_serializers.py:19-25`). Si l’étape 2 est censée être obligatoire pour tous, elle est contournée par les deux voies, pas seulement OAuth.
- **Email vérifié :** `external_profile()` ne conserve/contrôle aucun indicateur `email_verified` (`oauth_views.py:37-48`); le callback utilise l’email reçu pour rechercher/créer un compte (`oauth_views.py:94-102`). Le code ne prouve donc pas que l’adresse est vérifiée avant d’en faire une clé de rapprochement/identité. Ne pas fusionner un compte existant automatiquement est une protection utile, mais ne remplace pas une vérification explicite du claim du fournisseur.
- **PKCE Google :** la requête d’autorisation envoie `state` mais ni `code_challenge` ni `code_challenge_method` (`oauth_views.py:63-68`); l’échange de code ne transmet pas de `code_verifier` (`oauth_views.py:77-80`). PKCE est absent.

**Correction attendue :** imposer le choix de rôle/contexte avant d’activer un contexte si le parcours le requiert; vérifier les claims d’email vérifié par fournisseur et refuser ou retarder la création/liaison sans preuve; implémenter PKCE S256 avec un verifier stocké en session à usage unique, et tests pour replay/absence de claims. Revoir les chemins Apple/Facebook/Google séparément, car leurs mécanismes de vérification diffèrent.

## Mise à jour des correctifs — 08/10/2026

Les corrections suivantes sont présentes dans le code et couvertes par les tests locaux :

- **CA‑19 :** chaque nouvelle pré-consultation a un établissement FK choisi par le patient; `facility_label` provient du registre serveur. La lecture requiert un grant actif et filtre sur le même établissement. Une tentative de valider une pré-consultation d’A via un grant de B échoue. Les lignes historiques `establishment=NULL` restent visibles par leur patient, mais ne sont pas partagées aux médecins (fail closed).
- **CA‑13 :** les actions accept/extend/revoke sont atomisées et verrouillent la ligne AccessGrant PostgreSQL. Un test à deux requêtes concurrentes vérifie que `revoke` demeure terminal.
- **Audit clinique :** lecture pré-consultation/consultation auditée et exposée au patient avec établissement/ressource/compte seulement; aucun texte médical dans les métadonnées. La protection `TRUNCATE` et les privilèges du rôle runtime demeurent ouverts.
- **Périmètre professionnel :** le parcours ne demande ni n’émet de numéro professionnel. La spécialité est déclarative, sélectionnée dans un catalogue; « Autre » ajoute une option réutilisable. L’établissement effectue ses vérifications en interne; E‑Carnet enregistre seulement la décision de rattachement. La colonne legacy `professional_identifier` n’est pas supprimée automatiquement afin d’éviter la perte implicite d’anciennes données; sa rétention/purge doit être décidée avant déploiement.

**Encore ouverts :** contraintes SQL AccessGrant (constat 3), expiration/re-demande/scope (5), identifiant interne et casse e-mail (6), flow QR (UUID obligatoire), OAuth (claims email vérifiés et PKCE), protection audit contre `TRUNCATE`, recette staging et décisions juridiques/rétention. Les correctifs locaux ne sont pas une certification ni une autorisation de charger des données réelles.

## Vérification exécutée

- Commande : `python manage.py test` dans l’API de l’archive, avec les dépendances déclarées dans `apps/api/requirements.txt` installées dans un virtualenv local.
- Vérification initiale de l’archive : **75 tests, 1 ignoré** sur SQLite. Après corrections, suite complète : **80 tests réussis sur PostgreSQL 16 local**, dont concurrence/rattachement inter-sites; avertissement Authlib `authlib.jose` toujours présent.
- Portée : tests locaux sur SQLite. Ils ne constituent pas une validation PostgreSQL, une recette staging ni une preuve de concurrence HTTP.
