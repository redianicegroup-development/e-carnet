# Sécurité — état du dépôt au 08/10/2026

Ce document décrit le code et ses limites. Il ne constitue ni une certification, ni une garantie de conformité, ni un audit indépendant.

## Contrôles présents

- **Données :** développement, tests, captures et pilote utilisent des données fictives. Aucune donnée clinique réelle avant les validations et le Go/No-Go.
- **Sessions :** session serveur Django; cookie de session HttpOnly, Secure hors DEBUG; CSRF/CORS configurés; aucun JWT dans `localStorage`.
- **Mots de passe :** `argon2-cffi` est déclaré et `Argon2PasswordHasher` est le premier `PASSWORD_HASHERS`; PBKDF2 reste dans la liste pour vérification/mise à niveau de comptes existants. Recetter la migration et la configuration en staging.
- **OAuth :** callbacks Google/Facebook/Apple et `AuthIdentity` présents; état OAuth par session; unicité `(provider, provider_user_id)` et `(user, provider)`; conflit e-mail traité sans fusion silencieuse. Les secrets fournisseurs sont absents ou placeholders dans l’archive. Le flow de liaison n’a pas de page d’administration utilisateur, l’audit et les tests fournisseurs restent à compléter. Apple dépend de credentials valides Apple Developer.
- **Accès clinique actuel :** l’API requiert contexte professionnel actif, établissement actif, membership active dans la structure sélectionnée et AccessGrant patient actif/consenti. Il n’existe plus de gate global E‑Carnet de vérification du médecin. Le statut/rôle et la spécialité sont déclaratifs; l’établissement vérifie en interne et l’application enregistre sa décision de rattachement.
- **QR :** le code serveur produit un jeton opaque, n’enregistre que son SHA-256, limite l’usage à une consommation et applique une expiration de 5 min. Les 5 minutes sont la durée produit V1 ; l’UI QR/scan est livrée localement et reste à recetter sur mobile/staging.
- **Audit :** acceptation/refus/prolongation/révocation du consentement et lecture autorisée des pré-consultations/consultations génèrent des événements minimisés visibles au patient. Les lectures sont limitées au même établissement que l’AccessGrant. Le trigger PostgreSQL UPDATE/DELETE existe; CA‑13 est verrouillé en transaction et couvert par un test concurrent PostgreSQL. `TRUNCATE` et les privilèges runtime restent à régler et tester sur la cible.
- **PWA :** les API et espaces authentifiés ne doivent pas être mis en cache.
- **Secrets :** variables d’environnement; aucun secret de production dans le dépôt. `.env.example` est un exemple local, non une configuration sécurisée prête à déployer.

## Limites importantes — bloquantes avant exposition

- **SVG d’attestation :** le backend applique une allowlist stricte de primitives et attributs graphiques, refuse DTD/entités, scripts, CSS, médias, URL externes et namespaces non autorisés, puis sérialise, calcule un SHA-256 et conserve un horodatage. Les tests hostiles locaux passent ; le rendu et la recette staging restent à vérifier.
- **OAuth :** endpoints présents ne signifient pas que Google/Facebook/Apple sont activés en production. Il faut callbacks enregistrés, secrets réels, retours UI sûrs, liaison/déliaison accessible, audit et tests bout en bout. Aucune fusion automatique sur email.
- **Établissement :** compte nominatif, invitation hashée à usage unique/48 h et relation d’administration remplaçable présents côté API/UI. L’e-mail réel, le durcissement de la console et la recette production restent à faire ; l’accès admin établissement n’a pas de lecture clinique.
- **Invitation et code médecin :** token/code aléatoires hashés en base, expiration 48 h, consommation atomique unique et demande `pending` avant approbation sont présents. Le jeton brut ne figure jamais dans une réponse API ; le destinataire le reçoit uniquement par le lien e-mail. La configuration SMTP de staging et la délivrabilité/renvoi/révocation restent à valider. L’acceptation explicite des conditions de rattachement est versionnée et enregistrée avant consommation du code.
- **Vérification structure/médecin :** preuves structure reçues par e-mail et examinées hors application; pas de dépôt public. La vérification du médecin est effectuée en interne par l’établissement. Le formulaire/API médecin ne demande ni n’expose de numéro professionnel ou de justificatif. La colonne historique `professional_identifier` demeure en base uniquement pour éviter une suppression implicite de données lors du déploiement; définir une rétention et une purge contrôlée avant la mise en production.
- **MFA/TOTP :** décision produit = V3. Modèles, endpoints, seed et tests restent présents; le garde clinique n’exige pas le MFA. Nettoyer les écrans/textes et les scénarios V1 pour éviter de laisser croire qu’il est requis ou livré.
- **Scopes :** listes et défauts AccessGrant sont codés en constantes et pas encore approuvés (A9). Ne pas traiter le défaut actuel comme une règle validée.
- **Dépendances :** `npm ci` du 05/10/2026 signale cinq vulnérabilités high dans l’arbre d’outillage. Revue/correctif compatible requis avant publication; le build réussi ne supprime pas ces alertes.
- **Authlib :** usage d’`authlib.jose` émet un avertissement de dépréciation; prévoir migration vers `joserfc` et retester les JWT Apple.

## Contrôles qui restent à réaliser

1. OAuth réel par fournisseur et vérification Apple séparée.
2. Tests hostiles SVG et revue de sécurité.
3. Rate limits login, codes établissement, invitations, durée/rotation de session et cookies/CSRF sur les vrais domaines.
4. Tests inter-établissements A/B et révocation/prolongation simultanée sur PostgreSQL : couverts en local; répéter sur staging. Compléter les privilèges DB et le trigger TRUNCATE audit.
5. Staging, sauvegarde/restauration avec RPO/RTO approuvés, essais Android/4G et accessibilité.
6. Stockage privé, antivirus, rétention documentaire, purge des éventuels numéros historiques, procédure d’incident et revue juridique/médicale avant toute donnée réelle.
