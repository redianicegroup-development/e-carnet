# Architecture — Mon Carnet Numérique

**État audité : 05/10/2026.** L’application demeure en construction; ce document distingue l’architecture existante du modèle produit cible.

## Vue technique actuelle

```mermaid
flowchart LR
  B[Navigateur / PWA mobile] -->|HTTPS, session + CSRF| W[Next.js 16 / React 19]
  W -->|REST /api/v1| A[Django 5.2 / DRF]
  A --> DB[(PostgreSQL cible; SQLite tests locaux)]
  A --> FS[Stockage privé à compléter]
```

Monorepo : `apps/web` (Next.js App Router), `apps/api` (Django modulaire), `packages/ui` (tokens/thèmes), `docs/`, scripts `ops/`. Sessions serveur; cookies sécurisés hors DEBUG; aucun jeton JWT en `localStorage`. Les services Docker Compose sont pour le développement, pas une configuration production.

## Modèle d’identité et d’accès cible

- **Compte utilisateur unique** : identifiants e-mail/mot de passe et identités fournisseurs Google/Facebook/Apple dans `AuthIdentity`. La liaison doit être explicite après authentification; email identique seul ne fusionne pas les comptes.
- **Étape 1** : prénom, nom, avatar éditable; préremplissage du fournisseur possible.
- **Étape 2** : Patient ou Professionnel. Aucun choix public Root/Établissement.
- **Étape 3** : profil du contexte choisi.
- **Patient** : possède le carnet et accorde/refuse les AccessGrants.
- **Professionnel** : médecin avec compte propre. Les justificatifs professionnels ne sont pas collectés par E‑Carnet; l’établissement effectue sa vérification interne. Une demande de rattachement active après approbation établissement, et le médecin n’accède aux dossiers qu’avec consentement patient.
- **Établissement** : espace privé avec compte d’un administrateur nominatif, un seul actif en V1. L’entité établissement est indépendante de l’admin, qui peut être remplacé sans recréer l’entité. Pas de rôle global `root` et aucun accès clinique établissement.
- **Startup E‑Carnet** : vérification manuelle des preuves structure reçues par e-mail puis création de l’accès depuis une console staff privée. L’invitation nominative est unique, expire à 48 h et laisse le destinataire choisir son mot de passe.

Le code courant a désormais implémenté ces frontières : route publique neutralisée, console staff, administrateur nominatif historisé, invitation hashée à usage unique/48 h, code médecin hashé à usage unique/48 h, demande en attente et décision d’administrateur établissement. Les limites restantes sont la configuration SMTP de staging, la recette PostgreSQL/staging et la concurrence réelle. Voir [spécification du flow](FLOW-ETABLISSEMENT.md) et [ADR-002](adr/ADR-002-etablissement-invitation-et-rattachement.md).

## Modules backend principaux

`identity` (compte, sessions, OAuth, thème), `patients`, `establishments`, `professionals` (incluant résidus MFA), `care` (pré-consultation, AccessGrant, QR, consultation), `audit`, `health`. L’API contrôle les droits; les IDs reçus du navigateur ne remplacent pas le contexte serveur.

## Sécurité et état d’implémentation

- Argon2id configuré en premier hasher; à recetter sur comptes anciens et staging.
- OAuth callbacks/identités uniques présents; credentials fournisseurs et tests bout en bout restent à faire ; liaison, audit et retour UI sont présents.
- QR backend : jeton haché/opaque, usage unique, valeur d’expiration 300 s (5 minutes). Aucune UI de scan/génération livrée ; durée fixée à 5 minutes.
- Scopes AccessGrant : `preconsultation`, `declarations`, `consultations`; défaut `[preconsultation, declarations]`; `documents` est hors V1 (A9 décidé).
- Attestation : parse XML, allowlist stricte, hash et date ; tests adversariaux intégrés.
- TOTP/MFA : V3; les modèles/endpoints/seed historiques restent mais ne sont pas exigés par le garde clinique V1.
- Audit append-only/trigger présent dans le code; PostgreSQL réel non vérifié.
- Le flow d’invitation, le code d’affiliation et l’UI QR sont implémentés côté API/UI ; **le transport SMTP est configurable** et le jeton d’invitation n’est jamais renvoyé dans les réponses API.
- Les pièces de la structure sont vérifiées hors application; les documents personnels du médecin ne sont pas stockés par E‑Carnet. La politique de conservation de la boîte e-mail officielle reste à définir. Le médecin accepte les conditions versionnées avant consommation du code; l’établissement ou le médecin peut terminer un rattachement sans supprimer son historique.

## Direction UI

Les prototypes HTML (320×660 environ) sont des références de **design**, non des références de flows. Reprendre l’expérience mobile générale : navigation compacte, hiérarchie, densité, proportions, cartes et icônes cohérentes. Le front utilise encore certains glyphes Unicode comme icônes; le travail d’alignement mobile est à faire. Ne pas recopier les parcours obsolètes.

## Résultats de vérification locale

Le 05/10/2026 : 57 tests API Django OK et 1 ignoré, contrôles système, migrations, lint et build Next.js réussis; 27 routes générées. `npm ci` signale cinq vulnérabilités high dans l’arbre d’outillage; Authlib signale `authlib.jose` déprécié. Staging, PostgreSQL réel, Docker runtime, restauration et Android/4G restent non démontrés. Voir [audit](../RAPPORT-AUDIT-ECARNET.md), [sécurité](SECURITY.md) et [roadmap](ROADMAP-V1-V5.md).
