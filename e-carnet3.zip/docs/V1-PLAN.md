# Plan d’implémentation — V1 de Mon Carnet Numérique

**État au 05/10/2026 :** V1 en construction, non acceptée. La roadmap [V1–V5](ROADMAP-V1-V5.md) et les dernières décisions du porteur définissent désormais les parcours; les prototypes ne dictent que la direction visuelle mobile.

## Périmètre et règles

- Application mobile-first, comptes uniques; contexte public limité à Patient / Professionnel.
- L’établissement est privé, sans inscription publique, avec un administrateur nominatif (un seul actif en V1); pas de rôle global `root`. La structure envoie ses preuves par e-mail à E‑Carnet; staff vérifie puis crée le compte. Invitation unique 48 h, mot de passe choisi par le destinataire. Le médecin est vérifié en interne par la structure; aucun justificatif personnel ne remonte à E‑Carnet. Code médecin 48 h/une fois → demande en attente → approbation établissement.
- Aucun accès clinique espace établissement. Dossiers demandés/consultés par le professionnel après rattachement actif, établissement actif et consentement patient.
- OTP SMS et TOTP/MFA : V3, non prérequis V1. Aucun rôle ou endpoint infirmier autonome.
- Données fictives uniquement avant l’autorisation formelle de traitement réel.

## État des jalons

| Jalon | État du dépôt audité |
|---|---|
| 1. Socle | Présent : monorepo, Next.js/Django, sessions, CSRF, migrations, Docker Compose décrit. Docker/PostgreSQL runtime non vérifié dans cette passe. |
| 2. Identité/onboarding | Partiel : email, `AuthIdentity` et callbacks OAuth existent; onboarding identité/avatar → choix Patient/Professionnel → formulaire contextuel présent ; recette métier restante. Argon2id est configuré. |
| 3. Patient | Socle présent : profil, déclarations/provenance, pré-consultation, clôture, consultations et historique; recette terrain encore requise. |
| 4. Startup/administrateur établissement/professionnel | Implémenté côté API/UI : route publique neutralisée, console staff, administrateur nominatif, invitation 48 h, code médecin 48 h à usage unique et décision établissement. |
| 5. AccessGrant | Consentement, expiration 2 h, 2 prolongations d’1 h, révocation et audit présents. QR backend et UI génération/lecture livrés (jeton à usage unique, hash, 5 min); scopes A9 décidés : défaut pré-consultation + déclarations, consultations sélectionnable, documents hors V1. |
| 6. Consultation | Flux consultation présent; SVG parsé avec allowlist stricte, hash et horodatage; sanitizer robuste et tests hostiles présents. |
| 7. Public/PWA | Pages publiques, manifest, SEO et service worker présents; vérifier déploiement réel et éviter toute donnée privée mise en cache. |
| 8. Qualité/recette | 57 tests Django OK et 1 ignoré, `check`, migrations, lint et build réussis le 05/10/2026 (27 routes); staging, PostgreSQL réel, restauration/RPO-RTO, tests Android/4G et revue de dépendances restent à faire ; smoke Chromium local déjà passé. |

## Décisions produit confirmées

- Compte unique; liaison OAuth explicite sans fusion silencieuse.
- Fournisseurs voulus : e-mail/mot de passe, Google, Facebook et Apple (Apple soumis aux credentials Developer). OTP SMS reporté en V3.
- Onboarding en 3 étapes : identité de base/avatar éditable; choix Patient ou Professionnel; formulaire de rôle.
- Médecin : identité et profil nécessaires; pas d’upload de pièces personnelles à E‑Carnet. Vérification interne par l’établissement; code 48 h à usage unique crée une demande, puis l’établissement accepte/refuse.
- Startup reçoit les preuves structure par e-mail, vérifie via ses équipes et crée l’accès administrateur nominatif à partir d’une console privée. Pas de Root global. Invitation unique 48 h pour choisir le mot de passe; aucun secret transmis par e-mail.
- Un admin établissement actif par structure en V1; changement d’admin sans recréer la structure. Plusieurs admins éventuels plus tard.
- Conserver les événements et anciennes associations; suspension/révocation plutôt que suppression. L’espace établissement n’accède pas aux dossiers médicaux.
- MFA TOTP reporté en V3; résidus TOTP dans le code ne doivent pas être présentés comme requis V1.
- Prototypes : référence de design responsive/mobile seulement; anciens flows obsolètes ne sont pas à réintroduire.

## Points à terminer avant pilote

Le modèle et le flow établissement sont désormais présents dans l’archive. Les points ci-dessous sont les **finitions et preuves restantes**, et non des fonctionnalités entièrement absentes :

1. **Flow établissement :** SMTP configurable livré ; aucun token brut n’est retourné par l’API ; valider SMTP, le domaine, SPF/DKIM/DMARC et le parcours de réception en staging.
2. **Recette établissement :** exécuter les tests de concurrence, remplacement d’admin, refus/expiration et isolation sur PostgreSQL/staging.
3. **Onboarding :** implémentation identité/avatar et formulaires présents ; recetter la reprise de parcours et le métier en staging.
4. **OAuth :** callback, retour UI, liaison/déliaison et audit présents ; fournir les credentials, URLs et tests fournisseurs réels.
5. **QR/scopes :** génération/affichage patient et scan caméra ou saisie professionnelle livrés ; recetter A9 déjà décidé (5 min, scopes V1) sur mobile/staging.
6. **Sécurité :** sanitizer SVG strict et tests adversariaux présents ; rejouer le rendu en staging et maintenir TOTP hors des prérequis V1.
7. **Exploitation :** staging, PostgreSQL/trigger, sauvegarde-restauration/RPO-RTO, Android/4G, accessibilité, icônes/mobile et dépendances.
8. **Go/No-Go :** obtenir les validations médicales, juridiques et sécurité avant toute donnée réelle.

## Vérifications exécutées


Le 05/10/2026 dans cette archive : `npm run test:api` détecte 57 tests, dont 57 réussissent, aucun n’échoue et 1 est ignoré sous SQLite ; `check`, migrations, lint et build réussissent, avec 27 routes générées. `npm ci` remonte 5 vulnérabilités high et Authlib signale `authlib.jose` déprécié. Ce résultat n’est pas une recette staging ni un audit sécurité indépendant.
