# Recette V1 — matrice CA-01 à CA-24

**État audité : 05/10/2026.** La V1 n’est pas acceptée. Ce document sépare le code présent, les tests automatisés rejoués et les validations terrain/non exécutées. Les parcours ci-dessous suivent les décisions du porteur et [la roadmap](ROADMAP-V1-V5.md), pas les anciens flows des prototypes.

**Données de recette :** comptes, dossiers, identifiants, justificatifs et événements entièrement fictifs (`example.test`). Aucune donnée réelle.

## Matrice

| ID | Critère | État du dépôt | À faire / preuve manquante |
|---|---|---|---|
| CA-01 | Identité unique et méthodes sans doublon | **Présent localement.** Argon2id, `AuthIdentity`, callbacks, retour UI, liaison/déliaison, audit, unicité provider+ID et conflit e-mail sans fusion. | Credentials OAuth réels et tests bout en bout. OTP SMS est reporté en V3. |
| CA-02 | Établissement demande par e-mail | **Partiel.** La route publique de création est neutralisée (`403`) et l’UI indique le contact e-mail. | Formaliser l’adresse officielle, la réception/examen hors application et la politique de rétention des preuves. |
| CA-03 | Staff vérifie la structure et crée l’accès | **Présent côté API/UI.** Routes staff protégées, entité stable et administrateur nominatif historisé. | Recetter permission staff, remplacement admin, audit et staging. |
| CA-04 | Invitation sécurisée au responsable établissement | **Présent côté API/UI.** Token hashé, usage unique, expiration 48 h, activation et mot de passe choisi par le destinataire ; tests ciblés présents. | Brancher l’e-mail réel, ne plus retourner le token hors local et recetter renvoi/révocation. |
| CA-05 | Code médecin crée une demande, établissement décide | **Présent côté API/UI.** Code hashé, usage unique, expiration 48 h ; saisie atomique → `pending` ; acceptation/refus par l’administrateur établissement. | Recetter expiration, concurrence PostgreSQL, révocation/renvoi, audit et UX mobile. |
| CA-06 | Professionnel choisit établissement actif | **Présent côté API.** Membership active et structure active vérifiées. | Recette multi-établissement/staging et UX mobile. |
| CA-07 | Patient saisit pré-consultation, aide sans compte infirmier | **Socle présent.** Saisie dans compte patient et champ d’aide non authentifié; aucun rôle infirmier autonome. | Valider champs médicaux et essai mobile/clavier/réseau lent. |
| CA-08 | Clôture et correction traçable | **Partiel.** Clôture idempotente et snapshot/audit; édition après clôture refusée. | Addendum de correction post-clôture à finaliser et valider médicalement. |
| CA-09 | Demande d’accès in-app ou QR sans lecture avant consentement | **Présent localement.** Demande in-app et API/UI QR ; jeton opaque, hash, usage unique, 300 s. | Recette mobile/staging et concurrence PostgreSQL. |
| CA-10 | Patient voit professionnel, établissement, scopes, durée et consent | **Présent localement.** Accept/refus contrôlés serveur; historique visible; scopes A9 et durée 5 min exposés. | Tester compréhension/labels sur mobile staging. |
| CA-11 | Expiration AccessGrant à 2 h côté serveur | **Couvert par tests du dépôt.** | Recette à rejouer sur staging/PostgreSQL et horloge contrôlée. |
| CA-12 | Deux prolongations d’une heure, troisième refusée | **Couvert par tests du dépôt.** | Vérifier rendu et échéance sur mobile/staging. |
| CA-13 | Révocation immédiate | **Couvert par tests du dépôt.** | Test concurrence/session en staging. |
| CA-14 | Professionnel retrouve la pré-consultation autorisée | **Couvert par tests backend.** | Recette UI complète avec scope final et consentement. |
| CA-15 | Consultation, auteur et établissement imposés serveur | **Socle testé.** Consultation persistée; auteur/structure pris du contexte serveur. | Champs médicaux A10 et recette complète staging restent. |
| CA-16 | Consultation visible dans carnet avec provenance | **Socle présent/testé.** | Vérifier lisibilité et flux bout en bout mobile. |
| CA-17 | Attestation médicale protégée et tracée | **Présent localement.** SVG parsé et sanitationné par allowlist stricte ; hash SHA-256, horodatage et tests script/CSS/URL/DTD intégrés. | Rejouer le sanitizer strict en staging et vérifier le rendu de stockage; le workflow clinique exact reste à valider. |
| CA-18 | Événements sensibles audités et immuables | **Partiel.** Audit et trigger/mécanismes présents dans le dépôt. | Exécuter le trigger sur PostgreSQL réel, tester UPDATE/DELETE, revoir couverture/permissions. |
| CA-19 | Isolation entre établissements | **Tests backend présents dans l’archive.** | Compléter la matrice A/B sur PostgreSQL/staging, URLs/IDs remplacés et frontières entre admin établissement et professionnel. |
| CA-20 | Départ médecin conserve traces et bloque accès futurs | **Socle backend présent.** | Recette suspension/fin d’affiliation initiée par le médecin ou l’administrateur établissement, avec historique conservé, sur staging. |
| CA-21 | Pas d’accès clinique avant rattachement, établissement et consentement | **Contrôles backend présents** : contexte professionnel, établissement/membership actifs et AccessGrant patient consenti. TOTP reste V3 et n’est pas exigé. | Vérifier sur PostgreSQL/staging que l’espace établissement ne peut pas lire les dossiers. |
| CA-22 | Restauration réelle, RPO/RTO mesurés | **À exécuter.** Scripts existent. | Exécuter sur PostgreSQL/Docker, approuver seuils et joindre les preuves. |
| CA-23 | Parcours mobile/ordinateur et accessibilité | **Partiel.** Build et validation locale rapportée dans les artefacts; cette passe n’a pas rejoué un vrai navigateur avec API connectée. | Android réel/4G, parcours OAuth/onboarding/QR, lecteurs d’écran et essais terrain; icônes/composition mobile encore à aligner aux prototypes. |
| CA-24 | Aucun compte/écran/endpoint infirmier autonome | **Conforme dans le code inspecté.** | Maintenir tests de non-régression. |

## Contrôles locaux rejoués le 05/10/2026

```bash
npm ci
npm run test:api
npm run check:api
(cd apps/api && .venv/bin/python manage.py makemigrations --check --dry-run)
npm run lint
npm run build
```

Résultats : **57 tests Django OK et 1 ignoré**, check sans erreur, aucune migration manquante, lint sans erreur, build Next.js réussi avec **27 routes** ; smoke Chromium local OK sur 6 routes. `npm ci` remonte **5 vulnérabilités high** dans l’arbre d’outillage ; l’import `authlib.jose` émet une dépréciation. Ces contrôles ne prouvent pas le fonctionnement réel OAuth, staging, PostgreSQL/trigger, Docker runtime, restauration, Android/4G ou sanitation SVG contre des charges adverses.

## Décisions toujours bloquantes

- A9 : décision appliquée localement (QR 5 min ; pré-consultation + déclarations par défaut ; consultations sélectionnable ; documents hors V1) ; recetter l’UX mobile.
- A8/A10 : validation médicale des champs, unités et corrections.
- A11–A16 : rétention des preuves structure reçues par e-mail, stockage, conservation, droit local, incidents et hébergement. Aucun justificatif personnel médecin dans E‑Carnet.
- Tests requis : invitation 48 h/usage unique, code 48 h/usage unique, rejeu/concurrence, refus, remplacement admin, historique conservé et absence d’accès clinique établissement.

La V1 ne doit pas être déclarée terminée tant que CA-01 à CA-24 n’ont pas de preuves staging/mobile/ordinateur et que les validations professionnelles/médico-juridiques applicables ne sont pas documentées.


## Couverture spécialisée à ajouter

Les tests ciblés OAuth fournisseur réel, concurrence QR PostgreSQL et recette de rendu staging restent à exécuter. Les charges SVG hostiles sont maintenant couvertes localement par les tests de sanitation.
