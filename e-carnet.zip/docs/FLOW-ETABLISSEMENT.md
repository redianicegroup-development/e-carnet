# Flow établissement et rattachement médecin

**Décision du porteur : 05/10/2026 — version 2, après réponses aux points à confirmer.** Cette note est la référence métier pour l’accès établissement en V1. Le rôle « Root » global n’est pas retenu; on parle d’**administrateur établissement**.

## Résumé

L’établissement ne se crée pas son compte et ne téléverse pas ses justificatifs sur la landing page. Il contacte l’équipe E‑Carnet par e-mail et envoie les preuves demandées. L’équipe vérifie manuellement la structure, puis un administrateur E‑Carnet utilise une route interne protégée pour créer l’établissement et son accès nominatif. Le responsable reçoit un lien d’invitation à usage unique valable 48 heures et choisit lui-même son mot de passe. Depuis son espace privé, l’administrateur génère un code médecin temporaire (48 heures, usage unique). Le code initie une demande de rattachement; l’établissement doit ensuite accepter cette demande. Ni invitation ni code ne confèrent seuls un accès clinique.

## Parcours 1 — demande, vérification et accès de l’établissement

1. **Contact hors application :** l’hôpital/la clinique est invité à écrire à l’adresse officielle E‑Carnet et à envoyer les documents de la structure, son identité et celle de son responsable. La landing page ne propose ni création libre de compte établissement ni upload public de justificatifs.
2. **Contrôle interne :** l’équipe E‑Carnet examine l’existence de la structure, ses preuves légales, son identité et son responsable. Les preuves restent traitées dans le canal interne de l’équipe; la V1 ne les stocke pas dans l’espace web public. La règle de rétention et de sécurité de la boîte e-mail reste à formaliser.
3. **Action interne :** un administrateur E‑Carnet, authentifié et autorisé, ouvre la console privée, inscrit la décision (validation/refus) et, après validation seulement, lance **Créer l’accès**. Chaque action est attribuée à l’employé et horodatée.
4. **Compte nominatif :** l’établissement est une entité stable, séparée de la personne qui l’administre. En V1, un seul administrateur principal nominatif est activé par structure; aucun identifiant/mot de passe commun. L’association de l’administrateur peut être remplacée ultérieurement sans recréer l’établissement. Le modèle pourra accueillir d’autres administrateurs dans une version future, mais leur activation multiple est hors périmètre V1.
5. **Invitation :** le backend envoie un lien sécurisé lié à l’établissement et à l’adresse professionnelle nominative validée. Il est à usage unique et expire après **48 heures**. Le destinataire définit son mot de passe sur la page d’activation. Le mot de passe n’est jamais envoyé par e-mail; dès consommation ou expiration, le lien est inutilisable. Une invitation expirée exige une nouvelle émission par l’administration E‑Carnet.
6. **Espace privé :** après activation, l’administrateur se connecte à une route établissement authentifiée. Il peut gérer les codes et demandes d’affiliation, les informations de sa structure et les rattachements autorisés; il ne peut ni demander ni consulter les dossiers médicaux au titre de cette fonction.

## Parcours 2 — code et affiliation médecin

1. Le médecin possède déjà son compte **Professionnel** E‑Carnet et n’a pas besoin d’une identité séparée pour l’établissement.
2. L’administrateur établissement vérifie le médecin **en interne, entre la structure et le médecin**. E‑Carnet ne demande pas et ne collecte pas les justificatifs personnels/professionnels du médecin dans ce flow.
3. L’établissement génère un code aléatoire associé à sa structure : durée **48 heures**, usage unique. Le code est un moyen d’initier une demande, pas une preuve d’accès direct; il ne révèle aucune donnée clinique. Stocker sa valeur sous forme de hash, permettre son expiration/révocation et ne pas l’écrire dans les logs.
4. Le médecin saisit le code dans son espace Professionnel. Le backend le consomme une seule fois et crée une **demande de rattachement `pending`** liée au médecin et à la structure. Il n’active pas le rattachement automatiquement. Si la demande est refusée ou si le code expire, l’établissement doit générer un autre code.
5. L’administrateur établissement accepte ou refuse la demande. Seule l’acceptation passe le rattachement à `active`. C’est la décision institutionnelle qui atteste, pour cette structure, que son processus interne de vérification a été effectué.
6. Une fois rattaché, le médecin peut choisir cette structure comme établissement actif. Les demandes/lectures de dossiers demeurent soumises aux contrôles professionnels, au périmètre AccessGrant et au consentement du patient. Le compte établissement ne voit pas les dossiers.

## Identité, autorisations et historique

- **Pas de rôle Root global.** L’accès privé établissement est porté par une relation nominative `administrateur ↔ établissement`; le compte de la personne et l’entité établissement sont distincts. Réutiliser `AccountContext(role="establishment")` est envisageable pour l’UX, mais la relation à la structure doit être explicite et vérifiée côté serveur.
- **Un administrateur principal en V1.** L’association doit être remplaçable en gardant le même enregistrement d’établissement; prévoir une relation/adhésion plutôt qu’un `created_by` immuable comme seule autorité. Les anciennes associations restent historisées.
- **Pas de justificatif médecin sur E‑Carnet.** L’approbation de la demande par l’établissement est la vérification institutionnelle et l’autorisation d’affiliation pour cette structure. Techniquement, revoir l’actuel prérequis global `ProfessionalProfile.verification_status == "verified"` : l’accès clinique doit dépendre d’une affiliation active à la structure sélectionnée, sans qu’un document personnel soit exigé par E‑Carnet. Le consentement patient reste une condition distincte et obligatoire.
- **Historique non destructif.** Ne pas supprimer une structure, un admin, un code consommé/expiré, une demande ou un rattachement pour effacer une trace. Une fin d’accès passe par révocation/suspension horodatée, et les événements métier restent consultables aux personnes autorisées. Le compte d’un ancien administrateur peut être désactivé pour cette structure sans récréer celle-ci.
- **Événements à tracer :** décision de vérification de structure et son auteur; création/refus de l’accès; invitation créée, renvoyée, révoquée, consommée ou expirée; activation du compte; code généré/expiré/révoqué/consommé; demande médecin; acceptation/refus; changement d’administrateur; suspension/réactivation d’affiliation. Ne pas mettre dans l’audit les secrets d’invitation/codes, mots de passe, justificatifs ou données cliniques inutiles.

## Sécurité de la route privée

Une URL non devinable ne suffit pas. La console E‑Carnet doit exiger une session authentifiée, un contrôle serveur de permission staff dédiée, des vérifications CSRF, une séparation entre actions startup et actions établissement, et des journaux d’audit. Chaque requête doit autoriser la ressource sur la structure associée au compte, sans confiance dans un identifiant transmis par le navigateur. Les écrans et API établissement ne sont jamais ouverts à une inscription publique.

## État réel au 05/10/2026

Le dépôt a maintenant implémenté le flow principal : la création publique historique est neutralisée (`403`), les routes staff sont protégées par `IsAdminUser`, l’entité établissement est séparée de `EstablishmentAdministrator`, les invitations sont hashées et valables 48 h, les codes médecin sont hashés et à usage unique pendant 48 h, et l’administrateur établissement décide du rattachement. Les pages web correspondantes sont présentes.

Ce qui manque encore n’est donc pas le modèle principal : il reste la politique de renvoi/révocation e-mail, la non-exposition du token brut hors local, les tests PostgreSQL de concurrence, la recette staging et la preuve que l’espace établissement ne peut jamais lire le clinique.

## Plan d’implémentation et gates

1. **Modèle et migrations :** stabiliser `Establishment` indépendant de son administrateur; ajouter relation nominative administrateur-établissement, invitations à usage unique (48 h), codes médecin hashés (48 h, une consommation), et états/audit des actions. Ajouter contraintes d’unicité et transactions pour éviter doubles consommations.
2. **Demande et console E‑Carnet :** retirer le dépôt libre de justificatifs en ligne; remplacer son CTA par le contact e-mail officiel. Implémenter une console staff privée permettant d’enregistrer décision/auteur, refuser ou valider, puis créer une invitation. Aucun compte établissement avant validation staff.
3. **Invitation et création compte :** e-mail tokenisé, hash stocké, usage unique, expiration 48 h, limitation des renvois; page de définition du mot de passe; révocation/réémission; erreurs n’exposant pas l’existence d’un compte. Aucun mot de passe temporaire dans un message.
4. **Espace établissement :** connexion privée, identité nominative, relation à une structure unique en V1, présentation de la structure et possibilité future de changer d’administrateur sans perdre l’historique.
5. **Codes et demandes médecin :** génération par l’admin établissement, code 48 h/une fois; entrée par compte professionnel existant; consommation atomique et création `pending`; liste des demandes; accept/refuse; aucune pièce personnelle demandée à E‑Carnet.
6. **Autorisation clinique :** remplacer l’hypothèse de vérification globale par la validation institutionnelle au niveau du rattachement actif (si le profil clinique ne requiert pas d’autre preuve métier), tout en conservant établissement actif, session/contexte professionnel, AccessGrant actif, scopes validés et consentement patient.
7. **Historique et recette :** actions append-only, suspension plutôt que suppression, tests permissions horizontales, replays/expiration, liens d’invitation et codes, deux usages concurrents, refus et changement d’admin; tests de bout en bout mobile et PostgreSQL.

**Gate de validation :** aucune donnée clinique réelle; le parcours établissement ne sort pas en V1 tant que les permissions staff/établissement, les invitations, l’usage unique, l’absence d’accès clinique établissement, la conservation de l’audit et les scénarios d’échec n’ont pas leurs tests réussis.
