# Mon Carnet Numérique — plan de production V1, V2 et V3

> Document opérationnel basé sur l’audit du dépôt au 05/10/2026. Il décrit une stratégie de déploiement progressive qui évite de coupler le code applicatif à un hébergeur.

## 1. Avis global

**Oui, la stratégie Vercel + Render + Neon est recommandée pour la V1 de test/pilote**, à condition de ne pas l’appeler encore une production de données médicales réelles.

Le code est déjà adapté à une migration ultérieure :

- monorepo séparant `apps/web` et `apps/api` ;
- API Django/DRF consommée par une URL configurable ;
- PostgreSQL via `DATABASE_URL` ;
- variables d’environnement déjà utilisées ;
- endpoint de santé live/ready ;
- Dockerfiles et Docker Compose pour une future installation VPS ;
- migrations Django versionnées.

### Mon avis sur le VPS

**Pas de VPS en V1.** Il ajouterait immédiatement la responsabilité de patcher Ubuntu, sécuriser SSH, gérer le reverse proxy, les certificats, les sauvegardes, le monitoring et les restaurations. Pour un pilote, cela ralentit le produit et augmente le risque opérationnel.

**VPS en V3 : oui**, lorsque l’un de ces déclencheurs est réel :

- besoin contractuel de localisation/souveraineté des données ;
- volume ou coût justifiant la centralisation ;
- besoin de contrôle réseau et d’archivage plus fin ;
- capacité à financer une mise en place DevOps et des sauvegardes hors serveur.

Un VPS local n’est pas automatiquement conforme parce qu’il est situé en Côte d’Ivoire, au Bénin ou au Togo. Pour des données de santé, il faut obtenir des garanties contractuelles sur la localisation, les sauvegardes, les accès opérateur, le chiffrement, la disponibilité, la restauration et la réglementation applicable.

## 2. Architecture retenue par version

### V1 — pilote contrôlé

```text
Navigateur
   │
   ▼
Vercel — Next.js (frontend)
   │ HTTPS / cookies de session / CORS-allowlist
   ▼
Render Free — Django/DRF (API)
   │ DATABASE_URL TLS
   ▼
Neon — PostgreSQL
```

- Données de développement, preview et staging : **uniquement synthétiques**.
- Upstash/Redis : **pas activé tant qu’une fonctionnalité ne l’exige pas**. Le dépôt actuel ne nécessite pas Redis pour démarrer la V1.
- OAuth : activer fournisseur par fournisseur, après callback réel et test de bout en bout.

### V2 — staging et exploitation sérieuse

- même découpage applicatif ;
- environnement staging séparé de la production ;
- projet/base Neon séparé(e), jamais une base partagée avec les tests ;
- domaine réel et sous-domaines dédiés ;
- SMTP de production vérifié ;
- sauvegarde/restauration testée avec RPO/RTO approuvés ;
- monitoring et alertes ;
- revue dépendances et tests PostgreSQL réels.

### V3 — VPS sans réécriture

```text
Internet
   │
   ▼
Caddy ou Nginx — TLS / reverse proxy
   ├── app.moncarnet.ci       → Next.js
   └── api.moncarnet.ci       → Gunicorn + Django
                                │
                                ├── PostgreSQL
                                ├── Redis seulement si justifié
                                └── stockage privé + sauvegardes hors VPS
```

Le passage V3 doit remplacer les **services**, pas les contrats :

- `NEXT_PUBLIC_API_URL` change de valeur ;
- `DATABASE_URL` pointe vers PostgreSQL VPS ou une base managée conservée ;
- les migrations Django restent la source de vérité ;
- le frontend ne connaît jamais l’implémentation de la base ;
- le backend garde les mêmes routes `/api/v1/...` ;
- Docker Compose devient le mode d’exécution du VPS ;
- un reverse proxy fournit les mêmes domaines HTTPS attendus par le navigateur.

## 3. Configuration Render — API Django

Le fichier [`render.yaml`](render.yaml) a été ajouté à la racine. Il configure :

- runtime Python ;
- `pip install -r apps/api/requirements.txt` ;
- migration au démarrage ;
- Gunicorn, et non `runserver` ;
- bind sur `0.0.0.0:$PORT` ;
- health check `/api/v1/health/ready/` ;
- variables non secrètes et variables à saisir dans Render.

### Paramètres à vérifier dans Render

1. Connecter le dépôt Git.
2. Utiliser le Blueprint `render.yaml` ou recopier ses valeurs.
3. Vérifier que le service écoute bien sur `$PORT`.
4. Renseigner `DATABASE_URL` avec l’URL Neon **pooled ou non pooled selon le besoin**, fournie par Neon et non copiée dans Git.
5. Définir `DJANGO_ALLOWED_HOSTS` avec le hostname Render de l’API, sans protocole :

   ```text
   ecarnet-api.onrender.com
   ```

6. Définir `WEB_ORIGIN` et `CORS_ALLOWED_ORIGINS` avec l’URL Vercel exacte, protocole inclus :

   ```text
   https://mon-carnet.vercel.app
   ```

7. Définir `CSRF_TRUSTED_ORIGINS` avec la même origine HTTPS.
8. Configurer SMTP avant de tester les invitations établissement.
9. Ne pas activer OAuth tant que chaque callback n’est pas enregistré exactement chez le fournisseur.

### Commandes Render

```text
Build command : pip install -r apps/api/requirements.txt
Start command : cd apps/api && python manage.py migrate --noinput && gunicorn config.wsgi:application --bind 0.0.0.0:$PORT --workers 2 --threads 4 --timeout 120
Health check  : /api/v1/health/ready/
```

Le plan gratuit Render peut se mettre en veille. C’est acceptable pour une V1 de démonstration, pas pour une promesse de disponibilité médicale 24/7.

## 4. Configuration Vercel — frontend Next.js

Créer un projet Vercel lié au même dépôt :

- Framework : **Next.js** ;
- Root Directory : `.` si Vercel utilise le workspace racine ;
- Install Command : `npm ci` ;
- Build Command : `npm run build` ;
- variable `NEXT_PUBLIC_API_URL` : URL HTTPS Render de l’API ;
- ne jamais mettre de secret backend dans une variable `NEXT_PUBLIC_*`.

Si le projet Vercel impose le dossier applicatif comme Root Directory, conserver l’installation depuis la racine du monorepo ou utiliser la configuration monorepo recommandée par Vercel : le lockfile de référence est le `package-lock.json` racine.

Après déploiement, vérifier :

```text
https://<frontend-vercel>/
https://<frontend-vercel>/connexion
https://<frontend-vercel>/securite
```

Puis vérifier que l’appel navigateur vers l’API passe bien en HTTPS avec cookies et CSRF.

## 5. Variables d’environnement

Le fichier [`.env.example`](.env.example) contient désormais les noms et exemples, sans secret réel.

### Variables indispensables en production API

| Variable | Valeur attendue |
|---|---|
| `DJANGO_DEBUG` | `false` |
| `DJANGO_SECRET_KEY` | secret aléatoire long, généré par Render ou gestionnaire de secrets |
| `DJANGO_ALLOWED_HOSTS` | hostnames API sans `https://` |
| `DATABASE_URL` | URL PostgreSQL Neon avec TLS |
| `WEB_ORIGIN` | origine frontend HTTPS exacte |
| `CORS_ALLOWED_ORIGINS` | même origine, éventuellement liste séparée par virgules |
| `CSRF_TRUSTED_ORIGINS` | mêmes origines HTTPS autorisées |
| `SESSION_COOKIE_SAMESITE` | `None` pour frontend et API sur domaines différents |
| `EMAIL_*` | SMTP réel et vérifié |
| `DEFAULT_FROM_EMAIL` | adresse d’envoi sur domaine contrôlé |
| `ECARNET_INVITATION_BASE_URL` | URL frontend `/etablissement/activation` |
| `ECARNET_QR_TTL_SECONDS` | `300` pour 5 minutes en V1 |

### Règles impératives

- `.env`, clés Apple `.p8`, secrets OAuth et mots de passe ne doivent pas entrer dans Git.
- `NEXT_PUBLIC_*` est public par conception.
- Ne pas réutiliser la base Neon de production pour les tests.
- Ne pas mettre les données médicales en cache dans le service worker.
- Après toute modification de domaine, revoir CORS, CSRF, cookies et callbacks OAuth ensemble.

## 6. Base Neon

Créer une base dédiée au minimum pour staging et une autre pour production. Utiliser PostgreSQL réel avant de déclarer la V1 prête :

```bash
cd apps/api
python manage.py check --deploy
python manage.py migrate --plan
python manage.py migrate --noinput
python manage.py showmigrations
```

Le test de readiness est :

```bash
curl -fsS https://<api-render>/api/v1/health/ready/
```

La réponse attendue est un JSON `{"status":"ready"}` avec HTTP 200.

Avant toute donnée réelle :

- tester le trigger append-only de l’audit ;
- vérifier l’isolation entre établissements A/B ;
- vérifier les permissions PostgreSQL ;
- produire une sauvegarde ;
- restaurer dans une base isolée ;
- mesurer et approuver RPO/RTO.

## 7. Checklist Go/No-Go V1

### Déploiement technique

- [ ] `npm ci` réussi depuis la racine.
- [ ] `npm run lint` réussi.
- [ ] `npm run build` réussi.
- [ ] `npm run test:api` réussi.
- [ ] `npm run check:api` réussi.
- [ ] `makemigrations --check --dry-run` sans migration manquante.
- [ ] Render répond sur live et ready.
- [ ] Frontend Vercel appelle l’API Render en HTTPS.
- [ ] Cookies de session et CSRF vérifiés sur les vrais domaines.
- [ ] PostgreSQL Neon réel testé, pas SQLite.

### Fonctionnel et sécurité — bloquants connus du dépôt

- [ ] SMTP réel configuré et invitation reçue.
- [ ] Aucun token brut d’invitation hors debug/local.
- [ ] QR 5 minutes testé sur mobile réel.
- [ ] OAuth réel testé, ou boutons désactivés tant que non configuré.
- [ ] Les 5 vulnérabilités npm high signalées par l’audit sont traitées ou acceptées explicitement avec justification.
- [ ] `authlib.jose` migré vers `joserfc` ou décision documentée.
- [ ] Sanitation SVG retestée sur staging.
- [ ] Sauvegarde/restauration prouvée.
- [ ] Console staff durcie et accès établissement vérifié.
- [ ] Validation médicale et juridique signée.

**Tant que ces cases ne sont pas validées, utiliser seulement des données fictives (`example.test`).** Le déploiement Vercel/Render/Neon peut être fait pour le pilote technique, mais il ne constitue pas à lui seul l’autorisation d’exploiter des données de santé réelles.

## 8. Plan de migration VPS V3

1. Garder les mêmes images et variables d’environnement.
2. Provisionner un VPS Ubuntu LTS dimensionné au minimum à 4 vCPU / 8 Go RAM selon charge mesurée.
3. Installer Docker, firewall, utilisateur non-root, clés SSH, mises à jour et sauvegardes hors machine.
4. Déployer Caddy/Nginx, web, API, PostgreSQL et éventuellement Redis via Compose.
5. Restaurer une copie anonymisée ou synthétique de staging.
6. Pointer temporairement un sous-domaine staging vers le VPS.
7. Exécuter la même recette CA-01 à CA-24.
8. Préparer un plan de retour vers Render/Neon.
9. Basculer le DNS avec TTL réduit et fenêtre surveillée.
10. Ne supprimer aucun service managé avant d’avoir une restauration testée et une période d’observation validée.

**Conclusion :** déployer la V1 sur Vercel + Render + Neon est le meilleur compromis maintenant. Préparer le VPS par les contrats (`DATABASE_URL`, `NEXT_PUBLIC_API_URL`, migrations, health checks, Docker), mais ne pas l’introduire avant que le produit, la sécurité et l’exploitation soient réellement validés.

## 9. Recommandation actuelle pour l’hébergeur V3

Après vérification des offres publiées, mon choix principal est **Hodi Côte d’Ivoire — VPS managé**, dans leur datacenter annoncé au VITIB de Grand-Bassam.

### Pourquoi Hodi managé

Pour ce projet, je privilégie l’exploitation et la continuité de service plutôt que le prix minimal. L’offre managée annonce notamment :

- datacenter Tier III à Grand-Bassam ;
- architecture haute disponibilité N+2 ;
- firewall managé ;
- sauvegarde globale quotidienne avec rétention annoncée de 7 jours ;
- supervision 24/7 ;
- infogérance logicielle ;
- maintien en condition opérationnelle et de sécurité.

Pour la V3, je demanderais un devis pour **4 vCPU / 8 Go RAM / 100 Go SSD minimum**, puis je confirmerais le dimensionnement après les mesures V2. Il faut demander séparément la rétention longue, la restauration testée, le RPO/RTO contractuel, les journaux d’accès administrateur et les engagements précis concernant les données de santé.

### Classement pratique

1. **Hodi Côte d’Ivoire managé** — meilleur choix opérationnel pour démarrer une V3 sérieuse sans équipe DevOps permanente.
2. **Cloudstore Africa / ST Digital** — très bonne alternative si l’offre contractuelle de cloud souverain, de sauvegarde et de support 24/7 est confirmée pour la Côte d’Ivoire. Leur offre publique présente aussi des instances 4 vCPU / 8 Go et des services de sauvegarde/DRP.
3. **Orange Cloud Côte d’Ivoire** — option entreprise crédible, notamment si vous avez déjà une relation Orange ou besoin d’un accompagnement télécom ; vérifier toutefois les détails de sauvegarde, d’infogérance et de localisation dans le contrat choisi.

Je ne recommande pas le **VPS non managé** Hodi pour la première installation de Mon Carnet Numérique, sauf si un DevOps qualifié prend en charge le durcissement initial, les mises à jour, la supervision et les restaurations.

Les caractéristiques et tarifs évoluent : ils doivent être reconfirmés par devis avant achat. Les pages consultées sont : [Hodi VPS managé](https://hodi.host/ci/store/serveur-virtuel-manage), [Hodi VPS non managé](https://hodi.host/ci/store/serveur-virtuel), [ST Digital / Cloudstore](https://st.digital/cloud) et [Orange Cloud CI](https://cloud.orange.ci/index.php?rp=/store/serveur-virtuel-dedie&id=1&group=1).

## Recommandation V3 — hébergeur

**Je recommande Hodi Côte d’Ivoire en VPS managé pour la V3.**

Ce choix est privilégié pour Mon Carnet Numérique parce que l’offre annoncée comprend notamment un datacenter Tier III à Grand-Bassam, des sauvegardes quotidiennes, une supervision 24/7, un firewall managé ainsi que la maintenance opérationnelle et de sécurité. Cela réduit la charge DevOps par rapport à un VPS non managé.

Configuration de départ à demander par devis : **4 vCPU, 8 Go RAM, 100 Go SSD minimum, Ubuntu LTS, sauvegardes quotidiennes, rétention longue durée et RPO/RTO contractuels**. Cette recommandation reste conditionnée à la vérification contractuelle de la localisation, du chiffrement, des accès administrateur, des sauvegardes, de la restauration et des exigences applicables aux données de santé.
