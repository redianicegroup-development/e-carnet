# Sécurité — état du dépôt au 05/10/2026

Ce document décrit le code et ses limites. Il ne constitue ni une certification, ni une garantie de conformité, ni un audit indépendant.

## Contrôles présents

- **Données :** développement, tests, captures et pilote utilisent des données fictives. Aucune donnée clinique réelle avant les validations et le Go/No-Go.
- **Sessions :** session serveur Django; cookie de session HttpOnly, Secure hors DEBUG; CSRF/CORS configurés; aucun JWT dans `localStorage`.
- **Mots de passe :** `argon2-cffi` est déclaré et `Argon2PasswordHasher` est le premier `PASSWORD_HASHERS`; PBKDF2 reste dans la liste pour vérification/mise à niveau de comptes existants. Recetter la migration et la configuration en staging.
- **OAuth :** callbacks Google/Facebook/Apple et `AuthIdentity` présents; état OAuth par session; unicité `(provider, provider_user_id)` et `(user, provider)`; conflit e-mail traité sans fusion silencieuse. Les secrets fournisseurs sont absents ou placeholders dans l’archive. Le flow de liaison n’a pas de page d’administration utilisateur, l’audit et les tests fournisseurs restent à compléter. Apple dépend de credentials valides Apple Developer.
- **Accès clinique actuel :** l’API requiert contexte professionnel actif, établissement actif, membership active dans la structure sélectionnée et AccessGrant patient actif/consenti. Le garde global `verification_status == "verified"` n’est plus utilisé par `professional_clinical_access_error`; il reste à vérifier le contrat métier complet en staging.
- **QR :** le code serveur produit un jeton opaque, n’enregistre que son SHA-256, limite l’usage à une consommation et applique une expiration de 5 min. Les 5 minutes sont la durée produit V1 ; l’UI QR/scan est livrée localement et reste à recetter sur mobile/staging.
- **Audit :** événements métier minimisés sans contenu clinique; contrôles ORM et trigger PostgreSQL existent dans le dépôt, mais le trigger doit être exécuté/vérifié sur PostgreSQL cible.
- **PWA :** les API et espaces authentifiés ne doivent pas être mis en cache.
- **Secrets :** variables d’environnement; aucun secret de production dans le dépôt. `.env.example` est un exemple local, non une configuration sécurisée prête à déployer.

## Limites importantes — bloquantes avant exposition

- **SVG d’attestation :** le backend applique une allowlist stricte de primitives et attributs graphiques, refuse DTD/entités, scripts, CSS, médias, URL externes et namespaces non autorisés, puis sérialise, calcule un SHA-256 et conserve un horodatage. Les tests hostiles locaux passent ; le rendu et la recette staging restent à vérifier.
- **OAuth :** endpoints présents ne signifient pas que Google/Facebook/Apple sont activés en production. Il faut callbacks enregistrés, secrets réels, retours UI sûrs, liaison/déliaison accessible, audit et tests bout en bout. Aucune fusion automatique sur email.
- **Établissement :** compte nominatif, invitation hashée à usage unique/48 h et relation d’administration remplaçable présents côté API/UI. L’e-mail réel, le durcissement de la console et la recette production restent à faire ; l’accès admin établissement n’a pas de lecture clinique.
- **Invitation et code médecin :** token/code aléatoires hashés en base, expiration 48 h, consommation atomique unique et demande `pending` avant approbation sont présents. La configuration SMTP de staging, le renvoi/révocation et la non-exposition du token brut hors local restent à valider.
- **Vérification structure/médecin :** preuves structure reçues par e-mail et examinées hors application; pas de dépôt public. Justificatifs personnels médecin non collectés par E‑Carnet; établir une politique de rétention/suppression sécurisée pour la boîte e-mail structure.
- **MFA/TOTP :** décision produit = V3. Modèles, endpoints, seed et tests restent présents; le garde clinique n’exige pas le MFA. Nettoyer les écrans/textes et les scénarios V1 pour éviter de laisser croire qu’il est requis ou livré.
- **Scopes :** listes et défauts AccessGrant sont codés en constantes et pas encore approuvés (A9). Ne pas traiter le défaut actuel comme une règle validée.
- **Dépendances :** `npm ci` du 05/10/2026 signale cinq vulnérabilités high dans l’arbre d’outillage. Revue/correctif compatible requis avant publication; le build réussi ne supprime pas ces alertes.
- **Authlib :** usage d’`authlib.jose` émet un avertissement de dépréciation; prévoir migration vers `joserfc` et retester les JWT Apple.

## Contrôles qui restent à réaliser

1. OAuth réel par fournisseur et vérification Apple séparée.
2. Tests hostiles SVG et revue de sécurité.
3. Rate limits login, codes établissement, invitations, durée/rotation de session et cookies/CSRF sur les vrais domaines.
4. Tests inter-établissements A/B sur PostgreSQL et examen des permissions DB/trigger audit.
5. Staging, sauvegarde/restauration avec RPO/RTO approuvés, essais Android/4G et accessibilité.
6. Stockage privé, antivirus, rétention documentaire, procédure d’incident et revue juridique/médicale avant toute donnée réelle.
