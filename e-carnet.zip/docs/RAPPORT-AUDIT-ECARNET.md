# Audit de conformité et d’alignement — Mon Carnet Numérique

**Dépôt audité :** archive `e-carnet.zip`, extraite le 05/10/2026.  
**Portée :** comparaison du code backend/frontend, des tests, des prototypes mobiles et des nouvelles décisions du porteur.  
**Important :** cet audit technique n’est ni une certification, ni un avis juridique/médical, ni une acceptation de la V1.

## Verdict exécutif

Le dépôt possède un **socle fonctionnel réel**. Les contrôles locaux sont concluants sur la suite disponible : **52 tests Django détectés, 51 réussis et 1 ignoré**, tandis que `manage.py check`, les migrations, le lint et le build Next.js réussissent (**26 routes**). Cela ne signifie pas que tous les parcours sont livrés ni que la V1 est prête pour un pilote.

Le rapport contenu dans l’archive était **en partie périmé** : contrairement à ce rapport ancien, le dépôt contient maintenant une configuration Argon2id, des modèles/callbacks OAuth et des fonctions backend QR, ainsi qu’un contrôle SVG et hash/horodatage. Ces éléments sont toutefois de complétude variable; les limites sont détaillées ci-dessous.

## Résultat face aux décisions les plus récentes

| Sujet | État du code actuel | Verdict |
|---|---|---|
| Attestation SVG | XML parsé; quelques balises/attributs interdits rejetés; SHA-256 et horodatage persistés. Aucune allowlist exhaustive : CSS, références externes et variantes SVG non couvertes par les contrôles simples. | **Partiel — sécurité insuffisante pour considérer le SVG assaini.** |
| Argon2id | `argon2-cffi` est déclaré; `Argon2PasswordHasher` est en première position de `PASSWORD_HASHERS`, PBKDF2 reste accepté pour vérification de comptes historiques. | **Configuré dans le code; à recetter sur déploiement réel et sur comptes existants.** |
| Google / Facebook / Apple | `AuthIdentity`, contraintes d’unicité provider+ID et compte+provider, routes start/callback, state de session et conflit d’email sans fusion silencieuse existent. `AuthForms` présente des liens vers ces routes. | **Socle OAuth présent, intégration produit incomplète.** Pas de secrets réels dans le dépôt; pas de page visible pour lier/délier un fournisseur; le callback renvoie du JSON; pas de couverture de tests OAuth démontrée; journalisation de liaison manquante. Apple demande sa configuration Developer et un client secret valide. |
| Doublons identité | Une reconnexion par même `(provider, provider_user_id)` retrouve le compte. Une adresse déjà portée par un autre compte déclenche un conflit au lieu d’une fusion automatique. | **Garde-fous backend présents; parcours utilisateur et tests de bout en bout à achever.** |
| OTP SMS | Aucun parcours SMS n’est livré. | **Conforme à la décision : reporté en V3.** |
| Onboarding | L’inscription e-mail demande déjà nom/prénom et crée par défaut un contexte Patient. Une page permet ensuite Patient/Professionnel. Pas d’étape identité autonome avec avatar modifiable, pas de reprise complète; formulaire patient et profil professionnel n’implémentent pas les champs/documents demandés. | **Non conforme au parcours retenu.** |
| Professionnel et justificatifs | Profil actuel limité; aucun justificatif personnel du médecin n’est collecté. Le rattachement passe par code 48 h puis décision établissement. | **Partiel :** UI métier et recette staging restent à compléter. |
| Startup / administrateur établissement | Routes staff, console, relation administrateur nominative, invitation hashée 48 h et code médecin hashé 48 h présents côté API/UI. | **Partiel :** configuration SMTP de staging et durcissement production restent à valider. |
| Accès clinique | Contexte professionnel, établissement actif, membership active et consentement patient contrôlés côté serveur. | **Présent côté code ;** recette multi-structure et staging à produire. |
| QR d’AccessGrant | API patient émet un jeton opaque dont seul le hash est stocké; usage unique et expiration technique de 600 s; la demande professionnelle accepte le jeton et le consomme. | **Backend partiel déjà implémenté; UI de génération/affichage/scan absente.** La durée technique de 10 min n’est pas encore une décision produit; A9 reste à finaliser. |
| Scopes AccessGrant | `ALLOWED_SCOPES` et `DEFAULT_SCOPES` fixent dans le code `preconsultation`, `declarations`, `consultations`, `documents`; le défaut actuel est `preconsultation` + `declarations`. Le formulaire expose seulement une sélection simplifiée. | **Implémenté techniquement mais non validé métier.** « Hardcodé » = valeurs écrites directement dans le code, pas administrables/configurables et non confirmées comme règle produit. Garder provisoire jusqu’à A9. |
| MFA/TOTP | Modèle, endpoints setup/verify, seed et tests restent dans le dépôt. Le garde d’accès clinique actuel n’exige pas `MfaDevice.is_active`; certaines données seedées portent pourtant un TOTP actif. | **Contradiction de surface à nettoyer.** La décision est V3 : retirer TOTP de l’expérience et des prérequis V1; code résiduel ne signifie pas fonctionnalité V1 validée. |
| Auth et design | Auth en français et marque E-carnet; logos fournisseurs en SVG; plus de bouton social « Autre » dans le composant vérifié. Navigation métier utilise encore des glyphes Unicode (`⌂`, `▤`, `＋`, `↗`, `●`) et non un système d’icônes cohérent. | **Mieux que l’ancien audit, mais reste à aligner visuellement.** |
| Maquettes mobiles | Le code reprend les espaces, cartes et parcours de base, mais la composition live ne reproduit pas la maquette mobile. La demande actuelle est de reprendre l’expérience générale (navigation, densité, proportions, icônes), en conservant les flows décidés, non de recopier les anciens flows. | **Alignement design partiel; travail UI mobile prioritaire.** |

## Compréhension du flow établissement retenu

Patient et Professionnel gardent leurs comptes séparés par contexte; l’espace établissement est à part, privé et administré par **une personne nominative** (un seul administrateur actif en V1). Le terme « Root » global est abandonné. L’établissement transmet les preuves de la structure par e-mail officiel; un membre autorisé de l’équipe E‑Carnet les vérifie hors application, puis utilise une console staff protégée pour créer la structure et envoyer une invitation unique valable 48 h. Le responsable définit son mot de passe; aucun secret n’est envoyé dans l’e-mail.

L’établissement vérifie les médecins en interne. E‑Carnet ne collecte pas leurs pièces personnelles. L’administrateur crée un code à usage unique valable 48 h; sa saisie ouvre seulement une demande `pending`, et l’établissement doit ensuite accepter/refuser. Cette approbation atteste le rattachement institutionnel de ce médecin à cette structure. Les comptes établissement n’ont jamais d’accès aux dossiers patients; le médecin seul demande un AccessGrant avec consentement patient. Les invitations, codes, changements d’admin et adhésions gardent un historique non destructif.

Le code courant implémente désormais le flow privé : route publique neutralisée, staff, administrateur nominatif, invitation et code à usage unique. Les limites sont la configuration SMTP de staging, la recette production et la concurrence PostgreSQL. Détails et plan dans [`docs/FLOW-ETABLISSEMENT.md`](docs/FLOW-ETABLISSEMENT.md) et [`docs/adr/ADR-002-etablissement-invitation-et-rattachement.md`](docs/adr/ADR-002-etablissement-invitation-et-rattachement.md).

## Vérifications rejouées le 05/10/2026

- `npm run test:api` : **52 tests détectés : 51 réussis et 1 ignoré**.
- `npm run check:api` : aucune erreur système.
- `makemigrations --check --dry-run` : aucune migration manquante.
- `npm run lint` : réussi.
- `npm run build` : réussi; **26 routes statiques générées**.
- `npm ci` signale **5 vulnérabilités high** dans l’arbre de dépendances d’outillage; elles exigent une revue avant publication.
- Avertissement Authlib : import `authlib.jose` déprécié.

Non démontré par cette exécution : OAuth avec les consoles fournisseurs, staging/cookies/CSRF, Android/4G, trigger append-only sur PostgreSQL réel, Compose/Docker runtime, restauration/RPO/RTO, revue de sanitation hostile SVG ou approbation juridique/médicale.

## Priorités documentées (sans modification du code dans cette mise à jour)

1. Compléter le contrôle SVG par une sanitation robuste et des tests de charges hostiles.
2. Finaliser le flow établissement déjà présent : configurer SMTP en staging, ne plus exposer le token brut hors local et valider la concurrence PostgreSQL.
3. Réaliser l’onboarding demandé : identité/avatar et formulaires conditionnels; retirer tout upload de justificatifs personnels médecin vers E‑Carnet.
4. Finir les parcours OAuth : retour UI, lien/délien explicite, audit, tests et configuration réelle; vérifier Apple séparément.
5. Générer/rendre/scanner le QR côté UI; finaliser A9 (scopes et validité).
6. Retirer TOTP de l’expérience V1 et corriger textes/seeds/tests qui le présentent comme requis; MFA reste V3.
7. Harmoniser icônes et shell mobile avec la direction des prototypes, sans reprendre leurs parcours périmés.
8. Fermer les essais opérationnels (staging, PostgreSQL, restauration, appareils mobiles et dépendances).

Cette passe met à jour la documentation uniquement ; le code audité est celui livré dans l’archive.


## Note de couverture des tests ciblés

La recherche dans les tests fournis n’a trouvé aucun test dédié aux callbacks OAuth, à l’émission/consommation concurrente du QR ou à une charge SVG hostile. Les tests de consultation utilisent notamment un SVG minimal `<svg></svg>`; ils ne démontrent donc ni sanitation complète ni résistance XSS. Les résultats partiels de la suite générale ne remplacent pas ces cas de sécurité ciblés.
