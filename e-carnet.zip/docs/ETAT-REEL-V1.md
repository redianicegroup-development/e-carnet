# État réel du projet — V1

**Date de vérification : 05/10/2026 — mise à jour après durcissement et recette locale**  
**Archive analysée :** état courant du dépôt après implémentation QR/OAuth/onboarding/avatar/sanitation SVG  
**Verdict : V1 en construction, non acceptée et non autorisée pour des données de santé réelles.**

## Résumé exécutif

Le dépôt contient un socle fonctionnel sérieux : monorepo Next.js/Django, sessions serveur, CSRF, profils patient/professionnel, pré-consultations, AccessGrant, consultations, audit, PWA et un flow établissement désormais largement implémenté côté API et interface.

La V1 n’est toutefois pas finalisée :

- la suite API est verte : **57 tests OK et 1 ignoré** ; le test ignoré couvre une concurrence non démontrable sous SQLite ;
- l’UI QR patient/professionnel est livrée : génération QR côté patient, lecture caméra ou saisie du jeton côté professionnel ;
- les scopes et la durée produit du QR sont ratifiés pour la V1 : 5 min ;
- OAuth possède les callbacks, le retour UI, la liaison/déliaison explicite et l’audit ; les credentials fournisseurs et la recette bout en bout restent à faire ;
- la sanitation SVG est maintenant une allowlist stricte, couverte par des tests adversariaux ;
- l’envoi d’invitation est branché via le backend SMTP Django configurable ; le token brut reste retourné uniquement lorsque `DEBUG=true` pour le développement local ;
- PostgreSQL réel, Docker runtime, restauration/RPO-RTO, staging, mobile/4G, accessibilité et validations médicales/juridiques ne sont pas démontrés.

## Contrôles rejoués dans l’archive

| Contrôle | Résultat |
|---|---|
| `npm run test:api` | **OK** : 57 tests, 1 ignoré |
| `npm run check:api` | OK |
| `python manage.py makemigrations --check --dry-run` | OK, aucune migration manquante |
| `npm run lint` | OK |
| `npm run build` | OK, **27 routes** générées |
| `npm ci` | OK, mais **5 vulnérabilités high** signalées dans l’arbre npm |
| Import Authlib | Avertissement : `authlib.jose` est déprécié au profit de `joserfc` |

Les tests ont été rejoués après installation locale de `npm` et des dépendances Python. Le résultat ne constitue ni une recette staging ni un audit de sécurité indépendant.

### Échecs à traiter

Les tests en échec se trouvent dans `apps/api/apps/establishments/tests.py` et vérifient encore l’ancien contrat :

1. création publique d’un établissement (`201`) alors que la route est maintenant neutralisée (`403`) ;
2. demande par ancien code permanent alors que la route est retirée (`410`) ;
3. approbation conditionnée par le statut global `verified` ;
4. génération automatique d’un `internal_code` lors de l’approbation.

Les tests historiques ont été réécrits sur le nouveau contrat. Il reste à compléter la couverture de concurrence PostgreSQL et les cas de recette staging, plutôt que réintroduire l’ancien comportement.

## Ce qui est réellement présent

### Socle et identité

- Next.js 16 / React 19, Django 5.2 / DRF et PostgreSQL cible ; SQLite est utilisé pour les tests locaux.
- Session serveur, cookies HttpOnly/Secure hors debug, CSRF/CORS configurés ; pas de JWT dans `localStorage`.
- Argon2id configuré comme premier hasher Django.
- Compte unique avec choix Patient ou Professionnel ; `AuthIdentity` et callbacks Google/Facebook/Apple présents.
- Onboarding identité/avatar → contexte → formulaire métier présent ; l’avatar est éditable par URL, sans upload de fichier local.

### Patient, accès clinique et consultation

- Profil patient, déclarations, pré-consultation brouillon/clôture, historique et consultation persistée.
- AccessGrant : demande, consentement/refus, expiration serveur à 2 h, deux prolongations d’1 h et révocation.
- Le garde clinique exige maintenant un contexte professionnel actif, un établissement actif, un rattachement actif et le consentement patient ; le statut global `verification_status == verified` n’est plus le contrôle d’accès dans `professionals/access.py`.
- Le backend QR émet un jeton opaque hashé, à usage unique, avec validité produit de 5 minutes ; les scopes V1 sont appliqués.
- L’attestation SVG est parsée, sanitationnée par allowlist stricte, hashée en SHA-256 et horodatée ; les charges script/CSS/URL/DTD sont couvertes par tests.

### Établissement et rattachement médecin

Le nouveau flow est **largement présent** :

- création et validation via routes staff protégées ; la route publique historique est neutralisée ;
- modèle `EstablishmentAdministrator` séparé, nominatif et historisé ; un seul administrateur actif par structure en V1 ;
- invitation hashée, unique et valable 48 h ; le responsable choisit son mot de passe ;
- modèle de code médecin hashé, à usage unique et valable 48 h ; la saisie crée `pending` ;
- acceptation/refus par l’administrateur établissement ; suspension/départ historisé ;
- isolation entre établissements et espace établissement sans lecture clinique ;
- pages web de console staff, activation d’invitation, gestion établissement et rattachements présentes.

Limites restantes : le transport SMTP doit être configuré et vérifié en staging, le token n’est retourné qu’en `DEBUG=true` local, et la console staff doit être durcie pour la production.

### Frontend et PWA

- 27 routes Next.js générées au build ; pages Patient, Professionnel, Établissement, Staff, onboarding, sécurité et FAQ présentes.
- Manifest/service worker présents ; aucune donnée médicale ne doit être mise en cache.
- Un smoke Chromium headless valide 6 routes pour mobile/accessibilité de base ; la recette Android/iOS/4G et l’audit WCAG 2.2 AA complet restent à faire.
- La demande professionnelle utilise encore un identifiant patient ; le parcours QR scan/entrée n’est pas intégré à l’UI.

## Travaux restants pour déclarer la V1 finalisée

### Bloquants fonctionnels immédiats

1. Exécuter les tests PostgreSQL de concurrence et compléter les cas de refus/révocation avec le transport SMTP de staging.
2. Brancher un transport d’e-mail de production pour les invitations ; ne plus retourner ni afficher le token brut hors environnement local ; définir SPF/DKIM/DMARC, expiration, renvoi et rétention.
3. Recetter sur mobile/staging la durée produit de 5 minutes et les scopes A9 ; l’UI locale est livrée.
4. Recetter l’onboarding identité/avatar et les formulaires métier ; l’avatar URL est livré, l’upload de fichier n’est pas prévu en V1.
5. Rejouer la sanitation SVG stricte sur le pipeline de staging et vérifier le rendu avec le composant final.

### Bloquants sécurité et exploitation

6. Rejouer les tests sur PostgreSQL réel, vérifier le trigger append-only, les permissions DB et l’isolation A/B.
7. Exécuter sauvegarde/restauration dans une base isolée et mesurer RPO/RTO approuvés ; les scripts existent mais la preuve n’est pas produite.
8. Configurer et tester OAuth Google/Facebook/Apple sur staging, avec callbacks réels, retour UI, liaison/déliaison explicite, audit et Apple Developer.
9. Traiter les 5 vulnérabilités npm high et migrer `authlib.jose` vers `joserfc` avec tests JWT Apple.
10. Vérifier rate limiting, cookies/CSRF sur domaines réels, stockage privé, rétention, procédure d’incident et absence de cache privé.

### Validation produit et Go/No-Go

11. Faire valider médicalement les champs de pré-consultation/consultation, unités et corrections.
12. Formaliser les décisions juridiques sur hébergement ivoirien, conservation, droits, e-mail des justificatifs structure et incidents.
13. Recetter navigateur mobile, Android/4G, clavier, lecteur d’écran, focus, session expirée et responsive desktop.
14. Réaliser une recette staging complète CA-01 à CA-24 avec SMTP réel, QR sur mobile et preuves horodatées, puis prendre une décision Go/No-Go. Tant que cette étape n’est pas signée, utiliser uniquement des données `example.test`.

## Documents de référence

- [Roadmap V1–V5](ROADMAP-V1-V5.md)
- [Plan V1](V1-PLAN.md)
- [Matrice de recette](RECETTE-V1.md)
- [Sécurité](SECURITY.md)
- [Flow établissement](FLOW-ETABLISSEMENT.md)
- [Audit détaillé](../RAPPORT-AUDIT-ECARNET.md)
