
## 2026-10-05 — Synchronisation documentation et recette finale

- README, cahier de décisions A1–A16, état réel, plan V1, roadmap, matrice de recette, sécurité et déploiement alignés sur le code courant.
- État vérifié : 57 tests API OK, 1 ignoré ; build Next.js avec 27 routes ; smoke Chromium local sur 6 routes.
- A9 documenté comme appliqué : QR opaque à usage unique, 5 minutes ; `preconsultation` + `declarations` par défaut, `consultations` sélectionnable, `documents` hors V1.
- Sanitation SVG documentée comme allowlist stricte avec tests adversariaux.
- Verdict maintenu : NO-GO staging/production tant que PostgreSQL réel, restauration, staging et validations métier/sécurité ne sont pas signés.
# Changelog

## V1 — flow établissement confirmé par le porteur — 2026-10-05

- L’établissement envoie ses preuves par e-mail à E‑Carnet; aucune demande/upload public. Un staff autorisé vérifie puis crée un compte d’administrateur nominatif; un seul admin actif en V1, remplaçable sans recréer la structure.
- Invitation unique à 48 h, mot de passe défini par le responsable; aucun mot de passe temporaire par e-mail.
- Code médecin émis par l’établissement, unique et valable 48 h; il crée seulement une demande `pending`, ensuite approuvée/refusée par l’établissement.
- E‑Carnet ne collecte pas les justificatifs personnels/professionnels médecin; la vérification est interne entre médecin et établissement. L’espace établissement ne lit aucun dossier patient.
- Historique non destructif des comptes, invitations, codes, décisions et rattachements; fin d’accès par suspension/révocation.
- Consigné dans [FLOW-ETABLISSEMENT.md](FLOW-ETABLISSEMENT.md) et [ADR-002](adr/ADR-002-etablissement-invitation-et-rattachement.md); le flow est désormais implémenté côté API/UI ; l’e-mail réel et la recette production restent à faire.

## V1 — audit comparatif et harmonisation des décisions — 2026-10-05

- Rejeu local des validations sur l’archive : **52 tests Django détectés : 51 réussis et 1 ignoré**, `check`, migrations, lint et build Next.js passés; build avec 26 routes.
- Correction du rapport d’audit ancien : Argon2id est configuré; les callbacks OAuth/`AuthIdentity` existent; un backend QR à jeton haché/usage unique existe; l’attestation SVG a déjà une blacklist partielle, empreinte SHA-256 et horodatage. Ces fonctions restent partielles, pas déclarées complètes.
- Décisions du porteur consignées : OTP SMS et MFA/TOTP en V3; onboarding identité/avatar puis choix Patient/Professionnel; Root/Établissement privés; startup vérifie la structure et provisionne Root; Root gère code/rattachement; accès clinique par professionnel avec consentement patient.
- Les deux roadmaps ont été harmonisées; les prototypes sont explicitement référence de design mobile, non de flow produit.
- État UI constaté : textes d’authentification français et logo E-carnet; navigation encore fondée sur glyphes Unicode; alignement visuel mobile à terminer.
- A9 (scopes et validité QR), sanitation SVG, parcours Root, onboarding complet, UI OAuth/QR et recettes staging restent ouverts.
- Aucune modification du code applicatif dans cette mise à jour; changements limités à la documentation.

## V1 — parcours complet et alignement de la recette — 2026-10-04

- Ajout d’un test d’intégration patient → demande AccessGrant → consentement → pré-consultation clôturée → consultation → révocation.
- Sessions serveur et protections d’accès clinique; TOTP/MFA reporté en V3 selon la décision produit actuelle.
- `DJANGO_SECRET_KEY` exigée hors DEBUG; contrôles de tests ciblés.
- Rapport antérieur indiquait 38 tests API à ce moment-là; le dépôt audité le 05/10 contenait 52 tests détectés, avec 51 réussis et 1 test ignoré ; cette formulation est historique et le code a depuis été corrigé. Cette entrée est historique ; voir l’état réel V1 pour le verdict courant.
- Staging, trigger PostgreSQL réel, restauration, Android/4G, OAuth fournisseurs et validations métier restent à exécuter.

## V1 — tranche de sécurisation et préparation de recette — 2026-10-03

- Next.js 16.3.8 et configuration ESLint flat; avis de dépendances à réévaluer.
- Audit append-only, endpoints patient/professionnel, établissement actif, historique et tests d’isolation progressivement ajoutés.
- Seed locale `example.test` opt-in; ne jamais exécuter sur staging partagé/production.
- La suite de tests évoluait pendant les travaux; consulter la recette datée pour l’état courant.

## 0.1.0 — 2026-10-03

- Création du monorepo Next.js/Django, Compose local, CI et préférences de thème par compte.
- Documentation initiale, API et prototypes archivés.

Les entrées historiques consignent l’état à leur date; pour l’état courant, voir [rapport d’audit](../RAPPORT-AUDIT-ECARNET.md), [roadmap](ROADMAP-V1-V5.md) et [recette](RECETTE-V1.md).
