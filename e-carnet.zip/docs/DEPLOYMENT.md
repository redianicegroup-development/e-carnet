# Développement, Docker et déploiement

**Mis à jour le 05/10/2026.** La pile est validée localement par tests et build, mais aucun staging/production ne peut être considéré comme prêt. Les données utilisées restent fictives.

## Prérequis

- Node.js 22+ avec npm 10+;
- Python 3.12+;
- Docker Engine et Docker Compose v2 pour l’exécution complète.

## Pile locale

À la racine :

```bash
cp .env.example .env
# Remplacer les secrets par des valeurs aléatoires locales.
docker compose config
docker compose up --build
```

Services : Web `http://localhost:3000`; API `http://localhost:8000/api/v1/health/live/`; readiness `http://localhost:8000/api/v1/health/ready/`; PostgreSQL local `localhost:5432`. Les ports sont bindés à `127.0.0.1`. `docker compose down -v` supprime le volume de données fictives.

## Dépendances et contrôles

```bash
npm ci
npm run test:api
npm run check:api
(cd apps/api && python manage.py makemigrations --check --dry-run)
npm run lint
npm run build
```

Dernière vérification rejouée le 05/10/2026 : 57 tests Django OK et 1 ignoré, check/migrations, lint et build Next passés (27 routes). `npm ci` annonce 5 vulnérabilités high d’outillage; traiter avant publication. Authlib signale `authlib.jose` déprécié.

## OAuth (non activé sans credentials)

Le backend lit les variables ci-dessous; les valeurs de `.env.example` sont des placeholders, **pas des secrets valides** :

| Fournisseur | Variables |
|---|---|
| Google | `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` |
| Facebook | `FACEBOOK_CLIENT_ID`, `FACEBOOK_CLIENT_SECRET` |
| Apple | `APPLE_CLIENT_ID`, `APPLE_CLIENT_SECRET`, `APPLE_TEAM_ID`, `APPLE_KEY_ID`, `APPLE_PRIVATE_KEY_PATH` |

Déclarer chaque URL de callback exacte côté fournisseur, conformément au domaine staging/production. Les callbacks sont générés sur `/api/v1/identity/oauth/<provider>/callback/`. Garder les secrets dans le gestionnaire de secrets ou variables d’environnement, jamais dans Git. L’implémentation possède les routes, le retour UI, l’identité externe, la liaison/déliaison et l’audit ; les tests fournisseurs et les credentials réels sont à fournir. Apple exige un client secret au format et à la durée conformes au setup Sign in with Apple et un compte Developer valide.

Lier une identité secondaire doit se faire après connexion au compte existant; une adresse email correspondante seule ne déclenche aucune fusion.

## Invitations établissement — finition avant production

Le flow d’invitation est présent côté API/UI : invitation hashée à usage unique valable 48 h, activation et choix du mot de passe par le destinataire. Le dépôt ne contient pas encore de transport e-mail de production : avant activation, choisir et configurer ce transport, SPF/DKIM/DMARC et un domaine d’expédition contrôlé. Les endpoints actuels renvoient encore le token brut pour le développement ; ne jamais le conserver ni l’exposer en production. Les preuves légales de la structure arrivent à la boîte officielle E‑Carnet et sont vérifiées hors application; définir la rétention, les accès et la suppression de ces pièces. Les justificatifs professionnels des médecins ne sont pas collectés par la plateforme.

## Configuration de mots de passe

Argon2id est déclaré dans `apps/api/requirements.txt` et est le premier hasher Django. PBKDF2 reste déclaré pour vérifier les anciens hachages et permettre la mise à niveau. Vérifier le comportement sur la base staging et ne jamais exporter les vrais hashes dans un rapport.

## Installation native

```bash
npm ci
npm run dev
```

API dans un autre terminal :

```bash
python3 -m venv apps/api/.venv
. apps/api/.venv/bin/activate
pip install -r apps/api/requirements.txt
cd apps/api
python manage.py migrate
python manage.py runserver 0.0.0.0:8000
```

Sans `DATABASE_URL`, Django utilise SQLite pour le local/tests seulement; le pilote doit utiliser PostgreSQL. `DEBUG=false` sans `DJANGO_SECRET_KEY` est refusé. `runserver` et `next dev` ne sont pas des serveurs de production.

## Séparation environnements et mise en production

Local, preview et staging utilisent uniquement des données synthétiques. Avant toute donnée réelle : hébergement ivoirien, validations juridique/médicale, domaine/HTTPS, cookies/CSRF, PostgreSQL/trigger, sauvegardes/RPO-RTO, procédure d’incident, sécurité SVG, revue de dépendances, OAuth configuré, console staff et espace établissement privés, transport d’invitation vérifié et flow à usage unique testé. Aucun Compose local ne remplace ces preuves.
