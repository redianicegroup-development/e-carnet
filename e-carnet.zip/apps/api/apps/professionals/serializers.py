from rest_framework import serializers

from .models import ProfessionalProfile


class ProfessionalOnboardingSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProfessionalProfile
        fields = ("professional_title", "specialty", "professional_identifier")


class ProfessionalProfileSerializer(serializers.ModelSerializer):
    active_establishment = serializers.UUIDField(source="active_establishment_id", allow_null=True, read_only=True)
    mfa_active = serializers.SerializerMethodField()

    class Meta:
        model = ProfessionalProfile
        fields = ("id", "professional_title", "specialty", "professional_identifier", "verification_status", "active_establishment", "mfa_active")

    def get_mfa_active(self, obj):
        device = getattr(obj.user, "mfa_device", None)
        return bool(device and device.is_active)
