from django.urls import path

from .views import MfaSetupView, MfaVerifyView, ProfessionalMeView, ProfessionalOnboardingView, StartupProfessionalVerificationQueueView

urlpatterns = [
    path("startup/verification-queue/", StartupProfessionalVerificationQueueView.as_view()),
    path("startup/<uuid:profile_id>/verification-decision/", StartupProfessionalVerificationQueueView.as_view()),
    path("me/", ProfessionalMeView.as_view()),
    path("onboarding/", ProfessionalOnboardingView.as_view()),
    path("mfa/setup/", MfaSetupView.as_view()),
    path("mfa/verify/", MfaVerifyView.as_view()),
]
