import base64
import secrets
from django.db import transaction
from django.utils import timezone
from rest_framework import status
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.identity.models import AccountContext
from apps.audit.services import record_event
from .mfa import valid_totp
from .models import MfaDevice, ProfessionalProfile
from .serializers import ProfessionalOnboardingSerializer, ProfessionalProfileSerializer


class ProfessionalMeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        profile = getattr(request.user, "professional_profile", None)
        if not profile:
            return Response({"success": False, "message": "Le profil professionnel n’est pas encore créé."}, status=404)
        return Response({"success": True, "data": ProfessionalProfileSerializer(profile).data})


class StartupProfessionalVerificationQueueView(APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request):
        profiles = ProfessionalProfile.objects.filter(verification_status="pending").select_related("user")
        data = [{
            "id": str(profile.id),
            "professional_title": profile.professional_title,
            "specialty": profile.specialty,
            "professional_identifier": profile.professional_identifier,
            "first_name": profile.user.first_name,
            "last_name": profile.user.last_name,
            "email": profile.user.email,
        } for profile in profiles]
        return Response({"success": True, "data": data})

    @transaction.atomic
    def post(self, request, profile_id):
        profile = ProfessionalProfile.objects.select_for_update().filter(
            id=profile_id, verification_status="pending"
        ).first()
        decision = request.data.get("decision")
        if not profile or decision not in ("approve", "reject"):
            return Response({"success": False, "message": "Décision de vérification invalide."}, status=400)

        profile.verification_status = "verified" if decision == "approve" else "rejected"
        profile.save(update_fields=("verification_status", "updated_at"))
        record_event(
            event_type="professional.verification.approved" if decision == "approve" else "professional.verification.rejected",
            actor=request.user,
            actor_role="startup",
            metadata={"action": decision, "status": profile.verification_status},
        )
        return Response({"success": True, "data": {"id": str(profile.id), "verification_status": profile.verification_status}})


class ProfessionalOnboardingView(APIView):
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def patch(self, request):
        profile, _ = ProfessionalProfile.objects.get_or_create(user=request.user, defaults={"professional_title": "Professionnel"})
        serializer = ProfessionalOnboardingSerializer(profile, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        context, _ = AccountContext.objects.get_or_create(user=request.user, role="professional")
        context.is_active = True
        context.onboarding_completed = True
        context.save(update_fields=("is_active", "onboarding_completed", "updated_at"))
        return Response({"success": True, "data": ProfessionalProfileSerializer(profile).data})


class MfaSetupView(APIView):
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def post(self, request):
        if not hasattr(request.user, "professional_profile") and not request.user.account_contexts.filter(role="establishment").exists():
            return Response({"success": False, "message": "Le MFA est réservé aux contextes professionnel ou établissement."}, status=403)
        device, created = MfaDevice.objects.get_or_create(user=request.user, defaults={"secret": base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")})
        if not device.is_active:
            return Response({"success": True, "data": {"secret": device.secret, "confirmed": False}})
        return Response({"success": True, "data": {"confirmed": True}})


class MfaVerifyView(APIView):
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def post(self, request):
        device = getattr(request.user, "mfa_device", None)
        if not device or not valid_totp(device.secret, request.data.get("code", "")):
            return Response({"success": False, "message": "Code MFA invalide."}, status=400)
        device.is_active = True
        device.activated_at = timezone.now()
        device.save(update_fields=("is_active", "activated_at"))
        return Response({"success": True, "data": {"confirmed": True}})
