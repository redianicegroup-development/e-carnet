from datetime import timedelta
from django.contrib.auth import get_user_model
from apps.identity.models import AccountContext
from django.utils import timezone
from django.test import TestCase
from rest_framework.exceptions import ValidationError
from rest_framework.test import APIClient
from apps.patients.models import PatientProfile
from apps.establishments.models import Establishment, EstablishmentMembership
from apps.professionals.models import MfaDevice, ProfessionalProfile
from apps.audit.models import AuditEvent
from .models import AccessGrant, CareEncounter, Consultation, ConsultationRevision

User = get_user_model()


class PatientAccessTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="patient-care", password="local-test-password")
        self.other = User.objects.create_user(username="other-care", password="local-test-password")
        self.profile = PatientProfile.objects.create(user=self.user)
        self.other_profile = PatientProfile.objects.create(user=self.other)
        self.client = APIClient()

    def test_patient_controls_two_extensions_then_revoke(self):
        grant = AccessGrant.objects.create(patient=self.profile, professional_name="Dr Test", facility_label="Établissement fictif", scope=["preconsultation"])
        self.client.force_authenticate(self.user)
        accepted = self.client.post(f"/api/v1/patient/care/access-grants/{grant.id}/accept/")
        self.assertEqual(accepted.status_code, 200)
        self.assertEqual(accepted.data["data"]["status"], "active")
        self.assertEqual(self.client.post(f"/api/v1/patient/care/access-grants/{grant.id}/extend/").status_code, 200)
        self.assertEqual(self.client.post(f"/api/v1/patient/care/access-grants/{grant.id}/extend/").status_code, 200)
        self.assertEqual(self.client.post(f"/api/v1/patient/care/access-grants/{grant.id}/extend/").status_code, 409)
        self.assertEqual(self.client.post(f"/api/v1/patient/care/access-grants/{grant.id}/revoke/").data["data"]["status"], "revoked")
        events = AuditEvent.objects.filter(access_grant=grant)
        self.assertEqual(events.count(), 4)
        self.assertTrue(all("clinical_text" not in event.metadata for event in events))
        event = events.first()
        event.event_type = "audit.modified"
        with self.assertRaises(TypeError):
            event.save()
        with self.assertRaises(TypeError):
            event.delete()
        with self.assertRaises(TypeError):
            events.update(event_type="audit.modified")
        with self.assertRaises(TypeError):
            events.delete()

    def test_expired_grant_is_audited_once_as_a_system_transition(self):
        grant = AccessGrant.objects.create(
            patient=self.profile,
            professional_name="Médecin fictif",
            facility_label="Établissement fictif",
            scope=["preconsultation"],
            status="active",
            starts_at=timezone.now() - timedelta(hours=3),
            expires_at=timezone.now() - timedelta(minutes=1),
        )
        self.client.force_authenticate(self.user)
        self.client.get("/api/v1/patient/care/access-grants/")
        self.client.get("/api/v1/patient/care/access-grants/")
        grant.refresh_from_db()
        event = AuditEvent.objects.get(access_grant=grant, event_type="access_grant.expired")
        self.assertEqual(grant.status, "expired")
        self.assertIsNone(event.actor)
        self.assertEqual(event.actor_role, "system")
        self.assertEqual(AuditEvent.objects.filter(access_grant=grant).count(), 1)

    def test_pending_request_can_be_refused_and_is_isolated(self):
        grant = AccessGrant.objects.create(patient=self.profile, professional_name="Dr Test", facility_label="Clinique fictive", scope=["declared"])
        self.client.force_authenticate(self.other)
        self.assertEqual(self.client.get("/api/v1/patient/care/access-grants/").data["data"], [])
        self.client.force_authenticate(self.user)
        response = self.client.post(f"/api/v1/patient/care/access-grants/{grant.id}/refuse/")
        self.assertEqual(response.data["data"]["status"], "refused")
        history = self.client.get("/api/v1/patient/care/access-audit/")
        self.assertEqual(history.status_code, 200)
        self.assertEqual([item["action"] for item in history.data["data"]], ["refuse"])
        self.assertNotIn("clinical_text", history.data["data"][0])

    def test_professional_clinical_reads_require_current_context_and_membership(self):
        doctor = User.objects.create_user(username="doctor-read-guard", password="local-test-password")
        profile = ProfessionalProfile.objects.create(user=doctor, professional_title="Médecin", verification_status="verified")
        establishment = Establishment.objects.create(created_by=self.user, name="Clinique garde", establishment_type="Clinique", city="Abidjan", address="G", phone="0", email="guard@example.test", responsible_name="Root", status="active", internal_code="GUARD-1")
        membership = EstablishmentMembership.objects.create(establishment=establishment, professional=profile, status="active")
        profile.active_establishment = establishment
        profile.save(update_fields=("active_establishment", "updated_at"))
        grant = AccessGrant.objects.create(patient=self.profile, professional=profile, establishment=establishment, professional_name="Médecin", facility_label=establishment.name, scope=["preconsultation"], status="active", starts_at=timezone.now(), expires_at=timezone.now() + timedelta(hours=1))
        self.client.force_authenticate(doctor)
        url = f"/api/v1/patient/care/professional/access-grants/{grant.id}/encounters/"

        self.assertEqual(self.client.get(url).status_code, 403)
        AccountContext.objects.create(user=doctor, role="professional", is_active=True)
        self.assertEqual(self.client.get(url).status_code, 200)
        self.assertEqual(self.client.get("/api/v1/patient/care/professional/consultations/").status_code, 200)

        grant.status = "revoked"
        grant.save(update_fields=("status",))
        self.assertEqual(self.client.get(url).status_code, 403)
        grant.status = "active"
        grant.expires_at = timezone.now() - timedelta(minutes=1)
        grant.save(update_fields=("status", "expires_at"))
        self.assertEqual(self.client.get(url).status_code, 403)
        grant.status = "active"
        grant.expires_at = timezone.now() + timedelta(hours=1)
        grant.save(update_fields=("status", "expires_at"))

        consultation = Consultation.objects.create(patient=self.profile, professional=profile, establishment=establishment, access_grant=grant, professional_name="Médecin", facility_label=establishment.name, reason="Motif synthétique", validated_at=timezone.now())
        membership.status = "suspended"
        membership.save(update_fields=("status",))
        self.assertEqual(self.client.get(url).status_code, 403)
        self.assertEqual(self.client.get("/api/v1/patient/care/professional/consultations/").status_code, 403)
        self.assertTrue(Consultation.objects.filter(pk=consultation.pk).exists())

    def test_nurse_role_and_endpoint_do_not_exist(self):
        roles = {value for value, _label in AccountContext.ROLE_CHOICES}
        self.assertNotIn("nurse", roles)
        self.assertEqual(self.client.get("/api/v1/patient/care/nurse/").status_code, 404)

    def test_professional_context_cannot_read_other_establishment_data(self):
        doctor = User.objects.create_user(username="doctor-cross-site", password="local-test-password")
        profile = ProfessionalProfile.objects.create(user=doctor, professional_title="Médecin", verification_status="verified")
        site_a = Establishment.objects.create(created_by=self.user, name="Site A fictif", establishment_type="Centre", city="Abidjan", address="A", phone="0", email="site-a@example.test", responsible_name="Root A", status="active", internal_code="SITE-A-1")
        site_b = Establishment.objects.create(created_by=self.user, name="Site B fictif", establishment_type="Centre", city="Abidjan", address="B", phone="0", email="site-b@example.test", responsible_name="Root B", status="active", internal_code="SITE-B-1")
        EstablishmentMembership.objects.create(establishment=site_a, professional=profile, status="active")
        EstablishmentMembership.objects.create(establishment=site_b, professional=profile, status="active")
        profile.active_establishment = site_b
        profile.save(update_fields=("active_establishment", "updated_at"))
        AccountContext.objects.create(user=doctor, role="professional", is_active=True)
        MfaDevice.objects.create(user=doctor, secret="JBSWY3DPEHPK3PXP", is_active=True)
        grant_a = AccessGrant.objects.create(patient=self.profile, professional=profile, establishment=site_a, professional_name="Médecin", facility_label=site_a.name, scope=["preconsultation"], status="active", starts_at=timezone.now(), expires_at=timezone.now() + timedelta(hours=1))
        Consultation.objects.create(patient=self.profile, professional=profile, establishment=site_a, access_grant=grant_a, professional_name="Médecin", facility_label=site_a.name, reason="Consultation fictive site A", validated_at=timezone.now())
        self.client.force_authenticate(doctor)

        self.assertEqual(self.client.get("/api/v1/patient/care/professional/access-grants/").data["data"], [])
        self.assertEqual(self.client.get("/api/v1/patient/care/professional/consultations/").data["data"], [])
        response = self.client.get(f"/api/v1/patient/care/professional/access-grants/{grant_a.id}/encounters/")
        self.assertEqual(response.status_code, 404)

    def test_consultations_are_read_only_and_patient_owned(self):
        Consultation.objects.create(patient=self.profile, professional_name="Dr Test", facility_label="Clinique fictive", reason="Motif fictif", validated_at=timezone.now())
        self.client.force_authenticate(self.user)
        self.assertEqual(len(self.client.get("/api/v1/patient/care/consultations/").data["data"]), 1)
        self.client.force_authenticate(self.other)
        self.assertEqual(self.client.get("/api/v1/patient/care/consultations/").data["data"], [])

    def test_professional_request_requires_verification_and_active_establishment(self):
        patient = self.profile
        doctor = User.objects.create_user(username="doctor-grant", email="doctor-grant@example.test", password="local-test-password", first_name="Docteur", last_name="Test")
        profile = ProfessionalProfile.objects.create(user=doctor, professional_title="Médecin", verification_status="verified")
        AccountContext.objects.create(user=doctor, role="professional", is_active=True)
        establishment = Establishment.objects.create(created_by=self.user, name="Clinique Grant", establishment_type="Clinique", city="Abidjan", address="A", phone="0", email="grant@example.test", responsible_name="Root", status="active", internal_code="GRANT-1")
        EstablishmentMembership.objects.create(establishment=establishment, professional=profile, status="active")
        profile.active_establishment = establishment
        profile.save(update_fields=("active_establishment", "updated_at"))
        self.client.force_authenticate(doctor)
        created = self.client.post("/api/v1/patient/care/professional/access-grants/", {"patient_id": str(patient.id), "scope": ["preconsultation", "declarations"]}, format="json")
        self.assertEqual(created.status_code, 201)
        self.assertEqual(created.data["data"]["status"], "pending")
        self.assertEqual(created.data["data"]["establishment_id"], str(establishment.id))

    def test_professional_cannot_request_access_for_unknown_scope_or_duplicate(self):
        doctor = User.objects.create_user(username="doctor-duplicate", password="local-test-password")
        profile = ProfessionalProfile.objects.create(user=doctor, professional_title="Médecin", verification_status="verified")
        AccountContext.objects.create(user=doctor, role="professional", is_active=True)
        establishment = Establishment.objects.create(created_by=self.user, name="Clinique Grant 2", establishment_type="Clinique", city="Abidjan", address="A", phone="0", email="grant2@example.test", responsible_name="Root", status="active", internal_code="GRANT-2")
        EstablishmentMembership.objects.create(establishment=establishment, professional=profile, status="active")
        profile.active_establishment = establishment
        profile.save(update_fields=("active_establishment", "updated_at"))
        MfaDevice.objects.create(user=doctor, secret="JBSWY3DPEHPK3PXP", is_active=True)
        self.client.force_authenticate(doctor)
        unknown = self.client.post("/api/v1/patient/care/professional/access-grants/", {"patient_id": str(self.profile.id), "scope": ["diagnostic"]}, format="json")
        self.assertEqual(unknown.status_code, 400)
        first = self.client.post("/api/v1/patient/care/professional/access-grants/", {"patient_id": str(self.profile.id), "scope": ["preconsultation"]}, format="json")
        self.assertEqual(first.status_code, 201)
        duplicate = self.client.post("/api/v1/patient/care/professional/access-grants/", {"patient_id": str(self.profile.id), "scope": ["preconsultation"]}, format="json")
        self.assertEqual(duplicate.status_code, 400)

    def test_professional_validates_consultation_from_closed_encounter_with_server_context(self):
        doctor = User.objects.create_user(username="doctor-consult", password="local-test-password", first_name="Docteur", last_name="Validant")
        profile = ProfessionalProfile.objects.create(user=doctor, professional_title="Médecin", verification_status="verified")
        AccountContext.objects.create(user=doctor, role="professional", is_active=True)
        establishment = Establishment.objects.create(created_by=self.user, name="Clinique Consultation", establishment_type="Clinique", city="Abidjan", address="C", phone="0", email="consult@example.test", responsible_name="Root", status="active", internal_code="CONSULT-1")
        EstablishmentMembership.objects.create(establishment=establishment, professional=profile, status="active")
        profile.active_establishment = establishment
        profile.save(update_fields=("active_establishment", "updated_at"))
        MfaDevice.objects.create(user=doctor, secret="JBSWY3DPEHPK3PXP", is_active=True)
        encounter = CareEncounter.objects.create(patient=self.profile, reason="Motif fictif", observations="Observations fictives", status="closed", closed_at=timezone.now())
        grant = AccessGrant.objects.create(patient=self.profile, professional=profile, establishment=establishment, professional_name="Docteur Validant", facility_label=establishment.name, scope=["preconsultation", "declarations"], status="active", starts_at=timezone.now() - timedelta(minutes=5), expires_at=timezone.now() + timedelta(hours=1))
        self.client.force_authenticate(doctor)
        response = self.client.post("/api/v1/patient/care/professional/consultations/", {"access_grant_id": str(grant.id), "source_encounter_id": str(encounter.id), "patient_id": str(self.other_profile.id), "professional_id": str(self.other.id), "establishment_id": str(self.other.id), "conclusion": "Conclusion fictive", "care_plan": "Suivi fictif", "attestation_svg": "<svg></svg>"}, format="json")
        self.assertEqual(response.status_code, 201)
        consultation = Consultation.objects.get()
        self.assertEqual(consultation.professional_id, profile.id)
        self.assertEqual(consultation.establishment_id, establishment.id)
        self.assertEqual(consultation.patient_id, self.profile.id)
        self.assertEqual(consultation.source_encounter_id, encounter.id)
        self.assertEqual(ConsultationRevision.objects.filter(consultation=consultation).count(), 1)
        self.client.force_authenticate(self.user)
        patient_history = self.client.get("/api/v1/patient/care/consultations/")
        self.assertEqual(patient_history.status_code, 200)
        self.assertEqual(patient_history.data["data"][0]["provenance"]["code"], "verified")

    def test_consultation_rejects_expired_grant_and_open_preconsultation(self):
        doctor = User.objects.create_user(username="doctor-expired", password="local-test-password")
        profile = ProfessionalProfile.objects.create(user=doctor, professional_title="Médecin", verification_status="verified")
        AccountContext.objects.create(user=doctor, role="professional", is_active=True)
        establishment = Establishment.objects.create(created_by=self.user, name="Clinique Expiree", establishment_type="Clinique", city="Abidjan", address="D", phone="0", email="expired@example.test", responsible_name="Root", status="active", internal_code="EXPIRE-1")
        EstablishmentMembership.objects.create(establishment=establishment, professional=profile, status="active")
        profile.active_establishment = establishment
        profile.save(update_fields=("active_establishment", "updated_at"))
        MfaDevice.objects.create(user=doctor, secret="JBSWY3DPEHPK3PXP", is_active=True)
        encounter = CareEncounter.objects.create(patient=self.profile, reason="Motif ouvert", status="draft")
        grant = AccessGrant.objects.create(patient=self.profile, professional=profile, establishment=establishment, professional_name="Médecin", facility_label=establishment.name, scope=["preconsultation"], status="active", starts_at=timezone.now() - timedelta(hours=3), expires_at=timezone.now() - timedelta(minutes=1))
        self.client.force_authenticate(doctor)
        response = self.client.post("/api/v1/patient/care/professional/consultations/", {"access_grant_id": str(grant.id), "source_encounter_id": str(encounter.id), "attestation_svg": "<svg></svg>"}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(Consultation.objects.count(), 0)

    def test_professional_reads_only_closed_encounters_after_active_grant(self):
        doctor = User.objects.create_user(username="doctor-read", password="local-test-password")
        profile = ProfessionalProfile.objects.create(user=doctor, professional_title="Médecin", verification_status="verified")
        AccountContext.objects.create(user=doctor, role="professional", is_active=True)
        establishment = Establishment.objects.create(created_by=self.user, name="Clinique Lecture", establishment_type="Clinique", city="Abidjan", address="E", phone="0", email="read@example.test", responsible_name="Root", status="active", internal_code="READ-1")
        EstablishmentMembership.objects.create(establishment=establishment, professional=profile, status="active")
        profile.active_establishment = establishment
        profile.save(update_fields=("active_establishment", "updated_at"))
        MfaDevice.objects.create(user=doctor, secret="JBSWY3DPEHPK3PXP", is_active=True)
        closed = CareEncounter.objects.create(patient=self.profile, reason="Clos", status="closed", closed_at=timezone.now())
        CareEncounter.objects.create(patient=self.profile, reason="Brouillon", status="draft")
        grant = AccessGrant.objects.create(patient=self.profile, professional=profile, establishment=establishment, professional_name="Médecin", facility_label=establishment.name, scope=["preconsultation"], status="active", starts_at=timezone.now(), expires_at=timezone.now() + timedelta(hours=1))
        self.client.force_authenticate(doctor)
        response = self.client.get(f"/api/v1/patient/care/professional/access-grants/{grant.id}/encounters/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual([item["id"] for item in response.data["data"]], [str(closed.id)])

    def test_patient_consent_to_professional_consultation_and_revocation(self):
        doctor = User.objects.create_user(
            username="doctor-full-journey",
            first_name="Docteur",
            last_name="Parcours",
            password="local-test-password",
        )
        profile = ProfessionalProfile.objects.create(
            user=doctor,
            professional_title="Médecin",
            verification_status="verified",
        )
        AccountContext.objects.create(user=doctor, role="professional", is_active=True)
        establishment = Establishment.objects.create(
            created_by=self.user,
            name="Clinique Parcours",
            establishment_type="Clinique",
            city="Abidjan",
            address="Adresse fictive",
            phone="00000000",
            email="parcours@example.test",
            responsible_name="Responsable fictif",
            status="active",
            internal_code="FLOW-1",
        )
        EstablishmentMembership.objects.create(
            establishment=establishment,
            professional=profile,
            status="active",
        )
        profile.active_establishment = establishment
        profile.save(update_fields=("active_establishment", "updated_at"))

        patient_client = APIClient()
        patient_client.force_authenticate(self.user)
        professional_client = APIClient()
        professional_client.force_authenticate(doctor)

        request = professional_client.post(
            "/api/v1/patient/care/professional/access-grants/",
            {"patient_id": str(self.profile.id), "scope": ["preconsultation"]},
            format="json",
        )
        self.assertEqual(request.status_code, 201)
        grant_id = request.data["data"]["id"]
        self.assertEqual(request.data["data"]["status"], "pending")

        denied_before_consent = professional_client.get(
            f"/api/v1/patient/care/professional/access-grants/{grant_id}/encounters/"
        )
        self.assertEqual(denied_before_consent.status_code, 403)

        consent = patient_client.post(
            f"/api/v1/patient/care/access-grants/{grant_id}/accept/"
        )
        self.assertEqual(consent.status_code, 200)
        self.assertEqual(consent.data["data"]["status"], "active")

        draft_response = patient_client.post(
            "/api/v1/patient/care/encounters/",
            {
                "facility_label": establishment.name,
                "reason": "Pré-consultation en brouillon",
                "observations": "Cette version ne doit pas être accessible au professionnel.",
            },
            format="json",
        )
        self.assertEqual(draft_response.status_code, 201)
        draft_id = draft_response.data["data"]["id"]

        encounter_response = patient_client.post(
            "/api/v1/patient/care/encounters/",
            {
                "facility_label": establishment.name,
                "reason": "Suivi de santé",
                "observations": "Informations communiquées par le patient.",
                "recorded_with_help": "Saisie par le patient",
            },
            format="json",
        )
        self.assertEqual(encounter_response.status_code, 201)
        encounter_id = encounter_response.data["data"]["id"]
        closed_encounter = patient_client.post(
            f"/api/v1/patient/care/encounters/{encounter_id}/",
            {},
            format="json",
        )
        self.assertEqual(closed_encounter.status_code, 200)
        self.assertEqual(closed_encounter.data["data"]["status"], "closed")

        authorized_encounters = professional_client.get(
            f"/api/v1/patient/care/professional/access-grants/{grant_id}/encounters/"
        )
        self.assertEqual(authorized_encounters.status_code, 200)
        self.assertEqual(
            [item["id"] for item in authorized_encounters.data["data"]],
            [encounter_id],
        )
        self.assertNotIn(
            draft_id,
            [item["id"] for item in authorized_encounters.data["data"]],
        )

        consultation_response = professional_client.post(
            "/api/v1/patient/care/professional/consultations/",
            {
                "access_grant_id": grant_id,
                "source_encounter_id": encounter_id,
                "conclusion": "Conclusion de suivi fictive.",
                "care_plan": "Contrôle ultérieur.",
                "attestation_svg": "<svg></svg>",
            },
            format="json",
        )
        self.assertEqual(consultation_response.status_code, 201)
        self.assertEqual(
            consultation_response.data["data"]["source_encounter_id"],
            encounter_id,
        )

        patient_history = patient_client.get("/api/v1/patient/care/consultations/")
        self.assertEqual(patient_history.status_code, 200)
        self.assertEqual(len(patient_history.data["data"]), 1)
        self.assertEqual(
            patient_history.data["data"][0]["provenance"]["code"], "verified"
        )

        revoked = patient_client.post(
            f"/api/v1/patient/care/access-grants/{grant_id}/revoke/"
        )
        self.assertEqual(revoked.status_code, 200)
        self.assertEqual(revoked.data["data"]["status"], "revoked")
        denied_after_revocation = professional_client.get(
            f"/api/v1/patient/care/professional/access-grants/{grant_id}/encounters/"
        )
        self.assertEqual(denied_after_revocation.status_code, 403)

class PatientQrContractTests(TestCase):
    def test_qr_contract_is_five_minutes_and_single_use_value_is_hashed(self):
        from .services import QR_TOKEN_TTL_SECONDS, create_patient_qr_token
        from .models import PatientAccessQrToken
        user = User.objects.create_user(username="qr-contract", password="local-test-password")
        profile = PatientProfile.objects.create(user=user)
        before = timezone.now()
        raw = create_patient_qr_token(patient=profile)
        token = PatientAccessQrToken.objects.get(patient=profile)
        self.assertEqual(QR_TOKEN_TTL_SECONDS, 300)
        self.assertGreaterEqual((token.expires_at - before).total_seconds(), 299)
        self.assertNotEqual(token.token_hash, raw)

class SvgSanitizerSecurityTests(TestCase):
    def test_svg_allows_drawing_primitives_and_normalizes_output(self):
        from .svg_sanitizer import sanitize_svg
        output = sanitize_svg('<svg viewBox="0 0 10 10"><path d="M0 0 L10 10" stroke="#000" fill="none" /></svg>')
        self.assertIn("<path", output)
        self.assertNotIn("  ", output)

    def test_svg_rejects_script_css_external_refs_and_foreign_namespace(self):
        from .svg_sanitizer import sanitize_svg
        payloads = (
            '<svg><script>alert(1)</script></svg>',
            '<svg><path style="fill:url(https://evil.test/x)" d="M0 0" /></svg>',
            '<svg><image href="https://evil.test/x" /></svg>',
            '<svg><path d="M0 0" fill="url(#paint)" /></svg>',
            '<svg xmlns="http://www.w3.org/2001/svg"><foreignObject><div>x</div></foreignObject></svg>',
            '<!DOCTYPE svg [<!ENTITY x "boom">]><svg>&x;</svg>',
        )
        for payload in payloads:
            with self.subTest(payload=payload):
                with self.assertRaises(ValidationError):
                    sanitize_svg(payload)
