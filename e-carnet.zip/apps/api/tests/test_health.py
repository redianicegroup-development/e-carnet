import os
import subprocess
import sys
from pathlib import Path

from django.test import TestCase


class HealthTests(TestCase):
    def test_legacy_health_is_public_and_contains_no_sensitive_data(self):
        response = self.client.get("/api/v1/health/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ok"})

    def test_liveness_is_public_and_does_not_depend_on_the_database(self):
        response = self.client.get("/api/v1/health/live/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ok"})

    def test_readiness_checks_database_without_returning_database_details(self):
        response = self.client.get("/api/v1/health/ready/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ready"})
        self.assertNotIn("database", response.json())


class ProductionSettingsTests(TestCase):
    def test_non_debug_settings_refuse_a_missing_secret_key(self):
        environment = os.environ.copy()
        environment.pop("DJANGO_SECRET_KEY", None)
        environment["DJANGO_DEBUG"] = "false"
        api_directory = Path(__file__).resolve().parents[1]

        result = subprocess.run(
            [sys.executable, "-c", "import config.settings"],
            cwd=api_directory,
            env=environment,
            capture_output=True,
            text=True,
            check=False,
        )

        self.assertNotEqual(result.returncode, 0)
        self.assertIn("DJANGO_SECRET_KEY must be set", result.stderr)

    def test_local_dev_defaults_to_debug_mode_when_no_env_is_set(self):
        environment = os.environ.copy()
        environment.pop("DJANGO_SECRET_KEY", None)
        environment.pop("DJANGO_DEBUG", None)
        api_directory = Path(__file__).resolve().parents[1]

        result = subprocess.run(
            [
                sys.executable,
                "-c",
                "import importlib; settings = importlib.import_module('config.settings'); print(settings.DEBUG)",
            ],
            cwd=api_directory,
            env=environment,
            capture_output=True,
            text=True,
            check=False,
        )

        self.assertEqual(result.returncode, 0)
        self.assertIn("True", result.stdout.strip())
