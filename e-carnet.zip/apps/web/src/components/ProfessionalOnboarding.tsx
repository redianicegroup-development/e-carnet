"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export function ProfessionalOnboarding() {
  const router = useRouter();
  const [form, setForm] = useState({
    professional_title: "Médecin",
    specialty: "Généraliste",
    professional_identifier: "",
  });
  const [message, setMessage] = useState("Complétez votre profil professionnel pour accéder au parcours V1.");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setMessage("Enregistrement de votre profil…");
    const csrfResponse = await fetch(`${API}/api/v1/csrf/`, { credentials: "include", cache: "no-store" });
    const token = decodeURIComponent(
      document.cookie
        .split(";")
        .map((part) => part.trim())
        .find((part) => part.startsWith("csrftoken="))
        ?.slice(9) ?? ""
    );

    const response = await fetch(`${API}/api/v1/professionals/onboarding/`, {
      method: "PATCH",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": token,
      },
      body: JSON.stringify(form),
    });

    const payload = await response.json().catch(() => ({}));
    if (!csrfResponse.ok || !response.ok) {
      setMessage(payload.message ?? "Le profil professionnel n’a pas pu être enregistré.");
      return;
    }

    setMessage("Profil professionnel enregistré.");
    router.push("/professionnel");
  }

  return (
    <form className="card auth-form" onSubmit={submit}>
      <span className="eyebrow">Étape professionnel · V1</span>
      <h1>Valider votre profil de praticien.</h1>
      <p className="muted">
        Ce profil ne donne pas d’accès clinique immédiat. Il ouvre le parcours de vérification, de rattachement et d’autorisation patient.
      </p>

      <label className="field">
        <span>Profession</span>
        <input
          required
          value={form.professional_title}
          onChange={(event) => setForm({ ...form, professional_title: event.target.value })}
        />
      </label>

      <label className="field">
        <span>Spécialité</span>
        <input
          value={form.specialty}
          onChange={(event) => setForm({ ...form, specialty: event.target.value })}
        />
      </label>

      <label className="field">
        <span>Identifiant professionnel / registre</span>
        <input
          value={form.professional_identifier}
          onChange={(event) => setForm({ ...form, professional_identifier: event.target.value })}
        />
      </label>

      <button type="submit" className="button primary">Enregistrer mon profil</button>
      <p className="status" aria-live="polite">{message}</p>
    </form>
  );
}
