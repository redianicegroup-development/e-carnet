"use client";

import { useEffect, useState } from "react";

type Profile = {
  professional_title: string;
  specialty: string;
  professional_identifier: string;
  verification_status: string;
  active_establishment: string | null;
};

type Establishment = {
  id: string;
  name: string;
  establishment_type: string;
  city: string;
  address: string;
  phone: string;
  email: string;
  responsible_name: string;
  status: string;
};

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

async function get<T>(path: string): Promise<T> {
  const response = await fetch(`${API}${path}`, { credentials: "include", cache: "no-store" });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.message ?? "Service indisponible.");
  return payload.data as T;
}

async function post<T>(path: string, body: Record<string, unknown>): Promise<T> {
  await fetch(`${API}/api/v1/csrf/`, { credentials: "include", cache: "no-store" });
  const token = decodeURIComponent(document.cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith("csrftoken="))?.slice(9) ?? "");
  const response = await fetch(`${API}${path}`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json", "X-CSRFToken": token }, body: JSON.stringify(body) });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.message ?? "Action impossible.");
  return payload.data as T;
}

export function ProfessionalManagement() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [establishments, setEstablishments] = useState<Establishment[]>([]);
  const [message, setMessage] = useState("Chargement du parcours professionnel…");
  const [membershipCode, setMembershipCode] = useState<Record<string, string>>({});

  async function refresh() {
    const [me, list] = await Promise.all([get<Profile>("/api/v1/professionals/me/"), get<Establishment[]>("/api/v1/establishments/")]);
    setProfile(me);
    setEstablishments(list);
    setMessage("Sécurité et rattachement disponibles.");
  }

  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const [me, list] = await Promise.all([get<Profile>("/api/v1/professionals/me/"), get<Establishment[]>("/api/v1/establishments/")]);
        if (!active) return;
        setProfile(me);
        setEstablishments(list);
        setMessage("Sécurité et rattachement disponibles.");
      } catch (error) {
        if (active) setMessage(error instanceof Error ? error.message : "Le parcours professionnel n’est pas disponible.");
      }
    }
    void load();
    return () => { active = false; };
  }, []);

  async function requestMembership(establishmentId: string) {
    try {
      await post<{ id: string }>("/api/v1/establishments/join-codes/redeem/", { code: membershipCode[establishmentId] ?? "" });
      setMessage("Code consommé : demande de rattachement en attente de validation par l’administrateur nominatif.");
      await refresh();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Le rattachement n’a pas pu être demandé.");
    }
  }

  async function setActive(establishmentId: string) {
    try {
      await post<{ active_establishment: string }>("/api/v1/establishments/active/", { establishment_id: establishmentId });
      setMessage("Établissement actif sélectionné pour le contexte professionnel.");
      await refresh();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "L’établissement actif n’a pas pu être mis à jour.");
    }
  }

  return (
    <section className="hero-page">
      <span className="eyebrow">Parcours professionnel V1</span>
      <h1>Vérification, rattachement et établissement actif</h1>
      <p className="notice" role="status" aria-live="polite">{message}</p>
      <div className="card" style={{ marginTop: 20 }}>
        <h2>Profil professionnel</h2>
        {profile ? <ul><li>Profession : {profile.professional_title || "À renseigner"}</li><li>Spécialité : {profile.specialty || "À renseigner"}</li><li>Identifiant : {profile.professional_identifier || "À renseigner"}</li><li>Établissement actif : {profile.active_establishment ?? "Aucun"}</li></ul> : <p className="muted">Profil non encore créé.</p>}
      </div>
      <section className="card" style={{ marginTop: 24 }}>
        <span className="eyebrow">Accès établissement</span>
        <h2>Une structure doit être vérifiée par E‑Carnet</h2>
        <p className="muted">Il n’est plus possible de créer une demande ou un compte établissement depuis cette interface. L’hôpital ou la clinique transmet ses justificatifs par l’adresse officielle E‑Carnet ; le staff vérifie ensuite la structure et invite nominativement son administrateur.</p>
        <p><strong>Contact :</strong> <a href="mailto:etablissements@e-carnet.example">etablissements@e-carnet.example</a></p>
      </section>
      <section className="card" style={{ marginTop: 24 }}>
        <h2>Établissements rattachés</h2>
        {establishments.length === 0 ? <p className="empty">Aucun établissement actif n’est lié à votre compte.</p> : <div className="stack">{establishments.map((establishment) => <article key={establishment.id} className="record"><div><strong>{establishment.name}</strong><p className="muted">{establishment.city} · {establishment.establishment_type} · {establishment.status}</p></div><div className="actions">{profile?.active_establishment !== establishment.id && <button type="button" className="button small" onClick={() => setActive(establishment.id)}>Choisir comme actif</button>}</div><div className="field" style={{ minWidth: 220 }}><span>Code médecin temporaire fourni par la structure</span><input value={membershipCode[establishment.id] ?? ""} onChange={(event) => setMembershipCode((current) => ({ ...current, [establishment.id]: event.target.value }))} placeholder="ECM-…" /><button type="button" className="button small" onClick={() => requestMembership(establishment.id)}>Demander le rattachement</button></div></article>)}</div>}
      </section>
    </section>
  );
}
