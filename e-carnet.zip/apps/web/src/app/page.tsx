import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Mon Carnet Numérique — Votre santé vous accompagne",
  description: "Un carnet de santé personnel, préparé avec le patient et partagé uniquement avec son autorisation.",
  robots: { index: true, follow: true },
};

const trustPoints = [
  {
    title: "Personnel",
    text: "Le patient garde le contrôle de son carnet et choisit qui voit quoi.",
  },
  {
    title: "Autorisé",
    text: "Aucune donnée n’est accessible sans consentement explicite et traçable.",
  },
  {
    title: "Traçable",
    text: "Les accès, décisions et pré-consultations restent audités côté serveur.",
  },
];

export default function HomePage() {
  return (
    <main className="landing-shell">
      <header className="topbar landing-topbar">
        <p className="brand">
          <span className="brand-mark" aria-hidden="true">＋</span>
          Mon Carnet Numérique
        </p>
        <div className="header-links">
          <Link href="/v1" className="button small">Voir la V1</Link>
          <Link href="/connexion" className="button primary small">Se connecter</Link>
        </div>
      </header>

      <section className="landing-hero">
        <div className="landing-hero__copy">
          <span className="eyebrow">Un carnet personnel, sous votre contrôle</span>
          <h1>Votre santé, mieux suivie, mieux sécurisée.</h1>
          <p className="muted">
            Le patient centralise son parcours, donne son consentement avant chaque accès, et garde la maîtrise de ses informations dans un environnement sécurisé et auditable.
          </p>

          <div className="actions">
            <Link href="/inscription" className="button primary">Créer mon carnet</Link>
            <Link href="/connexion" className="button">Se connecter</Link>
            <Link href="/professionnel" className="button">Je suis un professionnel</Link>
            <Link href="/etablissement" className="button">Je représente un établissement</Link>
          </div>

          <div className="landing-proof">
            <span>✓ Sans donnée médicale réelle</span>
            <span>✓ Consentement explicite</span>
            <span>✓ Accès auditable</span>
          </div>
        </div>

        <div className="landing-visual" aria-hidden="true">
          <div className="landing-card landing-card--main">
            <div className="mini-header">
              <span className="dot dot--green" />
              <span className="dot dot--blue" />
              <span className="dot dot--orange" />
            </div>
            <div className="feature-pill">Carnet patient</div>
            <div className="visual-stack">
              <div className="visual-box visual-box--big" />
              <div className="visual-box visual-box--small" />
              <div className="visual-box visual-box--tiny" />
            </div>
          </div>
          <div className="landing-card landing-card--floating">
            <strong>Consentement</strong>
            <span>2h · accord explicite</span>
          </div>
        </div>
      </section>

      <section className="grid landing-grid" aria-label="Principes du produit">
        {trustPoints.map((item) => (
          <article key={item.title} className="card landing-card-item">
            <span className="eyebrow">{item.title}</span>
            <h2>{item.title}</h2>
            <p className="muted">{item.text}</p>
          </article>
        ))}
      </section>

      <section className="landing-bottom">
        <div className="card landing-panel">
          <h2>Une base solide pour la V1</h2>
          <p className="muted">
            Inscription sécurisée, parcours patient et professionnel guidés, consentement contrôlé et audit des accès.
          </p>
        </div>
        <div className="card landing-panel">
          <h2>Ce que la V1 garantit</h2>
          <ul>
            <li>Le patient reste maître de son carnet.</li>
            <li>Le professionnel ne voit rien sans autorisation explicite.</li>
            <li>Les accès sont temporaires, limités et audités.</li>
          </ul>
        </div>
      </section>

      <footer className="footer landing-footer">
        <Link href="/a-propos">À propos</Link> · <Link href="/securite">Sécurité</Link> · <Link href="/faq">FAQ</Link>
        <br />
        Socle de développement — données fictives uniquement. Pas de donnée de santé réelle dans ce pilote.
      </footer>
    </main>
  );
}

