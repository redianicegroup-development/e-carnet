import Link from "next/link";
import { WorkspaceNav } from "../../../components/WorkspaceNav";
import { AccountSettingsClient } from "../../../components/AccountSettingsClient";
import { ThemeSettingsClient } from "../../../components/ThemeSettingsClient";
export default function PatientSettingsPage() { return <main className="shell"><header className="topbar patient-topbar"><div className="patient-topbar-main"><Link className="button ghost" href="/patient">← Retour</Link><p className="brand"><span className="brand-mark" aria-hidden="true">＋</span>Paramètres du compte</p></div></header><WorkspaceNav workspace="patient" /><section className="settings-page"><AccountSettingsClient /><ThemeSettingsClient /></section><footer className="footer">Vous contrôlez votre identité, vos méthodes de connexion et vos autorisations.</footer></main>; }
