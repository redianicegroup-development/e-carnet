import Link from "next/link";
import { PatientDashboard } from "../../components/PatientDashboard";
import { WorkspaceNav } from "../../components/WorkspaceNav";

export const metadata = { title: "Mon espace patient — Mon Carnet Numérique", robots: { index: false, follow: false } };

export default function PatientPage() {
  return (
    <main className="shell">
      <header className="topbar patient-topbar">
        <div className="patient-topbar-main">
          <Link className="button ghost" href="/">← Accueil</Link>
          <p className="brand">
            <span className="brand-mark" aria-hidden="true">＋</span>
            Mon espace patient
          </p>
        </div>
      </header>

      <WorkspaceNav workspace="patient" />

      <PatientDashboard />

      <footer className="footer">
        Données fictives uniquement en développement. Aucun professionnel ne peut lire votre carnet sans
        autorisation explicite.
      </footer>
    </main>
  );
}
