import Link from "next/link";
import { PatientConsultations } from "../../../components/PatientConsultations";
import { WorkspaceNav } from "../../../components/WorkspaceNav";
export const metadata = { title: "Mes consultations — Mon Carnet Numérique", robots: { index: false, follow: false } };
export default function ConsultationsPage() { return <main className="shell"><header className="topbar"><Link className="button" href="/patient">← Mon espace</Link><p className="brand">Historique médical</p></header><WorkspaceNav workspace="patient" /><PatientConsultations /><footer className="footer">La provenance et le professionnel restent visibles dans votre historique.</footer></main>; }
