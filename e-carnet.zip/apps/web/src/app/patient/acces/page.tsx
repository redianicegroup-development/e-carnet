import Link from "next/link";
import { PatientAccessGrants } from "../../../components/PatientAccessGrants";
import { WorkspaceNav } from "../../../components/WorkspaceNav";
export const metadata = { title: "Mes autorisations — Mon Carnet Numérique", robots: { index: false, follow: false } };
export default function AccessPage() { return <main className="shell"><header className="topbar"><Link className="button" href="/patient">← Mon espace</Link><p className="brand">Autorisations</p></header><WorkspaceNav workspace="patient" /><PatientAccessGrants /><footer className="footer">Vous pouvez révoquer un accès actif à tout moment.</footer></main>; }
