import Link from "next/link";
import { EstablishmentSettingsClient } from "../../../components/EstablishmentSettingsClient";
import { WorkspaceNav } from "../../../components/WorkspaceNav";

export const metadata = {
  title: "Paramètres établissement — Mon Carnet Numérique",
  robots: { index: false, follow: false },
};

export default function EstablishmentSettingsPage() {
  return (
    <main className="shell">
      <header className="topbar patient-topbar">
        <div className="patient-topbar-main">
          <Link className="button ghost" href="/professionnel/etablissements">← Établissements</Link>
          <Link className="button" href="/etablissement/gestion">Gérer les rattachements</Link>
          <p className="brand"><span className="brand-mark" aria-hidden="true">＋</span>Paramètres établissement</p>
        </div>
      </header>
      <WorkspaceNav workspace="establishment" />
      <section className="hero" style={{ paddingBottom: 24 }}>
        <span className="eyebrow">Profil de la structure</span>
        <h1 style={{ fontSize: "clamp(30px, 5vw, 42px)" }}>Votre établissement, ses contacts et son compte.</h1>
        <p className="muted">Consultez les informations associées à votre session. Les données sont chargées depuis l’API, sans fiche fictive.</p>
      </section>
      <EstablishmentSettingsClient />
      <footer className="footer">Gestion d’équipe, responsable habilité avancé et gestion des sessions seront complétés dans les prochaines versions.</footer>
    </main>
  );
}
