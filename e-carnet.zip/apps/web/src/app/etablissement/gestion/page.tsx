import { EstablishmentAdminWorkspace } from "../../../components/EstablishmentAdminWorkspace";

export const metadata = { title: "Gestion établissement — Mon Carnet Numérique", robots: { index: false, follow: false } };

export default function EstablishmentManagementPage() {
  return <EstablishmentAdminWorkspace />;
}
