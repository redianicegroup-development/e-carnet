import Link from "next/link";
import { EstablishmentWorkspace } from "../../components/EstablishmentWorkspace";
import { WorkspaceNav } from "../../components/WorkspaceNav";

export const metadata = {
  title: "Espace établissement — Mon Carnet Numérique",
  description: "Suivre une demande établissement et préparer l’accompagnement de configuration.",
  robots: { index: false, follow: false },
};

export default function EstablishmentPage() {
  return (
    <main className="shell">
      <header className="topbar patient-topbar">
        <div className="patient-topbar-main">
          <Link className="button ghost" href="/">← Accueil</Link>
          <p className="brand"><span className="brand-mark" aria-hidden="true">＋</span>Espace établissement</p>
        </div>
      </header>
      <WorkspaceNav workspace="establishment" />
      <EstablishmentWorkspace />
      <footer className="footer">En V1, l’établissement ne consulte aucun dossier clinique depuis cet espace. La gestion d’équipe complète est prévue après le pilote.</footer>
    </main>
  );
}
