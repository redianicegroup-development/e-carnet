import { StaffEstablishmentConsole } from "../../../components/StaffEstablishmentConsole";

export const metadata = { title: "Console staff établissement — Mon Carnet Numérique", robots: { index: false, follow: false } };

export default function StaffEstablishmentsPage() {
  return <StaffEstablishmentConsole />;
}
