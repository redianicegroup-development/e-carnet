import Link from "next/link";
import { ProfessionalSettingsClient } from "../../../components/ProfessionalSettingsClient";
import { WorkspaceNav } from "../../../components/WorkspaceNav";

export const metadata = { title: "Mon profil professionnel — Mon Carnet Numérique", robots: { index: false, follow: false } };

export default function ProfessionalSettingsPage() {
  return (
    <main className="shell">
      <header className="topbar patient-topbar">
        <div className="patient-topbar-main">
          <Link className="button ghost" href="/professionnel">← Mon espace</Link>
          <p className="brand"><span className="brand-mark" aria-hidden="true">＋</span>Moi et paramètres</p>
        </div>
      </header>
      <WorkspaceNav workspace="professional" />
      <ProfessionalSettingsClient />
      <footer className="footer">Les données professionnelles sont contrôlées par l’API. Aucun dossier patient n’est accessible depuis les paramètres du compte.</footer>
    </main>
  );
}
