import Link from "next/link";
import { ProfessionalManagement } from "../../../components/ProfessionalManagement";
import { WorkspaceNav } from "../../../components/WorkspaceNav";

export const metadata = { title: "Établissements et rattachement — Mon Carnet Numérique", robots: { index: false, follow: false } };

export default function ProfessionalEstablishmentsPage() {
  return (
    <main className="shell">
      <header className="topbar">
        <Link className="button" href="/professionnel">← Mon espace</Link>
        <p className="brand">Établissements et rattachement</p>
        <Link className="button small" href="/etablissement/parametres">Paramètres établissement</Link>
      </header>
      <WorkspaceNav workspace="professional" />
      <ProfessionalManagement />
    </main>
  );
}
