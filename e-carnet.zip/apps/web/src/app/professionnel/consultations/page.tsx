import { ProfessionalConsultations } from "../../../components/ProfessionalConsultations";

export default function ProfessionalConsultationsPage() {
  return <ProfessionalConsultations />;
}
