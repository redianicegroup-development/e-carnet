import Link from "next/link";
import type { Metadata } from "next";
import { WorkspaceNav } from "../../components/WorkspaceNav";

export const metadata: Metadata = {
  title: "Espace professionnel — Mon Carnet Numérique",
  description: "Parcours professionnel V1 : vérification, rattachement à l’établissement, établissement actif et accès conditionné au consentement patient.",
  robots: { index: false, follow: false },
};

const steps = [
  "Compte créé et onboarding professionnel terminé",
  "Vérification de l’identité et du statut professionnel",
  "Demande de rattachement par code interne de l’établissement",
  "Validation par le Root de l’établissement",
  "Sélection de l’établissement actif",
  "AccessGrant accepté par le patient avant tout accès clinique",
];

const controls = [
  "Aucun accès clinique avant vérification",
  "Aucun accès sans établissement actif",
  "Aucun accès sans consentement du patient",
  "Toutes les lectures et validations sont auditées",
];

export default function ProfessionalPage() {
  return (
    <main className="shell">
      <header className="topbar">
        <p className="brand">
          <span className="brand-mark" aria-hidden="true">＋</span>
          Espace professionnel
        </p>
        <div className="header-links">
          <Link href="/" className="button small">Accueil</Link>
          <Link href="/connexion" className="button small">Connexion</Link>
        </div>
      </header>

      <WorkspaceNav workspace="professional" />

      <section className="hero hero-page">
        <span className="eyebrow">Professionnel · V1</span>
        <h1>Un accès clinique contrôlé, réservé aux cas autorisés.</h1>
        <p className="muted">
          En V1, le professionnel n’accède à un dossier qu’après vérification, rattachement valide et consentement
          explicite du patient. Le MFA TOTP est volontairement reporté en V3 ; il ne bloque pas le parcours V1.
        </p>

        <div className="actions">
          <Link href="/professionnel/onboarding" className="button primary">Compléter mon onboarding</Link>
          <Link href="/professionnel/etablissements" className="button">Établissements</Link>
          <Link href="/professionnel/acces" className="button">Demandes d’accès</Link>
          <Link href="/professionnel/consultations" className="button">Consultations</Link>
          <Link href="/v1" className="button">Voir la V1</Link>
        </div>
      </section>

      <section className="grid" aria-label="Parcours professionnel V1">
        <article className="card">
          <h2>Parcours de mise en situation</h2>
          <ol>
            {steps.map((step) => (
              <li key={step}>{step}</li>
            ))}
          </ol>
        </article>

        <article className="card">
          <h2>Contrôles de sécurité</h2>
          <ul>
            {controls.map((control) => (
              <li key={control}>{control}</li>
            ))}
          </ul>
        </article>
      </section>

      <section className="grid" aria-label="Flux V1">
        <Link className="card card-link" href="/professionnel/onboarding">
          <span className="eyebrow">1</span>
          <h2>Onboarding professionnel</h2>
          <p className="muted">Saisir le profil médical et préparer la vérification.</p>
        </Link>
        <Link className="card card-link" href="/professionnel/etablissements">
          <span className="eyebrow">2</span>
          <h2>Établissement + rattachement</h2>
          <p className="muted">Créer un établissement, demander le rattachement et choisir l’établissement actif.</p>
        </Link>
        <Link className="card card-link" href="/professionnel/acces">
          <span className="eyebrow">3</span>
          <h2>Consentement AccessGrant</h2>
          <p className="muted">Demander l’accès et attendre l’autorisation explicite du patient.</p>
        </Link>
        <Link className="card card-link" href="/professionnel/consultations">
          <span className="eyebrow">4</span>
          <h2>Pré-consultation + consultation</h2>
          <p className="muted">Reprendre la pré-consultation validée et créer la consultation avec provenance.</p>
        </Link>
      </section>

      <section className="card" style={{ marginTop: 24 }}>
        <h2>Ce qui est hors scope de cette V1</h2>
        <p className="muted">
          MFA TOTP, OTP SMS, partages inter-établissements, comptes infirmiers et fonctions cliniques avancées restent
          reportés. La V1 vise la base sûre du produit, pas l’extension complète du système.
        </p>
      </section>

      <footer className="footer">
        V1 professionnelle : vérification, rattachement, établissement actif et consentement patient.
      </footer>
    </main>
  );
}
