import { ProfessionalAccessGrants } from "../../../components/ProfessionalAccessGrants";

export default function ProfessionalAccessPage() {
  return <ProfessionalAccessGrants />;
}
