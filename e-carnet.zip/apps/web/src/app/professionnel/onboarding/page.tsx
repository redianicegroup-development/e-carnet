import Link from "next/link";
import { ProfessionalOnboarding } from "../../../components/ProfessionalOnboarding";
import { WorkspaceNav } from "../../../components/WorkspaceNav";

export const metadata = { title: "Onboarding professionnel — Mon Carnet Numérique", robots: { index: false, follow: false } };

export default function ProfessionalOnboardingPage() {
  return (
    <main className="auth-shell">
      <Link className="button" href="/professionnel">← Espace professionnel</Link>
      <WorkspaceNav workspace="professional" />
      <ProfessionalOnboarding />
    </main>
  );
}
