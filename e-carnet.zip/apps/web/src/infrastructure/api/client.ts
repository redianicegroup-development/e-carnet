const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

function csrfToken(): string {
  return decodeURIComponent(document.cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith("csrftoken="))?.slice(9) ?? "");
}

async function parse<T>(response: Response): Promise<T> {
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new ApiError(payload.message ?? "Le service est momentanément indisponible.", response.status);
  return payload.data as T;
}

export async function apiGet<T>(path: string): Promise<T> {
  return parse<T>(await fetch(`${API}${path}`, { credentials: "include", cache: "no-store" }));
}

export async function apiPost<T>(path: string, body: unknown): Promise<T> {
  const csrf = await fetch(`${API}/api/v1/csrf/`, { credentials: "include", cache: "no-store" });
  if (!csrf.ok) throw new ApiError("Impossible d’établir la session de sécurité.", csrf.status);
  return parse<T>(await fetch(`${API}${path}`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json", "X-CSRFToken": csrfToken() }, body: JSON.stringify(body) }));
}
